export type MetricType =
  | "progress"
  | "milestone"
  | "score"
  | "currency"
  | "currentTarget"
  | "number";

export interface Metric {
  id: string;
  label: string;
  type: MetricType;

  value?: number;

  current?: number | string;
  target?: number | string;

  unit?: string;
  trend?: string;

  color?: string;
  cardWidth: boolean;
  responsible?:boolean;
}

export interface Initiative {
  id: string;
  name: string;
  score: number;

  health: "On Track" | "Needs Attention" | "Off Track" | "Null Track";
  lastUpdatedAt?:string;

  metrics: Metric[];
}

export interface Pillar {
  id: string;
  name: string;
  color: string;
  initiatives: Initiative[];
}
