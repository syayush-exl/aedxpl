import {
    Box,
    Typography,
  } from "@mui/material";
  
  import PillarColumn from "./PillarColumn";
  import { pillarData } from "../../data/pillarData";
  
  export default function PillarOverview() {
    return (
      <Box
        sx={{
          width: "100%",
        //   p: 2,
          bgcolor: "#F1F5F9",
        //   minHeight: "100vh",
        }}
      >
        {/* <Box mb={2}>
          <Typography
            sx={{
              fontSize: 28,
              fontWeight: 800,
              color: "#0F172A",
            }}
          >
            Pillar Overview
          </Typography>
  
          <Typography
            sx={{
              color: "#64748B",
              mt: 0.5,
            }}
          >
            Strategic initiatives and KPI
            performance across all pillars
          </Typography>
        </Box> */}
  
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns:
              "repeat(4, minmax(0, 1fr))",
            gap: 0.5,
            alignItems: "start",
            width: "100%",
          }}
        >
          {pillarData.map((pillar) => (
            <PillarColumn
              key={pillar.id}
              pillar={pillar}
            />
          ))}
        </Box>
      </Box>
    );
  }