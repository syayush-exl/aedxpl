import React from "react";
import {
  Box,
  Card,
  Divider,
  LinearProgress,
  Stack,
  Typography,
} from "@mui/material";

interface NumberItem {
  type: "number";
  label: string;
  value: string | number;
}

interface ProgressItem {
  type: "progress";
  label: string;
  value: number;
}

interface TargetItem {
  type: "target";
  label: string;
  current: string | number;
  target: string | number;
  value: number;
}

type TransformItem = NumberItem | ProgressItem | TargetItem;

interface TransformCard {
  title: string;
  items: TransformItem[];
}

const transformData: TransformCard[] = [
    {
        title: "GPT Global Delivery",
        items: [
          {
            type: "target",
            label: "Resource Mix Savings Progress",
            current: "$12M",
            target: "$40M",
            value: 30,
          },
          {
            type: "target",
            label: "Geo Mix Savings Progress",
            current: "$6M",
            target: "$30M",
            value: 20,
          },
          {
            type: "target",
            label: "Microsite Reduction Progress",
            current: "8 Sites",
            target: "20 Sites",
            value: 40,
          },
          {
            type: "number",
            label: "Microsite Reduction Progress",            
            value: "94:6 --> 90:10",
          },
        ],
      },
      {
        title: "Vendor Management",
        items: [
          {
            type: "target",
            label: "Vendor cost saving realizaed",
            current: "$40M",
            target: "$140M",
            value: 28,
          },         
          
          {
            type: "number",
            label: "Cost CAGR Reduction Progress",            
            value: "Target 4.5%",
          },
        ],
      },
      {
        title: "Stakeholder Excellence",
        items: [
          {
            type: "target",
            label: "Stakeolder Advocacy Score",
            current: "30%",
            target: "90%",
            value: 33,
          },         
          
        //   {
        //     type: "number",
        //     label: "Cost CAGR Reduction Progress",            
        //     value: "Target 4.5%",
        //   },
        ],
      },
//   {
//     title: "Workforce Transformation",
//     items: [
//       {
//         type: "number",
//         label: "People Trained",
//         value: 1200,
//       },
//       {
//         type: "progress",
//         label: "Adoption",
//         value: 78,
//       },
//     ],
//   },
//   {
//     title: "Business Value Realization",
//     items: [
//       {
//         type: "target",
//         label: "Benefits Realized",
//         current: "$120M",
//         target: "$200M",
//         value: 60,
//       },
//       {
//         type: "target",
//         label: "Cost Reduction",
//         current: "$50M",
//         target: "$80M",
//         value: 63,
//       },
//     ],
//   },
];

const getProgressColor = (value: number) => {
  if (value < 40) return "#DC2626";
  if (value <= 70) return "#F59E0B";
  return "#16A34A";
};

const renderTransformItem = (item: TransformItem) => {
  switch (item.type) {
    case "number":
      return (
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
        >
          <Typography
           sx={{
            fontSize: "9px",
            color: "#374151",
            fontWeight: 600,
        }}
          >
            {item.label}
          </Typography>

          <Typography
            sx={{
              fontSize: "9px",
              fontWeight: 600,
            //   color: "#111827",
            }}
          >
            {item.value}
          </Typography>
        </Stack>
      );

    case "progress":
      return (
        <Stack
          direction="row"
          alignItems="center"
          spacing={1}
        >
          <Typography
            sx={{
              width: 90,
              flexShrink: 0,
              fontSize: "9px",
              fontWeight: 600,
              color: "#374151",
            }}
          >
            {item.label}
          </Typography>

          <LinearProgress
            variant="determinate"
            value={item.value}
            sx={{
              flex: 1,
              height: 4,
              borderRadius: 5,
              bgcolor: "#E5E7EB",

              "& .MuiLinearProgress-bar": {
                borderRadius: 5,
                bgcolor: getProgressColor(item.value),
              },
            }}
          />

          <Typography
            sx={{
              minWidth: 32,
              textAlign: "right",
              fontSize: "9px",
              fontWeight: 700,
            //   color: getProgressColor(item.value),
            }}
          >
            {item.value}%
          </Typography>
        </Stack>
      );

    case "target":
      return (
        <Box>
          {/* Current / Target */}
          <Stack
      direction="row"
      justifyContent="space-between"
      alignItems="center"
      mb={0.5}
    >
      <Typography
        sx={{
            fontSize: "9px",
            color: "#374151",
            fontWeight: 600,
        }}
      >
        {item.label}
      </Typography>

      <Typography
        sx={{
          fontSize: "9px",
          fontWeight:600,
        //   color: "#111827",
        }}
      >
        {/* {item.current} / {item.target} */}
        {item.label !== "Breakthrough Business CAGR" ? `${item.current}/${item.target}` : `${item.current}${item.target}`}
      </Typography>
    </Stack>

          {/* Progress Row */}
          <Stack
      direction="row"
      alignItems="center"
      spacing={0.5}
    >
      <Typography
        sx={{
          width: 140,
          flexShrink: 0,
          fontSize: "11px",
          fontWeight: 500,
          color: "#374151",
        }}
      >
        {/* {item.progressLabel ?? "Progress"} */}
      </Typography>

      <LinearProgress
        variant="determinate"
        value={item.value}
        sx={{
          flex: 1,
          height: 4,
          borderRadius: 5,
          bgcolor: "#E5E7EB",

          "& .MuiLinearProgress-bar": {
            borderRadius: 5,
            bgcolor: getProgressColor(item.value),
          },
        }}
      />

      <Typography
        sx={{
        //   minWidth: 32,
          textAlign: "right",
          fontSize: "9px",
          fontWeight: 600,
        //   color: getProgressColor(item.value),
        }}
      >
        {item.value}%
      </Typography>
    </Stack>
        </Box>
      );

    default:
      return null;
  }
};

export default function TransformSection() {
  return (
    <Box sx={{ width: "100%" }}>
      {/* Header */}
      <Stack direction="row" spacing={0.5} alignItems="center">
        <Typography
          sx={{
            fontSize: "11px",
            fontWeight: 700,
            color: "#00838F",
            textTransform: "uppercase",
          }}
        >
          TRANSFORM
        </Typography>

        <Typography
          sx={{
            fontSize: "10px",
            fontWeight: 600,
            color: "#4B5563",
          }}
        >
          {/* (7 / 9) */}
        </Typography>
      </Stack>

      <Divider
        sx={{
          my: 0.5,
          borderBottomWidth: 1.5,
          borderColor: "#7C2D12",
        }}
      />

      <Stack spacing={0.75}>
        {transformData.map((section) => {
          const progressItems = section.items.filter(
            (item) =>
              item.type === "progress" ||
              item.type === "target"
          );

        //   const avgProgress =
        //     progressItems.length > 0
        //       ? progressItems.reduce(
        //           (sum, item) => sum + item.value,
        //           0
        //         ) / progressItems.length
        //       : 100;

          return (
            <Card
              key={section.title}
              elevation={0}
              sx={{
                border: "1px solid #E5E7EB",
                borderRadius: 1,
                p: 1,
              }}
            >
              <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="center"
                mb={1}
              >
                <Typography
                  sx={{
                    fontSize: "10px",
                    fontWeight: 700,
                    // color: "#111827",
                  }}
                >
                  {section.title}
                </Typography>

                <Box
                  sx={{
                    width: 7,
                    height: 7,
                    borderRadius: "50%",
                    // bgcolor: getProgressColor(avgProgress),
                  }}
                />
              </Stack>

              <Stack spacing={1.25}>
                {section.items.map((item, index) => (
                  <Box key={index}>
                    {renderTransformItem(item)}
                  </Box>
                ))}
              </Stack>
            </Card>
          );
        })}
      </Stack>
    </Box>
  );
}