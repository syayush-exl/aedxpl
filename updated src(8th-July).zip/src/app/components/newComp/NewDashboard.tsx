import { Box, Chip, Stack } from "@mui/material";

import PriorityMatrix from "./PriorityMatrix";
import TopCards from "./TopCards";
import Footer from "./Footer";

export default function NewDashboard() {
  return (
    <Box p={0.8} sx={{ background: "#fafafc" }}>
      <TopCards />
      <PriorityMatrix />
      <Footer />
    </Box>
  );
}
