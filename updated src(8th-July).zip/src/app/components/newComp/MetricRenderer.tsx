import { Box, LinearProgress, Typography } from "@mui/material";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import FlagIcon from "@mui/icons-material/Flag";
import PaidIcon from "@mui/icons-material/Paid";
import SpeedIcon from "@mui/icons-material/Speed";

import { Metric } from "../../data/pillarTypes";

interface Props {
  metric: Metric;
}

const getProgressColor = (value = 0) => {
  if (value >= 75) return "#16A34A";
  if (value >= 50) return "#F59E0B";
  return "#DC2626";
};

export default function MetricRenderer({ metric }: Props) {
  return (
    <Box
      sx={{
        p: 0.5,
        borderRadius: 1,
        border: "1px solid #E2E8F0",
        bgcolor: "#FFF",
        minHeight: 60,
      }}
    >
      <Typography
        sx={{
          fontSize: "9px",
          color: "#010035",
          fontWeight: 600,
          mb: 1,
          lineHeight: 1.2,
        }}
      >
        {metric.label}
      </Typography>

      {metric.type === "progress" && (
        <>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              mb: 0.75,
            }}
          >
            <Typography
              sx={{
                fontSize: "9px",
                color: "#383d5a",
                fontWeight: 600,
              }}
            >
              {metric.value}%
            </Typography>

            {/* <TrendingUpIcon
                sx={{
                  color: getProgressColor(metric.value),
                }}
              /> */}
          </Box>

          <LinearProgress
            variant="determinate"
            value={metric.value}
            sx={{
              flex: 1,
              height: 4,
              borderRadius: 5,
              bgcolor: "#E5E7EB",

              "& .MuiLinearProgress-bar": {
                borderRadius: 5,
                bgcolor: getProgressColor(metric.value),
              },
            }}
          />
        </>
      )}

      {metric.type === "score" && (
        <>
          <Typography
            sx={{
              fontSize: "9px",
              color: "#383d5a",
              mt: 0.75,
              fontWeight: 600,
            }}
          >
            {metric.value}
          </Typography>

          <Typography
            sx={{
              fontSize: "8px",
              color: "#16A34A",
              fontWeight: 600,
            }}
          >
            {metric.trend}
          </Typography>
        </>
      )}

      {metric.type === "number" && (
        <>
          <Typography
            sx={{
              fontSize: "9px",
              color: "#383d5a",
              fontWeight: 600,
            }}
          >
            {metric.value}
          </Typography>
        </>
      )}

      {metric.type === "milestone" && (
        <>
          {/* <FlagIcon
              sx={{
                color: "#7C3AED",
                mb: 0.5,
              }}
            /> */}

          <Typography
            sx={{
              fontSize: "9px",
              color: "#383d5a",
              fontWeight: 600,
            }}
          >
            {metric.current} / {metric.target}
          </Typography>

          <Typography
            sx={{
              fontSize: "9px",
              fontWeight: 600,
              color: "#383d5a",
            }}
          >
            {/* Completed */}
          </Typography>
        </>
      )}

      {metric.type === "currency" && (
        <>
          {/* <PaidIcon
              sx={{
                color: "#16A34A",
                mb: 0.5,
              }}
            /> */}

          <Typography
            sx={{
              fontSize: "9px",
              fontWeight: 600,
              color: "#383d5a",
            }}
          >
            Current: {metric.current}
          </Typography>

          <Typography
            sx={{
              fontSize: "9px",
              fontWeight: 600,
              color: "#383d5a",
            }}
          >
            Target {metric.target}
          </Typography>
        </>
      )}

      {metric.type === "currentTarget" && (
        <>
          {/* <SpeedIcon
              sx={{
                color: "#0891B2",
                mb: 1,
              }}
            /> */}

          <Typography
            sx={{
              fontSize: "9px",
              fontWeight: 600,
              color: "#383d5a",
            }}
          >
            Current: {metric.current}
          </Typography>

          <Typography
            sx={{
              color: "#383d5a",
              fontSize: "9px",
              fontWeight: 600,
            }}
          >
            Target: {metric.target}
          </Typography>
        </>
      )}
    </Box>
  );
}
