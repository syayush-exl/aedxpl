const ReCard=({title, children,className=""})=>{
    return (
        <div className={`bg-white rounded-sl shadow-xl p-6 h-full flex flex-col `}>
            <h2 className="text-lg font-semibold text-gray-800 mb-4 border-b pb-3">{title}</h2>
            <div className="flex-1 overflow-auto">
                {children}
            </div>
        </div>
    )
}

export default ReCard;