import {
    Card,
    Box,
    Typography,
  } from "@mui/material";
  
  import ScoreRing from "./ScoreRing";
  import HealthChip from "./HealthChip";
  import MetricRenderer from "./MetricRenderer";
  
  import { Initiative } from "../../data/pillarTypes";
  
  interface Props {
    initiative: Initiative;
  }
  
  export default function ReusableInitiativeCard({
    initiative,
  }: Props) {

    const getProgressColor = (value: string) => {
      if (value === "On Track") return "#18B96E";
      if (value === "Needs Attention") return "#f29900";
      return "#d93025";
    };

    return (
      <Card
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          borderRadius: 1,
          mb: 1,
          overflow: "hidden",
          transition: ".2s",
  
          // "&:hover": {
          //   boxShadow:
          //     "0 8px 20px rgba(0,0,0,.08)",
          // },
        }}
      >
        <Box
          sx={{
            p: "5px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
            gap: 1,
          }}
        >
          <Box flex={1}>
            <Typography
              sx={{
                fontSize: 11,
                fontWeight: 700,
                lineHeight: 1.3,
                color: "#010035"
                // mb: 1,
              }}
            >
              {initiative.name}
            </Typography>
  
            {/* <HealthChip
              health={initiative.health}
            /> */}
          </Box>
          <Box
            sx={{
              width: 7,
              height: 7,
              borderRadius: "50%",
              bgcolor: getProgressColor(initiative.health),
            }}
          />
  
          {/* <ScoreRing
            value={initiative.score}
          /> */}
        </Box>
  
        <Box
          sx={{
            p: 0.5,
            pt: 0,
            display: "grid",
            gridTemplateColumns:
              initiative.metrics.length >= 2
                ? `repeat(2, 1fr)`
                : "repeat(1,1fr)",
            gap: 0.5,
          }}
        >
          {initiative.metrics.map((metric) => (
            <MetricRenderer
              key={metric.id}
              metric={metric}
            />
          ))}
        </Box>
      </Card>
    );
  }