import {
  Box,
  Button,
  Card,
  CardContent,
  Typography,
  Stack,
  IconButton,
} from "@mui/material";
import GridViewRoundedIcon from "@mui/icons-material/GridViewRounded";
import ArrowForwardRoundedIcon from "@mui/icons-material/ArrowForwardRounded";
import { useNavigate } from "react-router-dom";
import { useTheme } from "../../theme-context";

export default function Footer() {
  const navigate = useNavigate();
  const { theme, toggle } = useTheme();

  return (
    <Box
      sx={{
        width: "100%",
        padding: "0 10px",
        background: "#fff",
        boxShadow: "none",
        borderRadius: "5px",
      }}
    >
      <Card
        elevation={0}
        sx={{
          margin: "10px 0 0",
          padding: "5px",
          border: "1px solid #E5E7EB",
          borderRadius: "5px",
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Stack direction="row" spacing={1} alignItems="center">
            <IconButton
              sx={{
                width: "fit-content",
                borderRadius: 2,
                bgcolor: "#d0271d",
                border: "1px solid #d7e7ff",
              }}
            >
              <GridViewRoundedIcon sx={{ color: "#ffffff" }} />
            </IconButton>

            <Box>
              <Typography fontWeight={700} fontSize={12} sx={{color: theme.textPrimary}}>
                Explore the full strategic portfolio
              </Typography>
              <Typography color="text.secondary" fontSize={8} sx={{color: theme.textTertiary}}>
                Dive deeper into initiatives across all towers.
              </Typography>
            </Box>
          </Stack>

          <Button
            variant="contained"
            endIcon={<ArrowForwardRoundedIcon />}
            onClick={() => navigate("/cockpit-view")}
            sx={{
              textTransform: "none",
              backgroundColor: "#fff",
              color: "#d0271d", 
              border: "2px solid #d0271d",
              // fontWeight: 600,
              fontSize: "14px",
              borderRadius: "5px",

              "& .MuiButton-startIcon": {
                color: "#d0271d",
              },

              "&:hover": {
                backgroundColor: "#ae2019",
                color: "#fff",
                // border: "none",
                borderColor: "#ae2019",

                "& .MuiButton-startIcon": {
                  color: "#fff",
                },
              },
            }}
          >
            Open Detailed View
          </Button>
        </Box>
      </Card>
    </Box>
  );
}
