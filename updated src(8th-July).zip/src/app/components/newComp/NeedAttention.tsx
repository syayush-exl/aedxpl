import React from "react";
import { Box, Card, Typography, Button, Stack } from "@mui/material";
import CloudUploadOutlinedIcon from "@mui/icons-material/CloudUploadOutlined";
import StorageOutlinedIcon from "@mui/icons-material/StorageOutlined";
import SecurityOutlinedIcon from "@mui/icons-material/SecurityOutlined";

import cardsData from "../../data/needAttention.json";

type InitiativeCard = {
  id: number;
  title: string;
  icon: string;
  pillar: string;
  tower: string;
  status: string;
  statusColor: string;
  decision: string;
  buttonText: string;
  leader: string;
};

const getIcon = (icon: string) => {
  switch (icon) {
    case "database":
      return <StorageOutlinedIcon sx={{ fontSize: 62, color: "#1E88E5" }} />;
    case "security":
      return <SecurityOutlinedIcon sx={{ fontSize: 62, color: "#1E88E5" }} />;
    default:
      return (
        <CloudUploadOutlinedIcon sx={{ fontSize: 68, color: "#1E88E5" }} />
      );
  }
};

const NeedAttention = () => {
  const data = cardsData as InitiativeCard[];

  return (
    <Box sx={{ maxWidth: 900, mx: "auto", p: 0.5 }}>
      <Stack spacing={2}>
        {data.map((item) => (
          <Card
            key={item.id}
            sx={{
              borderRadius: "10px",
              border: "1px solid #E5EEF7",
              //   boxShadow: "0 8px 24px rgba(30, 64, 175, 0.08)",
              overflow: "hidden",
              bgcolor: "#FDFEFF",
            }}
          >
            <Box sx={{ display: "flex", padding: "2px 5px", gap: 3 }}>
              <Box sx={{ flex: 1 }}>
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    width: "100%",
                  }}
                >
                  <Typography
                    sx={{
                      fontSize: 10,
                      fontWeight: 900,
                      color: "rgb(95, 99, 104)",
                      mb: 0.4,
                    }}
                  >
                    {item.title}
                  </Typography>

                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      gap: 1,
                    }}
                  >
                    <Typography
                      sx={{
                        fontSize: 10,
                        fontWeight: 800,
                        color: "rgb(95, 99, 104)",
                      }}
                    >
                      Status:
                    </Typography>

                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        gap: 0.5,
                      }}
                    >
                      <Box
                        sx={{
                          width: 8,
                          height: 8,
                          borderRadius: "50%",
                          bgcolor: item.statusColor,
                        }}
                      />

                      <Typography
                        sx={{
                          fontSize: 10,
                          fontWeight: 700,
                          color: item.statusColor,
                        }}
                      >
                        {item.status}
                      </Typography>
                    </Box>
                  </Box>
                </Box>

                <Typography
                  sx={{
                    fontSize: 9,
                    fontWeight: 500,
                    color: "#64748B",
                    mb: 0.5,
                  }}
                >
                  FAST Pillar:{" "}
                  <Box component="span" sx={{ fontWeight: 400 }}>
                    {item.pillar}
                  </Box>{" "}
                  | Tower:{" "}
                  <Box component="span" sx={{ fontWeight: 400 }}>
                    {item.tower}
                  </Box>
                </Typography>

                <Typography
                  sx={{
                    fontSize: 9,
                    fontWeight: 500,
                    color: "#64748B",
                    mb: 0.4,
                  }}
                >
                  Leader:{" "}
                  <Box component="span" sx={{ fontWeight: 400 }}>
                    {item.leader}
                  </Box>{" "}
                </Typography>
              </Box>
            </Box>

            <Box
              sx={{
                borderTop: "1px solid #E5EEF7",
                px: 1,
                py: 1,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: 2,
              }}
            >
              <Typography
                sx={{
                  fontSize: 9,
                  fontWeight: 700,
                  color: "rgb(95, 99, 104)",
                  lineHeight: 1.4,
                }}
              >
                Needs Attention:{" "}
                <Box component="span" sx={{ fontWeight: 400 }}>
                  {item.decision}
                </Box>
              </Typography>
            </Box>
          </Card>
        ))}
      </Stack>
    </Box>
  );
};

export default NeedAttention;
