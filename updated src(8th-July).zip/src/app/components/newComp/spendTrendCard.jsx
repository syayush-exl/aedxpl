import { Tooltip } from "@mui/material";
import { Bar, CartesianGrid, ComposedChart, LabelList, Line, ResponsiveContainer, XAxis, YAxis } from "recharts";
import ReCard from "./ReCard";

const data=[
    {year:"FY23", spend:711, growth:10.5},
    {year:"FY24", spend:766, growth:10.5},
    {year:"FY25", spend:832, growth:10.5},
    {year:"FY26", spend:959, growth:10.5},
    // {year:"FY26", spend:959, growth:10.5},
];

const SpendTrendCard=()=>{
    return (
        <ReCard title="TECHNOLOGY VENDOR SPEND TREND">
            <div className="flex items-center gap-2 mb-4 text-sm">
                <div className="flex items-center gap-1">
                <div className="w-3 h-3 bg-blue-800 rounded"></div>
                <span>Tech Vendor Spend ($M)</span>
                </div>

                <div className="flex items-center gap-1">
                    <div className="w-3 h-3 border-2 border-emerald-500 rounded-full"></div>
                    <span>YoY Growth (%)</span>
                </div>
            </div>

            <ResponsiveContainer width="100%" height={320}>
                <ComposedChart data={data} margin={{top:20, right:30,left:20,bottom:10}}> 
                    <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="year" fontSize={12}/>
                        <YAxis yAxisId="left" tickFormatter={(v)=>`$${v}M`} domain={[0,1200]} ticks={[0, 200, 400, 600, 800, 1000, 1200]} fontSize={12}/>
                        <YAxis yAxisId="right" orientation="right" domain={[0,12]} ticks={[3,6,9,12,15,18,21]} tickFormatter={(v)=>`${v}%`} fontSize={12}/>
                        <Tooltip />
                        <Bar yAxisId="left" dataKey="spend" fill="#1e40af" radius={[4,4,0,0]} name="Tech Vendor Spend ($M)" >
                            <LabelList dataKey="spend" position="top" formatter={(v)=>`$${v}M`} fill="#1e3a8a" fontWeight="bold" fontSize={12}/>
                        </Bar>

                        <Line yAxisId="right" type="monotone" dataKey="growth" stroke="#10b981" strokeWidth={3} dot={{fill:'#10b981', r:3, strokeWidth:2}} name="YoY Growth (%)"  >
                            <LabelList dataKey="growth" position="top" offset={8} formatter={(v)=>`${v}%`} fill="#10b981" fontWeight="600" fontSize={10}/>
                        </Line>
                </ComposedChart>
            </ResponsiveContainer>

            <div className="grid grid-cols-2 gap-6 mt-6">
                <div>
                    <div className="text-gray-500 text-sm">Current Trajectory</div>
                    <div className="font-bold text-2xl">10.5% CAGR</div>
                </div>
                <div className="text-right">
                    <div className="text-gray-500 text-sm">Strategic Target</div>
                    <div className="font-bold text-2xl text-emerald-600">4% CAGR</div>
                </div>
            </div>
            <p className="text-sm text-gray-600 mt-4">
            Reduce technology spend growth from 10.5% CAGR to 4% CAGR through spend optimization, vendor consolidation, contract intelligence, and governance controls, enabling reinvestment in strategic innovation initiatives.
            </p>
        </ReCard>
    )
}

export default SpendTrendCard;