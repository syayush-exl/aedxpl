import { Card, Chip, Typography, Stack, Box, Tooltip } from "@mui/material";
import WarningIcon from "@mui/icons-material/Warning";
import { Initiative } from "../../data/types";
import CommentIcon from "@mui/icons-material/Comment";
import { useTheme } from "../../theme-context";
import { useNavigate } from "react-router-dom";

import React from "react";

const towerColors = {
  Focus: "rgb(26, 115, 232)",
  Accelerate: "rgb(123, 31, 162)",
  Scale: "rgb(0, 151, 167)",
  Transform: "rgb(230, 81, 0)",
};

const towerBorders = {
  Focus: "1px solid rgba(26, 115, 232, 0.25)",
  Accelerate: "1px solid rgba(123, 31, 162, 0.25)",
  Scale: "1px solid rgba(0, 151, 167, 0.25)",
  Transform: "1px solid rgba(230, 81, 0, 0.25)",
};

const towerBGColors = {
  Focus: "rgba(26, 115, 232, 0.082)",
  Accelerate: "rgba(123, 31, 162, 0.082)",
  Scale: "rgba(0, 151, 167, 0.082)",
  Transform: "rgba(230, 81, 0, 0.082)",
};

interface Props {
  initiative: Initiative;
  selectedTowers: [];
}

export function InitiativeCard({
  initiative,
  selectedStatus,
  selectedTowers,
  selectedPriorities,
}: Props) {
  console.log("InitiativeCard called")
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();
  const getStatusColor = (status: string) => {
    switch (status) {
      case "On Track":
        return theme.onTrack;
      case "Needs Attention":
        return theme.attention;
      case "Off Track":
        return theme.offTrack;
      case "Null Track":
        return "#767a8191";
      default:
        return "#000"; // Not Started
    }
  };
  console.log("initiative.status: "+initiative.status)

  const showData = !selectedStatus || initiative.status === selectedStatus;
  const showOnlyFilteredTower = selectedTowers.includes(initiative.towerTeam);
  return (
    <>
      {/* {initiative.hasdata === true && showData && showOnlyFilteredTower ? ( */}
      <Stack
        direction="row"
        onClick={() => {
          if (initiative.name === "Cloud Migration") {
            navigate("/deep-dive");
          }
          if (initiative.name === "GPT Global Delivery Model") {
            navigate("/gpt-deep-dive");
          }
          if (initiative.name === "Tech Ecosystem & Spend Management") {
            navigate("/tesm-deep-dive");
          }
          if (initiative.name === "Risk and Resiliency") {
            navigate("/risk-deep-dive");
          }
          if (initiative.name === "IAM") {
            navigate("/iam-deep-dive");
          } if (initiative.name === "Develop AI-Centric (BU) Roadmaps") {
            navigate("/ai-deep-dive");
          }
          if (initiative.name === "Stakeholder Excellence") {
            navigate("/stakeholder-deep-dive");
          }               
        }}
        sx={{
          minHeight: 30,
          maxHeight: 60,
          borderRadius: 1,
          overflow: "hidden",
          border: "1px solid rgba(0,0,0,0.12)",
          bgcolor: "#fff",
          cursor: ["Cloud Migration", "GPT Global Delivery Model", "Tech Ecosystem & Spend Management", "Risk and Resiliency", "IAM", "Develop AI-Centric (BU) Roadmaps", "Stakeholder Excellence"].includes(initiative.name) ? "pointer" : "default",
          "&:hover": {
            boxShadow:
            ["Cloud Migration", "GPT Global Delivery Model", "Tech Ecosystem & Spend Management", "Risk and Resiliency", "IAM", "Develop AI-Centric (BU) Roadmaps", "Stakeholder Excellence"].includes(initiative.name)
                ? "0 2px 8px rgba(0,0,0,0.12)"
                : "none",
          },
        }}
      >
        {/* ---------- NA CARD ---------- */}
        {!initiative ? (
          <Box
            sx={{
              flex: 1,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Typography
              sx={{
                fontSize: 11,
                fontWeight: 600,
                color: theme.textTertiary,
              }}
            >
              NA
            </Typography>
          </Box>
        ) : (
          <>
            {/* Content */}
            <Box
              sx={{
                flex: 1,
                padding: "4px 8px",
                display: "flex",
                flexDirection: "column",
                justifyContent: "start",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "start",
                  gap: 0.5,
                  width: "100%",
                }}
              >
                <Typography
                  variant="subtitle2"
                  sx={{
                    fontWeight: 600,
                    fontSize: "10px",
                    lineHeight: 1.4,
                    mb: 1.5,
                    color: theme.textPrimary,
                  }}
                >
                  {initiative.name}
                </Typography>

                {/* {initiative.error && (
                  <Tooltip
                    title="Immediate attention required"
                    arrow
                    slotProps={{
                      tooltip: {
                        sx: {
                          fontSize: "8px",
                        },
                      },
                    }}
                  >
                    <WarningIcon
                      sx={{
                        color: "#ef4444",
                        fontSize: 17,
                        cursor: "pointer",
                        flexShrink: 0,
                      }}
                    />
                  </Tooltip>
                )} */}
              </Box>

              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  width: "100%",
                }}
              >
                <Typography
                  variant="caption"
                  sx={{
                    fontSize: "9px",
                    color: theme.textTertiary,
                  }}
                >
                  {/* Leader: {initiative.owner} */}
                </Typography>

                <CommentIcon sx={{ fontSize: 16 }} />
              </Box>
            </Box>

            {/* Status Border */}
            <Box
              sx={{
                width: 6,
                bgcolor: getStatusColor(initiative.status),
 
              }}
            />
          </>
        )}
      </Stack>
    </>
  );
}

export default React.memo(InitiativeCard);
