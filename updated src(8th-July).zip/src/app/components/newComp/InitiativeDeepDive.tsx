import { useParams } from "react-router-dom";

const InitiativeDeepDive = () => {
  const { initiativeName } = useParams();

  return (
    <div
      style={{
        padding: "24px",
      }}
    >
      <h1>Initiative Details</h1>

      <p>
        Selected Initiative:
        <strong> {decodeURIComponent(initiativeName || "")}</strong>
      </p>
    </div>
  );
};

export default InitiativeDeepDive;