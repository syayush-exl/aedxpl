import {
    Box,
    Card,
    Divider,
    LinearProgress,
    Stack,
    Typography,
  } from "@mui/material";
  
  const scaleData = [
    {
      title: "Breakthrough Revenue",
      items: [
        {
            label: "Breakthrough Revenue Growth",
            current: "$464M",
            target: "$802M",
            value: 61,
          },
          {
            label: "Breakthrough Business CAGR",
            current: "30%",
            target: " (>20%)",
            value: 30,
          },
        {
          label: "Marketplace Revenue Growth",
          current: "$98M",
          target: "$206M",
          value: 48,
        },
        
        {
          label: "Data solutions Revenue Growth",
          current: "$364M",
          target: "$503M",
          value: 69,
        },
        {
            label: "Ventures Revenue Growth",
            current: "$20M",
            target: "$73M",
            value: 27,
          },          

      ],
    },
    // {
    //   title: "Marketplace Growth",
    //   items: [
    //     {
    //       label: "GMV",
    //       current: "$108M",
    //       target: "$180M",
    //       value: 60,
    //     },
    //   ],
    // },
  ];
  
  const getProgressColor = (value: number) => {
    if (value < 40) return "#DC2626";
    if (value <= 70) return "#F59E0B";
    return "#16A34A";
  };
  
  export default function ScaleSection() {
    return (
      <Box sx={{ width: "100%" }}>
        {/* Header */}
        <Stack direction="row" spacing={0.5} alignItems="center">
          <Typography
            sx={{
              fontSize: "11px",
              fontWeight: 700,
              color: "#00838F",
              textTransform: "uppercase",
            }}
          >
            SCALE
          </Typography>
  
          <Typography
            sx={{
              fontSize: "10px",
              fontWeight: 600,
              color: "#4B5563",
            }}
          >
            {/* (0 / 3) */}
          </Typography>
        </Stack>
  
        <Divider
          sx={{
            my: 0.5,
            borderBottomWidth: 1.5,
            borderColor: "#00838F",
          }}
        />
  
        <Stack spacing={0.75}>
                {scaleData.map((section) => {
                    const avgProgress =
                        section.items.reduce((sum, item) => sum + item.value, 0) /
                        section.items.length;

                    return (
                        <Card
                            key={section.title}
                            elevation={0}
                            sx={{
                                border: "1px solid #E5E7EB",
                                borderRadius: 1,
                                p: 1,
                            }}
                        >
                            {/* Card Header */}
                            <Stack
                                direction="row"
                                justifyContent="space-between"
                                alignItems="center"
                                mb={1.5}
                            >
                                <Typography
                                    sx={{
                                        fontSize: "10px",
                                        fontWeight: 700,
                                    }}
                                >
                                    {section.title}
                                </Typography>

                                <Box
                                    sx={{
                                        width: 7,
                                        height: 7,
                                        borderRadius: "50%",
                                        bgcolor: getProgressColor(avgProgress),
                                    }}
                                />
                            </Stack>

                            {section.items.map((item, index) => (
  <Box
    key={`${item.label}-${index}`}
    sx={{
      mb: index !== section.items.length - 1 ? 3 : 0,
    }}
  >
    {/* Current / Target */}
    <Stack
      direction="row"
      justifyContent="space-between"
      alignItems="center"
      mb={0.5}
    >
      <Typography
        sx={{
            fontSize: "9px",
            color: "#374151",
            fontWeight: 600,
        }}
      >
        {item.label}
      </Typography>

      <Typography
        sx={{
          fontSize: "9px",
          fontWeight:600,
        //   color: "#111827",
        }}
      >
        {/* {item.current} / {item.target} */}
        {item.label !== "Breakthrough Business CAGR" ? `${item.current}/${item.target}` : `${item.current}${item.target}`}
      </Typography>
    </Stack>

    {/* Label + Progress + % */}
    <Stack
      direction="row"
      alignItems="center"
      spacing={0.5}
    >
      <Typography
        sx={{
          width: 140,
          flexShrink: 0,
          fontSize: "11px",
          fontWeight: 500,
          color: "#374151",
        }}
      >
        {/* {item.progressLabel ?? "Progress"} */}
      </Typography>

      <LinearProgress
        variant="determinate"
        value={item.value}
        sx={{
          flex: 1,
          height: 4,
          borderRadius: 5,
          bgcolor: "#E5E7EB",

          "& .MuiLinearProgress-bar": {
            borderRadius: 5,
            bgcolor: getProgressColor(item.value),
          },
        }}
      />

      <Typography
        sx={{
        //   minWidth: 32,
          textAlign: "right",
          fontSize: "9px",
          fontWeight: 600,
        //   color: getProgressColor(item.value),
        }}
      >
        {item.value}%
      </Typography>
    </Stack>
  </Box>
))}
                        </Card>
                    );
                })}
        </Stack>
      </Box>
    );
  }