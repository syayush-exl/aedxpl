import { Outlet } from "react-router-dom";
import DashboardHeader from "./DashboardHeader";

export default function MainLayout() {
  return (
    <>
      <DashboardHeader />

      <Outlet />
    </>
  );
}
