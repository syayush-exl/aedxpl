import { Box } from "@mui/material";
import { useParams } from "react-router-dom";

import BreadcrumbsNav from "../deepDive/BreadcrumbsNav";
import InitiativeHeader from "../deepDive/InitiativeHeader";
import KpiSummarySection from "../deepDive/KpiSummarySection";

const GPTGlobalDeliveryModel = () => {
    const { initiativeName } = useParams();
  return (
      <Box
          sx={{
              background: "#F8FAFC",
              minHeight: "100vh",
              p: {
                  xs: 1.5,
                  md: 2,
              },
              maxWidth: "1800px",
              mx: "auto",
          }}
      >
      <BreadcrumbsNav />

      <InitiativeHeader />

      <KpiSummarySection />
    </Box>
  );
};

export default GPTGlobalDeliveryModel;