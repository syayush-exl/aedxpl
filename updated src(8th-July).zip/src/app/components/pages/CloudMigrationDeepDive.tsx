import React from "react";
import {
  Avatar,
  Box,
  Breadcrumbs,
  Button,
  Card,
  Chip,
  Divider,
  Grid,
  LinearProgress,
  Stack,
  Typography,
  Paper,
  CardContent,
  IconButton,
} from "@mui/material";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import ShareOutlinedIcon from "@mui/icons-material/ShareOutlined";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import InsertDriveFileOutlinedIcon from "@mui/icons-material/InsertDriveFileOutlined";
import AssessmentOutlinedIcon from "@mui/icons-material/AssessmentOutlined";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  LabelList,
  BarChart,
  Bar,
  Legend,
  ReferenceLine,
} from "recharts";

import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import CloudOutlinedIcon from "@mui/icons-material/CloudOutlined";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import DashboardCustomizeOutlinedIcon from "@mui/icons-material/DashboardCustomizeOutlined";
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import FlagOutlinedIcon from "@mui/icons-material/FlagOutlined";
import MonitorHeartOutlinedIcon from "@mui/icons-material/MonitorHeartOutlined";

import AppsOutlinedIcon from "@mui/icons-material/AppsOutlined";
import CloudDoneOutlinedIcon from "@mui/icons-material/CloudDoneOutlined";
import ApartmentOutlinedIcon from "@mui/icons-material/ApartmentOutlined";
import CheckCircleOutlineOutlinedIcon from "@mui/icons-material/CheckCircleOutlineOutlined";
import AccessTimeOutlinedIcon from "@mui/icons-material/AccessTimeOutlined";

import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import DoneIcon from "@mui/icons-material/Done";
import chart from "../../data/migrationProgress.json";
import { useTheme } from "../../theme-context";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useNavigate } from "react-router-dom";

const kpis = [
  {
    title: "Total Applications",
    value: "1,094",
    subtitle: "Across 18 DCs",
    color: "#0A2E78",
    icon: <AppsOutlinedIcon sx={{ fontSize: 16 }} />,
  },
  {
    title: "Applications Migrated",
    value: "280",
    subtitle: "26% of total",
    color: "#0A2E78",
    icon: <CloudDoneOutlinedIcon sx={{ fontSize: 16 }} />,
  },
  {
    title: "Active Data Centers",
    value: "18",
    subtitle: "On Track",
    color: "#0A2E78",
    icon: <ApartmentOutlinedIcon sx={{ fontSize: 16 }} />,
  },
  {
    title: "Overall Migration Completion",
    value: "16%",
    subtitle: "Achieved by June 2026",
    color: "#0A2E78",
    icon: <CheckCircleOutlineOutlinedIcon sx={{ fontSize: 16 }} />,
  },
];

const labelStyle = {
  fontSize: "12px",
  fontWeight: 700,
  color: "#0A2E78",
};

const valueStyle = {
  fontSize: "42px",
  fontWeight: 700,
  color: "#0A2E78",
};

const migrationProgressData = [
  { month: "Q1", planned: 20, actual: 16 },
  { month: "Q2", planned: 35, actual: 28 },
  { month: "Q3", planned: 50, actual: 42 },
  { month: "Q4", planned: 70, actual: 60 },
  { month: "Q5", planned: 90, actual: 80 },
];

const buData = [
  {
    name: "Commercial",
    completed: 70,
    inProgress: 20,
    pending: 10,
  },
  {
    name: "Consumer",
    completed: 55,
    inProgress: 25,
    pending: 20,
  },
  {
    name: "Finance",
    completed: 40,
    inProgress: 30,
    pending: 30,
  },
  {
    name: "Operations",
    completed: 65,
    inProgress: 20,
    pending: 15,
  },
];
const buRows = [
  {
    bu: "GETS",
    total: 500,
    red: 90,
    purple: 40,
    green: 50,
    gray: 90,
    blue: 20,
    pct: "14%",
  },
  {
    bu: "ESI",
    total: 210,
    red: 25,
    purple: 20,
    green: 40,
    gray: 70,
    blue: 25,
    pct: "19%",
  },
  {
    bu: "Nationals",
    total: 80,
    red: 40,
    purple: 10,
    green: 15,
    gray: 15,
    blue: 0,
    pct: "13%",
  },
  {
    bu: "Major & Canada",
    total: 70,
    red: 35,
    purple: 10,
    green: 10,
    gray: 15,
    blue: 0,
    pct: "21%",
  },
  {
    bu: "SR/MRFS",
    total: 60,
    red: 25,
    purple: 10,
    green: 5,
    gray: 10,
    blue: 10,
    pct: "8%",
  },
];
const milestones = [
  {
    milestone: "Initial Application Migration",
    target: "Jun 2026",
    status: "Completed",
  },
  {
    milestone: "Migration Pipeline Established",
    target: "Jun 2026",
    status: "Completed",
  },
  {
    milestone: "Migration Factory Setup",
    target: "Dec 2026",
    status: "In Progress",
  },
  {
    milestone: "Regional Migration Model",
    target: "Jan 2027",
    status: "Planned",
  },
  {
    milestone: "FinOps Implementation",
    target: "Sep 2027",
    status: "Planned",
  },
];

const risks = [
  {
    risk: "Legacy application dependencies",
    impact: "High",
    status: "Red",
    mitigation: "Dependency mapping & refactor plan",
  },
  {
    risk: "Application readiness delays",
    impact: "Medium",
    status: "Amber",
    mitigation: "Accelerated assessment",
  },
  {
    risk: "Resource constraints in BU teams",
    impact: "Medium",
    status: "Amber",
    mitigation: "Additional teams & capacity",
  },
  {
    risk: "Data migration complexity",
    impact: "Medium",
    status: "Green",
    mitigation: "Automation tooling",
  },
];
const documents = [
  {
    icon: "📊",
    title: "Cloud Migration\nStrategy (PPT)",
  },
  {
    icon: "📗",
    title: "Application Inventory\n(XLSX)",
  },
  {
    icon: "📈",
    title: "Migration Factory\nDashboard",
  },
  {
    icon: "📘",
    title: "FinOps Assessment\n(DOCX)",
  },
  {
    icon: "📕",
    title: "Architecture Review\n(PDF)",
  },
  {
    icon: "🟢",
    title: "Steering Committee\nNotes",
  },
  {
    icon: "📄",
    title: "RAID Log",
  },
];

const BLUE = "#1565FF";
const GREEN = "#0CA44B";

const CustomTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;

  return (
    <div className="tooltip">
      <div>{payload[0]?.payload.month}</div>

      {payload.map((item: any) => (
        <div key={item.dataKey}>
          {item.name}: {item.value}%
        </div>
      ))}
    </div>
  );
};

/* ===================== CONFIG ===================== */
const statusConfig = {
  Completed: { color: "#16A34A", type: "filled" },
  "In Progress": { color: "#F59E0B", type: "outlined" },
  Planned: { color: "#2563EB", type: "outlined" },
};

const impactConfig = {
  High: "#DC2626",
  Medium: "#F59E0B",
  Low: "#2563EB",
};

/* ===================== STATUS BADGE ===================== */
const StatusBadge = ({ value }) => {
  const config = statusConfig[value] || { color: "#0A2E78" };

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
      <Box
        sx={{
          width: 10,
          height: 10,
          borderRadius: "50%",
          border:
            config.type === "outlined" ? `2px solid ${config.color}` : "none",
          backgroundColor:
            config.type === "filled" ? config.color : "transparent",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {config.type === "filled" && (
          <Typography sx={{ fontSize: 8, color: "#fff", lineHeight: 1 }}>
            ✓
          </Typography>
        )}
      </Box>

      <Typography sx={{ fontSize: 10, color: "#0A2E78" }}>{value}</Typography>
    </Box>
  );
};

/* ===================== IMPACT BADGE ===================== */
const ImpactBadge = ({ value }) => {
  const color = impactConfig[value] || "#0A2E78";

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
      <Typography sx={{ fontSize: 10, color }}>{value}</Typography>
    </Box>
  );
};

const statusColorMap = {
  Red: "#DC2626",
  Amber: "#F59E0B",
  Green: "#16A34A",
};

const StatusDotText = ({ value }) => {
  const color = statusColorMap[value] || "#0A2E78";

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.6 }}>
      {/* dot */}
      <Box
        sx={{
          width: 8,
          height: 8,
          borderRadius: "50%",
          backgroundColor: color,
        }}
      />

      {/* text */}
      <Typography
        sx={{
          fontSize: 10,
          fontWeight: 600,
          color: color,
          lineHeight: 1,
        }}
      >
        {value}
      </Typography>
    </Box>
  );
};

export default function CloudMigrationDeepDive() {
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();
  return (
    <Box
      sx={{
        width: "100%",
        bgcolor: "#F5F7FB",
        px: 1.5,
        py: 1,
      }}
    >
      {/* ================================= */}
      {/* BREADCRUMB */}
      {/* ================================= */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          mb: "10px",
          alignItems: "center",
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Breadcrumbs
            separator={<NavigateNextIcon fontSize="small" />}
            sx={{
              // mb: 1,
              fontSize: 13,
            }}
          >
            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 600,
                color: "#0A2E78",
              }}
            >
              Initiatives
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 600,
                color: "#0A2E78",
              }}
            >
              Cloud Migration
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 700,
                color: "#0A2E78",
              }}
            >
              Deep Dive
            </Typography>
          </Breadcrumbs>

          <IconButton
            onClick={() => navigate("/")}
            size="small"
            sx={{
              color: "#0A2E78",
              marginLeft: "10px",
              fontSize: "5px",
            }}
          >
            <ArrowBackIcon fontSize="small" />
          </IconButton>
        </Box>

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            textAlign: "center",
            alignContent: "center",
          }}
        >
          <div
            style={{
              padding: "5px 10px",
              background: theme.tableHeaderBg,
              borderRadius: 6,
              color: "#ffffff",
              fontSize: 11,
              fontFamily: "var(--font-mono)",
              border: `1px solid ${theme.chipActiveBorder}`,
              fontWeight: 500,
            }}
          >
            Live ·{" "}
            {new Date().toLocaleDateString("en-US", {
              month: "short",
              day: "numeric",
              year: "numeric",
            })}
          </div>
        </Box>
      </Box>

      {/* ================================= */}
      {/* HEADER */}
      {/* ================================= */}
      <Card
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          borderRadius: 1.5,
          px: 1.5,
          py: 0.75,
          mb: 1,
        }}
      >
        <Grid container alignItems="center">
          <Grid size={{ xs: 12, md: 8 }}>
            <Stack direction="row" spacing={1.5} alignItems="center">
              <Avatar
                sx={{
                  width: 32,
                  height: 32,
                  bgcolor: "#0A2E78",
                }}
              >
                <CloudOutlinedIcon sx={{ fontSize: 18 }} />
              </Avatar>

              <Box>
                <Stack direction="row" spacing={1} alignItems="center">
                  <Typography
                    sx={{
                      fontSize: 16,
                      fontWeight: 700,
                      color: "#0A2E78",
                      lineHeight: 1,
                    }}
                  >
                    Cloud Migration
                  </Typography>

                  <Chip
                    label=""
                    size="small"
                    sx={{
                      bgcolor: "#F4A622",
                      color: "#000",
                      fontWeight: 700,
                      height: 22,
                      width: 22,
                      fontSize: 10,
                    }}
                  />
                </Stack>

                <Typography
                  sx={{
                    fontSize: 10,
                    mt: 0.25,
                    color: "#475569",
                    lineHeight: 1.3,
                    maxWidth: "100%",
                  }}
                >
                  Migrating applications, infrastructure and data from legacy
                  data centers to cloud to improve scalability, reduce costs and
                  enhance performance.
                </Typography>
              </Box>
            </Stack>
          </Grid>

          <Grid size={{ xs: 12, md: 4 }}>
            <Stack
              direction="row"
              spacing={1}
              justifyContent="flex-end"
              alignItems="center"
            >
              <Button
                variant="outlined"
                startIcon={<ShareOutlinedIcon sx={{ fontSize: 14 }} />}
                size="small"
                sx={{
                  minWidth: 75,
                  height: 28,
                  fontSize: 11,
                  textTransform: "none",
                  px: 1,
                }}
              >
                Share
              </Button>

              <Button
                variant="outlined"
                startIcon={<DownloadOutlinedIcon sx={{ fontSize: 14 }} />}
                size="small"
                sx={{
                  minWidth: 80,
                  height: 28,
                  fontSize: 11,
                  textTransform: "none",
                  px: 1,
                }}
              >
                Export
              </Button>
            </Stack>
          </Grid>
        </Grid>
      </Card>

      {/* ================================= */}
      {/* SUMMARY CARD */}
      {/* ================================= */}

      <Card
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          borderRadius: 1.5,
          px: 1.5,
          //    py: 1,
          mb: 1,
        }}
      >
        <Grid
          container
          wrap="nowrap"
          alignItems="start"
          sx={{
            minHeight: 70,
            columnGap: 0,
            width: "100%",
            padding: "10px 5px",
          }}
        >
          {/* Initiative Owner */}
          <Grid
            size={{ xs: 12 }}
            sx={{
              flex: 0.88,
              minWidth: 0,
            }}
          >
            <Stack spacing={0.2}>
              <Stack direction="row" spacing={0.5} alignItems="start">
                <PersonOutlineIcon color="primary" sx={{ fontSize: 16 }} />
                <Typography sx={labelStyle}>Initiative Owner</Typography>
              </Stack>

              <Typography
                sx={{
                  fontSize: 12,
                  fontWeight: 700,
                  paddingLeft: "20px",
                }}
              >
                Prakash
              </Typography>

              <Typography
                sx={{
                  fontSize: 10,
                  color: "text.secondary",
                }}
              ></Typography>
            </Stack>
          </Grid>

          {/* Pillar */}
          <Grid
            size={{ xs: 12 }}
            sx={{
              flex: 0.8,
              minWidth: 0,
              display: "flex",
              alignItems: "stretch",
              gap: 1,
            }}
          >
            <Divider
              orientation="vertical"
              flexItem
              sx={{
                borderColor: "rgba(0,0,0,0.15)",
                alignSelf: "stretch",
              }}
            />

            <Stack spacing={0.2}>
              <Stack direction="row" spacing={0.5} alignItems="center">
                <DashboardCustomizeOutlinedIcon
                  color="primary"
                  sx={{ fontSize: 16 }}
                />
                <Typography sx={labelStyle}>FAST Pillar</Typography>
              </Stack>

              <Typography
                sx={{
                  fontSize: 12,
                  fontWeight: 700,
                  paddingLeft: "20px",
                }}
              >
                Transform
              </Typography>

              <Typography
                sx={{
                  fontSize: 10,
                  color: "text.secondary",
                }}
              >
                {"\u00A0"}
              </Typography>
            </Stack>
          </Grid>

          {/* Timeline */}
          <Grid
            size={{ xs: 12 }}
            sx={{
              flex: 0.9,
              minWidth: 0,
              display: "flex",
              alignItems: "center",
              gap: 1,
            }}
          >
            <Divider
              orientation="vertical"
              flexItem
              sx={{
                borderColor: "rgba(0,0,0,0.15)",
              }}
            />

            <Stack spacing={0.25}>
              <Stack direction="row" spacing={0.5} alignItems="center">
                <CalendarMonthOutlinedIcon
                  color="primary"
                  sx={{ fontSize: 16 }}
                />
                <Typography sx={labelStyle}>Timeline</Typography>
              </Stack>

              <Typography
                sx={{
                  fontSize: 12,
                  fontWeight: 700,
                  paddingLeft: "20px",
                }}
              >
                FY26 - FY29
              </Typography>

              <Typography
                sx={{
                  fontSize: 10,
                  color: "text.secondary",
                  paddingLeft: "20px",
                }}
              >
                (4 Year Program)
              </Typography>
            </Stack>
          </Grid>

          {/* Current Phase */}
          <Grid
            size={{ xs: 12 }}
            sx={{
              flex: 0.9,
              minWidth: 0,
              display: "flex",
              alignItems: "center",
              gap: 1,
            }}
          >
            <Divider
              orientation="vertical"
              flexItem
              sx={{
                borderColor: "rgba(0,0,0,0.15)",
              }}
            />

            <Stack spacing={0.25}>
              <Stack direction="row" spacing={0.5} alignItems="center">
                <FlagOutlinedIcon color="primary" sx={{ fontSize: 16 }} />
                <Typography sx={labelStyle}>Current Phase</Typography>
              </Stack>

              <Typography
                sx={{
                  fontSize: 12,
                  fontWeight: 700,
                  paddingLeft: "20px",
                }}
              >
                FY27
              </Typography>

              <Typography
                sx={{
                  fontSize: 10,
                  color: "text.secondary",
                  paddingLeft: "20px",
                }}
              >
                Foundation Phase
              </Typography>
            </Stack>
          </Grid>

          {/* Health */}
          <Grid
            size={{ xs: 12 }}
            sx={{
              flex: 0.8,
              minWidth: 0,
              display: "flex",
              alignItems: "center",
              gap: 1,
            }}
          >
            <Divider
              orientation="vertical"
              flexItem
              sx={{
                borderColor: "rgba(0,0,0,0.15)",
              }}
            />

            <Stack spacing={0.25}>
              <Stack direction="row" spacing={0.5} alignItems="center">
                <MonitorHeartOutlinedIcon
                  color="primary"
                  sx={{ fontSize: 16 }}
                />
                <Typography sx={labelStyle}>Overall Health</Typography>
              </Stack>

              <Typography
                sx={{
                  fontSize: 24,
                  fontWeight: 700,
                  color: "#F4A622",
                  lineHeight: 1,
                  paddingLeft: "20px",
                }}
              >
                ●
              </Typography>
            </Stack>
          </Grid>

          {/* Key Takeaway */}
          <Grid
            size={{ xs: 12 }}
            sx={{
              flex: 3.5,
              minWidth: 0,
              display: "flex",
              alignItems: "center",
              gap: 1,
            }}
          >
            <Divider
              orientation="vertical"
              flexItem
              sx={{
                borderColor: "rgba(0,0,0,0.15)",
              }}
            />

            <Stack spacing={0.25}>
              <Typography sx={labelStyle}>Key Takeaway</Typography>

              <Typography
                sx={{
                  fontSize: 11,
                  color: "#383d5a",
                  lineHeight: 1.25,
                }}
              >
                Program is the Foundation Phase FY26. Migration factories and
                tooling are established. Application migration is on track,
                while decommissioning has items at risk.
              </Typography>
            </Stack>
          </Grid>
        </Grid>
      </Card>

      {/* ================================= */}
      {/* KPI ROW */}
      {/* ================================= */}

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr 1fr 1.2fr 2fr",
          gap: 1,
          mt: 1,
        }}
      >
        {kpis.map((item) => (
          <Card
            key={item.title}
            elevation={0}
            sx={{
              border: "1px solid #E2E8F0",
              borderRadius: 1.5,
              height: 92,
              px: 1.5,
              py: 1,
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
            }}
          >
            <Stack direction="row" spacing={1} alignItems="center">
              <Avatar
                sx={{
                  width: 24,
                  height: 24,
                  bgcolor: "#F4F7FC",
                  color: item.color,
                }}
              >
                {item.icon}
              </Avatar>

              <Typography
                sx={{
                  fontSize: 12,
                  fontWeight: 700,
                  lineHeight: 1.2,
                  color: "#0A2E78",
                }}
              >
                {item.title}
              </Typography>
            </Stack>

            <Typography
              sx={{
                fontSize: 22,
                fontWeight: 700,
                color: item.color,
                lineHeight: 1,
                marginLeft: "30px",
              }}
            >
              {item.value}
            </Typography>

            <Typography
              sx={{
                fontSize: 10,
                color: "#64748B",
                marginLeft: "30px",
              }}
            >
              {item.subtitle}
            </Typography>
          </Card>
        ))}
        <Card
          elevation={0}
          sx={{
            border: "1px solid #E2E8F0",
            borderRadius: 1.5,
            height: 92,
            px: 1.5,
            py: 1,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
          }}
        >
          {/* Header */}
          <Stack direction="row" spacing={1} alignItems="center">
            <Avatar
              sx={{
                width: 24,
                height: 24,
                bgcolor: "#F4F7FC",
                color: "#16A34A",
              }}
            >
              <AccessTimeOutlinedIcon sx={{ fontSize: 16 }} />
            </Avatar>

            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Typography
                sx={{
                  fontSize: 12,
                  fontWeight: 600,
                  lineHeight: 1.2,
                  color: "#0A2E78",
                }}
              >
                Migration Adherence
              </Typography>

              <Typography
                sx={{
                  fontSize: 9,
                  color: "#64748B",
                  lineHeight: 1,
                  marginLeft: "10px",
                }}
              >
                (Planned vs Actual)
              </Typography>
            </Box>
          </Stack>

          {/* Planned */}
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <Typography fontSize={10} color="#0A2E78" sx={{ minWidth: 50 }}>
              Planned
            </Typography>

            <LinearProgress
              variant="determinate"
              value={20}
              sx={{
                flex: 1,
                height: 6,
                borderRadius: 10,
                bgcolor: "#E5EAF2",
                "& .MuiLinearProgress-bar": {
                  backgroundColor: "#0A2E78",
                },
              }}
            />

            <Typography
              fontSize={10}
              fontWeight={700}
              color="#0A2E78"
              sx={{ minWidth: 30, textAlign: "right" }}
            >
              20%
            </Typography>
          </Box>

          {/* Achieved */}
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <Typography fontSize={10} color="#64748B" sx={{ minWidth: 50 }}>
              Achieved
            </Typography>

            <LinearProgress
              variant="determinate"
              value={16}
              sx={{
                flex: 1,
                height: 6,
                borderRadius: 10,
                bgcolor: "#E5EAF2",
                "& .MuiLinearProgress-bar": {
                  backgroundColor: "green",
                },
              }}
            />

            <Typography
              fontSize={10}
              fontWeight={700}
              color="#16A34A"
              sx={{ minWidth: 30, textAlign: "right" }}
            >
              16%
            </Typography>
          </Box>
        </Card>
      </Box>

      {/* Charts */}
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "1.2fr 1.15fr 1.2fr",
          gap: 1,
          mt: 1,
        }}
      >
        <Card
          sx={{
            p: 1.5,
            borderRadius: "5px",
            boxShadow: "0 8px 30px rgba(0,0,0,.05)",
          }}
        >
          <Typography
            sx={{
              fontSize: 12,
              lineHeight: 1.2,
              fontWeight: 700,
              color: "#0A2E78",
              mb: 1,
            }}
          >
            {chart.title}
          </Typography>

          {/* Legend */}

          <Stack direction="row" spacing={3} mb={1.5}>
            <LegendItem color={BLUE} label="Planned" dashed />

            <LegendItem color={GREEN} label="Achieved" />
          </Stack>

          {/* Chart */}

          <Box
            sx={{
              width: "100%",
              height: 190,
              position: "relative",
            }}
          >
            <ResponsiveContainer>
              <LineChart
                data={chart.data}
                margin={{
                  top: 18,
                  left: -32, // move chart slightly left
                  right: 20, // give last point space
                  bottom: 12,
                }}
              >
                <CartesianGrid
                  stroke="#E8EDF5"
                  vertical={false}
                  strokeDasharray="5 5"
                />

                <XAxis
                  dataKey="date"
                  interval={0}
                  minTickGap={0}
                  padding={{
                    left: 12,
                    right: 12,
                  }}
                  tick={{
                    fill: "#0B226F",
                    fontSize: 8,
                  }}
                  axisLine={false}
                  tickLine={false}
                />

                <YAxis
                  domain={[0, 100]}
                  ticks={[0, 25, 50, 75, 100]}
                  tickFormatter={(v) => `${v}%`}
                  tick={{
                    fill: "#0B226F",
                    fontSize: 8,
                  }}
                  axisLine={false}
                  tickLine={false}
                />

                <ReferenceLine
                  segment={[
                    { x: "Jun 2026", y: 0 },
                    { x: "Jun 2026", y: 16 },
                  ]}
                  stroke={GREEN}
                  strokeWidth={1.5}
                  strokeDasharray="3 3"
                />

                <Tooltip />

                <Line
                  dataKey="planned"
                  stroke={BLUE}
                  strokeWidth={1.5}
                  strokeDasharray="10 6"
                  dot={{
                    r: 3,
                    fill: BLUE,
                  }}
                >
                  <LabelList
                    position="top"
                    formatter={(v: number) => `${v}%`}
                    style={{
                      fill: BLUE,
                      fontSize: 8,
                      fontWeight: 600,
                    }}
                  />
                </Line>

                <Line
                  dataKey="achieved"
                  connectNulls={false}
                  stroke={GREEN}
                  strokeWidth={2}
                  dot={{
                    r: 3,
                    fill: GREEN,
                  }}
                >
                  <LabelList
                    position="top"
                    formatter={(v: number) => (v ? `${v}%` : "")}
                    style={{
                      fill: GREEN,
                      fontSize: 8,
                      fontWeight: 600,
                    }}
                  />
                </Line>
              </LineChart>
            </ResponsiveContainer>
            <Box
              sx={{
                position: "absolute",
                left: "21%",
                top: 78,
                height: "calc(100% - 58px - 40px)", // adjust bottom gap
                borderLeft: `1.5px dashed ${GREEN}`,
                zIndex: 1,
              }}
            />
          </Box>

          {/* Annotation */}

          <Box
            sx={{
              mt: -2,
              ml: 5,
              // position: "absolute",
              top: 128,
              left: "12%",
              width: 75,
              p: 0.75,
              fontSize: 8,
              border: "1px solid #9BD8B2",
              borderRadius: 1,
            }}
          >
            16% achieved
            <br />
            by June 2026
          </Box>

          {/* Footer */}
        </Card>
        <Card
          elevation={0}
          sx={{
            height: "stretch",
            border: "1px solid #E2E8F0",
            borderRadius: 1.5,
            p: 1.5,
          }}
        >
          <Typography
            sx={{
              fontSize: 12,
              fontWeight: 700,
              color: "#0A2E78",
              mb: 2,
            }}
          >
            MIGRATION BY BU
            <Typography
              component="span"
              sx={{
                ml: 0.5,
                fontSize: 11,
              }}
            >
              (# of Applications)
            </Typography>
          </Typography>

          {/* Legend */}
          <Stack direction="row" spacing={2} sx={{ mb: 4, flexWrap: "wrap" }}>
            <Stack direction="row" spacing={0.5} alignItems="center">
              <Box
                sx={{
                  width: 10,
                  height: 10,
                  bgcolor: "#DC2626",
                  borderRadius: 0.5,
                }}
              />
              <Typography fontSize={10}>Blank (At Risk)</Typography>
            </Stack>

            <Stack direction="row" spacing={0.5} alignItems="center">
              <Box
                sx={{
                  width: 10,
                  height: 10,
                  bgcolor: "#7C3AED",
                  borderRadius: 0.5,
                }}
              />
              <Typography fontSize={10}>At Risk</Typography>
            </Stack>

            <Stack direction="row" spacing={0.5} alignItems="center">
              <Box
                sx={{
                  width: 10,
                  height: 10,
                  bgcolor: "#16A34A",
                  borderRadius: 0.5,
                }}
              />
              <Typography fontSize={10}>Complete</Typography>
            </Stack>

            <Stack direction="row" spacing={0.5} alignItems="center">
              <Box
                sx={{
                  width: 10,
                  height: 10,
                  bgcolor: "#9CA3AF",
                  borderRadius: 0.5,
                }}
              />
              <Typography fontSize={10}>Not in Flight</Typography>
            </Stack>

            <Stack direction="row" spacing={0.5} alignItems="center">
              <Box
                sx={{
                  width: 10,
                  height: 10,
                  bgcolor: "#2563EB",
                  borderRadius: 0.5,
                }}
              />
              <Typography fontSize={10}>On Track</Typography>
            </Stack>
          </Stack>

          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "85px 50px 180px 85px", // increased % column width
              rowGap: 0.75,
              // columnGap: "5px", // adds horizontal gap between columns
              alignItems: "center",
              borderBottom: "1px solid lightgrey",
            }}
          >
            {/* Header */}
            <Typography
              fontSize={10}
              fontWeight={700}
              sx={{
                // backgroundColor: "#0A2E78",
                color: "#333",
                fontWeight: 700,
              }}
            >
              BU
            </Typography>

            <Typography
              fontSize={10}
              fontWeight={700}
              sx={{
                // backgroundColor: "#0A2E78",
                color: "#333",
                fontWeight: 700,
              }}
            >
              Total
            </Typography>

            <Typography
              fontSize={10}
              fontWeight={700}
              sx={{
                // backgroundColor: "#0A2E78",
                color: "#333",
                fontWeight: 700,
              }}
            >
              Status
            </Typography>

            <Typography
              fontSize={10}
              fontWeight={700}
              sx={{
                pl: "10px", // extra space from Status bar
                // backgroundColor: "#0A2E78",
                color: "#333",
                fontWeight: 700,
              }}
            >
              %
            </Typography>

            {/* Header bottom spacing */}
            <Box sx={{ gridColumn: "1 / -1", height: "15px" }} />

            {buRows.map((row) => (
              <React.Fragment key={row.bu}>
                <Typography fontSize={10}>{row.bu}</Typography>

                <Typography fontSize={10}>{row.total}</Typography>

                <Stack
                  direction="row"
                  sx={{
                    height: 22,
                    borderRadius: 0.5,
                    overflow: "hidden",
                  }}
                >
                  <Box sx={{ width: row.red, bgcolor: "#DC2626" }} />
                  <Box sx={{ width: row.purple, bgcolor: "#7C3AED" }} />
                  <Box sx={{ width: row.green, bgcolor: "#16A34A" }} />
                  <Box sx={{ width: row.gray, bgcolor: "#9CA3AF" }} />
                  <Box sx={{ width: row.blue, bgcolor: "#2563EB" }} />
                </Stack>

                <Typography
                  fontSize={10}
                  fontWeight={700}
                  sx={{
                    pl: "10px", // extra space from Status bar
                  }}
                >
                  {row.pct}
                </Typography>
              </React.Fragment>
            ))}
          </Box>
        </Card>
        <Card
          elevation={0}
          sx={{
            border: "1px solid #E2E8F0",
            borderRadius: 2,
            p: "10px",
            height: "stretch", // IMPORTANT: stable height for perfect alignment
          }}
        >
          {/* HEADER */}
          <Typography
            sx={{
              fontSize: 11,
              fontWeight: 700,
              color: "#0A2E78",
              mb: 3,
              textAlign: "start",
            }}
          >
            DECOMMISSIONING SUMMARY{" "}
            <Typography component="span" sx={{ fontSize: 10, ml: 0.5 }}>
              (Servers)
            </Typography>
          </Typography>

          {/* GRID */}
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "120px repeat(3, 1fr)",
              gridTemplateRows: "1fr 1fr",
              gap: "10px",
              height: "calc(80% - 24px)",
            }}
          >
            {/* TOTAL SERVER INVENTORY (short visual height = 0.5 feel) */}
            <Card
              variant="outlined"
              sx={{
                gridRow: "1 / span 2",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                p: "10px",
                height: "100%",
              }}
            >
              <Typography sx={{ fontSize: 10, textAlign: "center" }}>
                Total Server Inventory
              </Typography>

              <Typography
                sx={{
                  fontSize: 26, // reduced from 30 for better balance
                  fontWeight: 700,
                  color: "#0A2E78",
                  lineHeight: 1,
                  my: 0.5,
                }}
              >
                41K
              </Typography>

              <Typography sx={{ fontSize: 10, textAlign: "center" }}>
                Total
              </Typography>
            </Card>

            {/* COMPLETE */}
            <Card
              variant="outlined"
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                p: "10px",
                borderColor: "#86EFAC",
                height: "100%",
              }}
            >
              <Typography sx={{ fontSize: 10 }}>Complete</Typography>
              <Typography
                sx={{ fontSize: 24, fontWeight: 700, color: "#16A34A" }}
              >
                2,326
              </Typography>
            </Card>

            {/* ON TRACK */}
            <Card
              variant="outlined"
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                p: "10px",
                borderColor: "#93C5FD",
                height: "100%",
              }}
            >
              <Typography sx={{ fontSize: 10 }}>On Track</Typography>
              <Typography
                sx={{ fontSize: 24, fontWeight: 700, color: "#2563EB" }}
              >
                7,458
              </Typography>
            </Card>

            {/* AT RISK */}
            <Card
              variant="outlined"
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                p: "10px",
                borderColor: "#FDBA74",
                height: "100%",
              }}
            >
              <Typography sx={{ fontSize: 10 }}>At Risk</Typography>
              <Typography
                sx={{ fontSize: 24, fontWeight: 700, color: "#F59E0B" }}
              >
                1,075
              </Typography>
            </Card>

            {/* DELAYED */}
            <Card
              variant="outlined"
              sx={{
                gridColumn: "2 / span 3",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                p: "10px",
                borderColor: "#FCA5A5",
                height: "100%",
              }}
            >
              <Typography
                sx={{
                  fontSize: 24,
                  fontWeight: 700,
                  color: "#DC2626",
                  mr: 1.5,
                }}
              >
                22
              </Typography>

              <Typography sx={{ fontSize: 11, fontWeight: 600 }}>
                Delayed
              </Typography>
            </Card>
          </Box>
        </Card>
      </Box>
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "1.2fr 0.8fr 0.9fr",
          gap: "10px",
          mt: 1,
        }}
      >
        <Card
          elevation={0}
          sx={{
            height: "100%",
            border: "1px solid #E2E8F0",
            borderRadius: 1.5,
            p: "10px",
            display: "flex",
            flexDirection: "column",
          }}
        >
          {/* HEADER */}
          <Typography
            sx={{
              fontSize: 12,
              fontWeight: 700,
              color: "#0A2E78",
              mb: 1.5,
            }}
          >
            PROGRAM ROADMAP
          </Typography>

          {/* TOP GRID */}
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr 1fr",
              flex: 1,
            }}
          >
            {/* FY26 */}
            <Box sx={{ pr: 1.5, borderRight: "1px solid #E5E7EB" }}>
              <Typography
                sx={{ color: "#16A34A", fontSize: 12, fontWeight: 600 }}
              >
                FY26
              </Typography>

              <Typography
                sx={{
                  color: "#16A34A",
                  fontSize: 12,
                  fontWeight: 600,
                  mb: 0.5,
                }}
              >
                Foundation Phase
              </Typography>

              <Box
                sx={{
                  width: "100%",
                  height: "6px",
                  bgcolor: "#16A34A",
                  mb: 1,
                }}
              />

              <Stack spacing={0.5}>
                {[
                  "Initial application migration",
                  "Migration pipelines & Tooling",
                  "Migration factory established",
                  "Regional migration model established",
                ].map((item) => (
                  <Typography key={item} sx={{ fontSize: 10 }}>
                    ○ {item}
                  </Typography>
                ))}
              </Stack>
            </Box>

            {/* FY27 */}
            <Box sx={{ px: 1.5, borderRight: "1px solid #E5E7EB" }}>
              <Typography
                sx={{ color: "#2563EB", fontSize: 12, fontWeight: 600 }}
              >
                FY27-FY28
              </Typography>

              <Typography
                sx={{
                  color: "#2563EB",
                  fontSize: 12,
                  fontWeight: 600,
                  mb: 0.5,
                }}
              >
                Expansion Phase
              </Typography>

              <Box
                sx={{
                  width: "100%",
                  height: "6px",
                  bgcolor: "#2563EB",
                  mb: 1,
                }}
              />

              <Stack spacing={0.5}>
                {[
                  "Majority applications migrated",
                  "DC decommissioning initiated",
                  "FinOps implementation",
                  "Enhance Performance & scalability",
                ].map((item) => (
                  <Typography key={item} sx={{ fontSize: 10 }}>
                    ○ {item}
                  </Typography>
                ))}
              </Stack>
            </Box>

            {/* FY28-29 */}
            <Box sx={{ pl: 1.5 }}>
              <Typography
                sx={{ color: "#7C3AED", fontSize: 12, fontWeight: 600 }}
              >
                FY29-FY30
              </Typography>

              <Typography
                sx={{
                  color: "#7C3AED",
                  fontSize: 12,
                  fontWeight: 600,
                  mb: 0.5,
                }}
              >
                Maturity Phase
              </Typography>

              <Box
                sx={{
                  width: "100%",
                  height: "6px",
                  bgcolor: "#7C3AED",
                  mb: 1,
                }}
              />

              <Stack spacing={0.5}>
                {[
                  "Full Data Center Shutdown",
                  "Cloud Cost optimization",
                  "Standardize operting model",
                  "Full migration of application & workloads",
                ].map((item) => (
                  <Typography key={item} sx={{ fontSize: 10 }}>
                    ○ {item}
                  </Typography>
                ))}
              </Stack>
            </Box>
          </Box>

          {/* 🔻 BOTTOM STATUS ROW (NEW) */}
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr 1fr",
              mt: 0,
              gap: 0.5,
            }}
          >
            <Box
              sx={{
                textAlign: "start",
                color: "#16A34A",
                fontSize: 12,
                fontWeight: 700,
                marginLeft: "5px",
              }}
            >
              Status: On Track
            </Box>

            <Box
              sx={{
                textAlign: "start",
                color: "#2563EB",
                fontSize: 12,
                fontWeight: 700,
                marginLeft: "7px",
              }}
            >
              Status: Planned
            </Box>

            <Box
              sx={{
                textAlign: "start",
                color: "#7C3AED",
                fontSize: 12,
                fontWeight: 700,
                marginLeft: "7px",
              }}
            >
              Status: Future
            </Box>
          </Box>
        </Card>
        <Card
          elevation={0}
          sx={{
            border: "1px solid #E2E8F0",
            borderRadius: 1.5,
            p: "10px",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Typography
            sx={{
              fontSize: 12,
              fontWeight: 700,
              color: "#0A2E78",
              mb: 1,
            }}
          >
            MILESTONE TRACKER
          </Typography>
          <Table
            size="small"
            sx={{
              tableLayout: "fixed", // important for width control

              "& .MuiTableCell-root": {
                fontSize: "10px",
                color: "#0A2E78",
                textAlign: "left",
                py: 0.6,
              },

              "& .MuiTableHead-root .MuiTableCell-root": {
                backgroundColor: "#0A2E78",
                color: "#fff",
                fontWeight: 700,
                borderBottom: "none",
              },
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: "45%" }}>Milestone</TableCell>

                <TableCell sx={{ width: "25%" }}>Target</TableCell>

                <TableCell sx={{ width: "30%" }}>Status</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {milestones.map((row) => (
                <TableRow key={row.milestone}>
                  <TableCell sx={{ whiteSpace: "nowrap", overflow: "hidden" }}>
                    {row.milestone}
                  </TableCell>

                  <TableCell sx={{ whiteSpace: "nowrap" }}>
                    {row.target}
                  </TableCell>

                  <TableCell sx={{ whiteSpace: "nowrap" }}>
                    <StatusBadge value={row.status} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>

        {/* ================= RISKS & ISSUES ================= */}
        <Card
          elevation={0}
          sx={{
            border: "1px solid #E2E8F0",
            borderRadius: 1.5,
            p: "10px",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Typography
            sx={{
              fontSize: 12,
              fontWeight: 700,
              color: "#0A2E78",
              mb: 1,
            }}
          >
            RISKS & ISSUES
          </Typography>

          <Table
            size="small"
            sx={{
              tableLayout: "fixed", // 🔥 important for controlled columns

              "& .MuiTableCell-root": {
                fontSize: "10px",
                color: "#0A2E78",
                textAlign: "left",
                py: 0.6,
              },

              "& .MuiTableHead-root .MuiTableCell-root": {
                backgroundColor: "#0A2E78",
                color: "#fff",
                fontWeight: 700,
                borderBottom: "none",
              },
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: "33%" }}>Risk / Issue</TableCell>
                <TableCell sx={{ width: "18%" }}>Impact</TableCell>
                <TableCell sx={{ width: "26%" }}>Status</TableCell>
                <TableCell sx={{ width: "42%" }}>Mitigation</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {risks.map((risk) => (
                <TableRow key={risk.risk}>
                  <TableCell>{risk.risk}</TableCell>

                  <TableCell>
                    <ImpactBadge value={risk.impact} />
                  </TableCell>

                  <TableCell>
                    <StatusDotText value={risk.status} />
                  </TableCell>

                  <TableCell>{risk.mitigation}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </Box>
      <Card
        elevation={0}
        sx={{
          mt: 1,
          border: "1px solid #E2E8F0",
          borderRadius: 1.5,
          p: 1.5,
        }}
      >
        <Typography
          sx={{
            fontSize: 12,
            fontWeight: 700,
            color: "#0A2E78",
            mb: 1,
          }}
        >
          KEY DOCUMENTS & LINKS
        </Typography>

        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "repeat(7, 1fr)",
            gap: 1,
          }}
        >
          {documents.map((doc) => (
            <Card
              key={doc.title}
              elevation={0}
              sx={{
                border: "1px solid #E2E8F0",
                borderRadius: 1,
                //   height: 82,
                px: 1,
                py: 1,
                cursor: "pointer",

                "&:hover": {
                  bgcolor: "#F8FAFC",
                },
              }}
            >
              <Stack direction="row" spacing={1} alignItems="flex-start">
                <Typography
                  sx={{
                    fontSize: 24,
                    lineHeight: 1,
                  }}
                >
                  {doc.icon}
                </Typography>

                <Box>
                  <Typography
                    sx={{
                      fontSize: 11,
                      fontWeight: 500,
                      color: "#0A2E78",
                      whiteSpace: "pre-line",
                      lineHeight: 1.3,
                    }}
                  >
                    {doc.title}
                  </Typography>

                  <Typography
                    sx={{
                      fontSize: 10,
                      color: "#2563EB",
                      mt: 0.5,
                      fontWeight: 500,
                    }}
                  >
                    View
                  </Typography>
                </Box>
              </Stack>
            </Card>
          ))}
        </Box>
      </Card>
    </Box>
  );
}

function LegendItem({ color, label, dashed }: any) {
  return (
    <Stack direction="row" spacing={2} alignItems="center">
      <Box
        sx={{
          width: 18,
          borderTop: `2px ${dashed ? "dashed" : "solid"} ${color}`,
        }}
      />

      <Typography
        sx={{
          fontSize: 10,
          fontWeight: 600,
          color: "#0A2E78",
        }}
      >
        {label}
      </Typography>
    </Stack>
  );
}

function FooterCard({ icon, title, value }: any) {
  return (
    <Stack
      direction="row"
      spacing={1}
      alignItems="center"
      sx={{
        minWidth: 95,
      }}
    >
      <Box
        sx={{
          display: "flex",
          "& .MuiSvgIcon-root": {
            fontSize: 14, // reduce icon size
          },
        }}
      >
        {icon}
      </Box>

      <Box>
        <Typography
          sx={{
            fontSize: 8,
            fontWeight: 700,
            color: "#0B226F",
          }}
        >
          {title}
        </Typography>

        <Typography
          sx={{
            fontSize: 9,
            color: "#344054",
          }}
        >
          {value}
        </Typography>
      </Box>
    </Stack>
  );
}
