import React from "react";
import {
  Avatar,
  Box,
  Breadcrumbs,
  Button,
  Card,
  Chip,
  Divider,
  Grid,
  LinearProgress,
  Stack,
  Typography,
  Paper,
  CardContent,
  IconButton,
  CircularProgress,
} from "@mui/material";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import ShareOutlinedIcon from "@mui/icons-material/ShareOutlined";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import InsertDriveFileOutlinedIcon from "@mui/icons-material/InsertDriveFileOutlined";
import AssessmentOutlinedIcon from "@mui/icons-material/AssessmentOutlined";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  ResponsiveContainer,
  CartesianGrid,
  LabelList,
  BarChart,
  Bar,
  Legend,
  ReferenceLine,
} from "recharts";

import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import CloudOutlinedIcon from "@mui/icons-material/CloudOutlined";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import DashboardCustomizeOutlinedIcon from "@mui/icons-material/DashboardCustomizeOutlined";
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import FlagOutlinedIcon from "@mui/icons-material/FlagOutlined";
import MonitorHeartOutlinedIcon from "@mui/icons-material/MonitorHeartOutlined";

import AppsOutlinedIcon from "@mui/icons-material/AppsOutlined";
import CloudDoneOutlinedIcon from "@mui/icons-material/CloudDoneOutlined";
import ApartmentOutlinedIcon from "@mui/icons-material/ApartmentOutlined";
import CheckCircleOutlineOutlinedIcon from "@mui/icons-material/CheckCircleOutlineOutlined";
import AccessTimeOutlinedIcon from "@mui/icons-material/AccessTimeOutlined";
import Groups2OutlinedIcon from "@mui/icons-material/Groups2Outlined";
import PublicOutlinedIcon from "@mui/icons-material/PublicOutlined";
import WindowOutlinedIcon from "@mui/icons-material/WindowOutlined";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import Tooltip from "@mui/material/Tooltip";

import AttachMoneyRoundedIcon from "@mui/icons-material/AttachMoneyRounded";
import GroupsRoundedIcon from "@mui/icons-material/GroupsRounded";
import SouthRoundedIcon from "@mui/icons-material/SouthRounded";
import NorthRoundedIcon from "@mui/icons-material/NorthRounded";

import GroupsIcon from "@mui/icons-material/Groups";
import PublicIcon from "@mui/icons-material/Public";
import GridViewRoundedIcon from "@mui/icons-material/GridViewRounded";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";

import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import DoneIcon from "@mui/icons-material/Done";
import chart from "../../data/migrationProgress.json";
import { useTheme } from "../../theme-context";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useNavigate } from "react-router-dom";

const kpis = [
  {
    title: "Total Applications",
    value: "1,094",
    subtitle: "Across 18 DCs",
    color: "#0A2E78",
    icon: <AppsOutlinedIcon sx={{ fontSize: 16 }} />,
  },
  {
    title: "Applications Migrated",
    value: "280",
    subtitle: "26% of total",
    color: "#0A2E78",
    icon: <CloudDoneOutlinedIcon sx={{ fontSize: 16 }} />,
  },
  {
    title: "Active Data Centers",
    value: "18",
    subtitle: "On Track",
    color: "#0A2E78",
    icon: <ApartmentOutlinedIcon sx={{ fontSize: 16 }} />,
  },
  {
    title: "Overall Migration Completion",
    value: "16%",
    subtitle: "Achieved by June 2026",
    color: "#0A2E78",
    icon: <CheckCircleOutlineOutlinedIcon sx={{ fontSize: 16 }} />,
  },
];

const labelStyle = {
  fontSize: "11px",
  fontWeight: 500,
  color: "#010035",
};

const valueStyle = {
  fontSize: "42px",
  fontWeight: 700,
  color: "#0A2E78",
};

const migrationProgressData = [
  { month: "Q1", planned: 20, actual: 16 },
  { month: "Q2", planned: 35, actual: 28 },
  { month: "Q3", planned: 50, actual: 42 },
  { month: "Q4", planned: 70, actual: 60 },
  { month: "Q5", planned: 90, actual: 80 },
];

const buData = [
  {
    name: "Commercial",
    completed: 70,
    inProgress: 20,
    pending: 10,
  },
  {
    name: "Consumer",
    completed: 55,
    inProgress: 25,
    pending: 20,
  },
  {
    name: "Finance",
    completed: 40,
    inProgress: 30,
    pending: 30,
  },
  {
    name: "Operations",
    completed: 65,
    inProgress: 20,
    pending: 15,
  },
];
const buRows = [
  {
    bu: "GETS",
    total: 500,
    red: 90,
    purple: 40,
    green: 50,
    gray: 90,
    blue: 20,
    pct: "14%",
  },
  {
    bu: "ESI",
    total: 210,
    red: 25,
    purple: 20,
    green: 40,
    gray: 70,
    blue: 25,
    pct: "19%",
  },
  {
    bu: "Nationals",
    total: 80,
    red: 40,
    purple: 10,
    green: 15,
    gray: 15,
    blue: 0,
    pct: "13%",
  },
  {
    bu: "Major & Canada",
    total: 70,
    red: 35,
    purple: 10,
    green: 10,
    gray: 15,
    blue: 0,
    pct: "21%",
  },
  {
    bu: "SR/MRFS",
    total: 60,
    red: 25,
    purple: 10,
    green: 5,
    gray: 10,
    blue: 10,
    pct: "8%",
  },
];
const milestones = [
  {
    milestone: "Resource Mix Savings Target ($)",
    target: "$40M",
    description: "Savings from FTE/Contractor rebalancing",
  },
  {
    milestone: "Geo Mix Savings Target ($)",
    target: "$10M - $30M",
    description: "Savings from geo mix shift",
  },
  {
    milestone: "Others Savings Target ($)",
    target: "-",
    description: "Savings from Microsite reduction",
  },

];

const risks = [
  {
    risk: "Workforce strategy execution",
    impact: "High",
    status: "At Risk",
    mitigation: "Dependency mapping & refactor plan",
  },
  {
    risk: "Geo mix transition execution",
    impact: "Medium",
    status: "Needs Attention",
    mitigation: "Accelerated assessment",
  },
  {
    risk: "Workforce rebalancing progress",
    impact: "Medium",
    status: "Needs Attention",
    mitigation: "Additional teams & capacity",
  },
  {
    risk: "Facility/Microsite consolidation execution",
    impact: "High",
    status: "At Risk",
    mitigation: "Automation tooling",
  },
  {
    risk: "Savings measurement & reporting integrity",
    impact: "Low",
    status: "On Track",
    mitigation: "Automation tooling",
  },
];
const documents = [
  {
    icon: "📊",
    title: "Initiative Overview (One Pager) (PPT)",
  },
  {
    icon: "📗",
    title: "Application Inventory\n(XLSX)",
  },
  {
    icon: "📈",
    title: "Migration Factory\nDashboard",
  },
  {
    icon: "📘",
    title: "FinOps Assessment\n(DOCX)",
  },
  {
    icon: "📕",
    title: "Architecture Review\n(PDF)",
  },
  {
    icon: "🟢",
    title: "Steering Committee\nNotes",
  },
  {
    icon: "📄",
    title: "RAID Log",
  },
];


export const summaryCards = [
  {
    title: "Savings MTD",
    value: "$1M",
    subtitle: "vs $1.5M Target",
    color: "#383d5a",
    icon: "$",
    variance: "$0.5M"
  },
  {
    title: "Savings QTD",
    value: "$3M",
    subtitle: "vs $5M Target",
    color: "#383d5a",
    icon: "$",
    variance: "$9M"
  },
  {
    title: "Savings YTD",
    value: "$8M",
    subtitle: "vs $17M Target",
    color: "#383d5a",
    icon: "$",
    variance: "$9M"
  },
  // {
  //   title: "Savings FY",
  //   value: "$20M",
  //   subtitle: "vs $25M Target",
  //   color: "#18A957",
  //   icon: "📈",
  //   variance: "$5M"
  // },
  {
    title: "Execution Progress",
    // subtitle: "Weighted average",
    progress: 20,
    color: "#767a8191",
    icon: "👥",
  },
  {
    title: "Workforce Mix Progress",
    // subtitle: "Weighted average",
    color: "#F97316",
    current: "94:6",
    target: "90:10",
    icon: "👥",
  },
  {
    title: "Geo Mix Progress",
    // subtitle: "Weighted average",
    color: "#2563EB",
    current: "56:9:35",
    target: "35:25:40",
    icon: "🌍",
  },
  {
    title: "Microsite Reduction progress",
    // subtitle: "Weighted average",
    color: "#7C3AED",
    current: "-",
    target: "20",
    icon: "",
  },
];
const infoCards = [
  {
    title: "Initiative Owner",
    value: "Varun",
    subtitle: "",
    icon: <PersonOutlineIcon color="primary" sx={{ fontSize: 16 }} />,
  },
  {
    title: "FAST Pillar",
    value: "Transform",
    subtitle: "",
    icon: (
      <DashboardCustomizeOutlinedIcon
        color="primary"
        sx={{ fontSize: 16 }}
      />
    ),
  },
  {
    title: "Timeline",
    value: "FY26 - FY29",
    subtitle: "(4 Year Program)",
    icon: (
      <CalendarMonthOutlinedIcon color="primary" sx={{ fontSize: 16 }} />
    ),
  },
  {
    title: "Current Phase",
    value: "FY27",
    subtitle: "Execution Phase",
    icon: <FlagOutlinedIcon color="primary" sx={{ fontSize: 16 }} />,
  },
  // {
  //   title: "Key Takeaway",
  //   value:
  //     "Geo mix optimization is ahead of plan while resource mix and workforce optimization require acceleration.",
  //   subtitle: "",
  //   icon: null,
  //   isTakeaway: true,
  // },
];
const summaryCard2 = [
  {
    title: "Cost Savings Realization (FY29)",
    value: "$20M",
    target: "$70M",
    progress: 29,
    percentage: "71%",
    iconBg: "#F1EBFF",
    iconColor: "#6B4CF6",
  },
  {
    title: "Total Savings (YTD)",
    value: "$8M",
    target: "$17M",
    ytdLY: "$5M (YTD LY)",
    growth: "+ $3M",
    progress: 47,
    percentage: "53%",
    iconBg: "#F1EBFF",
    iconColor: "#6B4CF6",
  },
  {
    title: "Total Savings (QTD)",
    value: "$3M",
    target: "$5M",
    progress: 60,
    ytdLY: "$2M (QTD LQ)",
    growth: "+ $1M",
    percentage: "40%",
    iconBg: "#EAF3FF",
    iconColor: "#1E88E5",
  },
  {
    title: "Total Savings (MTD)",
    value: "$1M",
    target: "$1.5M",
    progress: 67,
    ytdLY: "$0.5M (MTD LM)",
    growth: "+ $0.5M",
    percentage: "33%",
    iconBg: "#E8F7EC",
    iconColor: "#28A745",
  },
]
const summaryCards1 = [
  {
    title: "Cost Savings Realization (FY29)",
    value: "$20M",
    target: "$70M Target",
    progress: 47,
    percentage: "71%",
    iconBg: "#F1EBFF",
    iconColor: "#6B4CF6",
  },
  {
    title: "Total Savings (YTD)",
    value: "$8M",
    target: "$17M Target",
    ytdLY: "vs $5M (YTD LY)",
    growth: "+ $3M",
    progress: 47,
    percentage: "53%",
    iconBg: "#F1EBFF",
    iconColor: "#6B4CF6",
  },
  {
    title: "Total Savings (QTD)",
    value: "$3M",
    target: "$5M Target",
    progress: 60,
    percentage: "40%",
    iconBg: "#EAF3FF",
    iconColor: "#1E88E5",
  },
  {
    title: "Total Savings (MTD)",
    value: "$1M",
    target: "$1.5M Target",
    progress: 67,
    percentage: "33%",
    iconBg: "#E8F7EC",
    iconColor: "#28A745",
  },
  // {
  //   title: "Execution Progress",
  //   value: "20%",
  //   progress: 20,
  //   execution: true,
  //   iconBg: "#EFE9FF",
  //   iconColor: "#7E57C2",
  // },
];

const savingsCards = [
  {
    id: 1,
    title: "Resource Mix",
    subtitle: "Optimize workforce composition for maximum efficiency.",
    status: "Off Track",

    progress: 30,

    current: "94:6",
    targetRatio: "90:10",

    ytd: "$6M",
    ytdTarget: "$8M",
    ytdPercentage: "75%",

    qtd: "$2M",
    qtdTarget: "$3M",
    qtdPercentage: "67%",

    color: "#635BFF",

    Icon: GroupsIcon,

    note:
      "Savings from FTE / contractor rebalancing to achieve optimal workforce mix and productivity.",
  },

  {
    id: 2,
    title: "Geo Mix",
    subtitle: "Strategic geo shift to optimize cost arbitrage and delivery.",
    status: "On Track",

    progress: 35,

    current: "56:9:35",
    targetRatio: "35:25:40",

    ytd: "$30M",
    ytdTarget: "$30M",
    ytdPercentage: "100%",

    qtd: "$10M",
    qtdTarget: "$10M",
    qtdPercentage: "100%",

    color: "#06B6D4",

    Icon: PublicIcon,

    note:
      "Savings from geo mix shift to optimize cost arbitrage and improve delivery economics.",
  },

  {
    id: 3,
    title: "Microsite Reduction",
    subtitle:
      "Reduce microsites to streamline operations and reduce overhead.",

    status: "",

    progress: 0,

    current: "0",
    targetRatio: "20",

    ytd: "$-",
    ytdTarget: "—",
    ytdPercentage: "",

    qtd: "$-",
    qtdTarget: "—",
    qtdPercentage: "",

    color: "#22C55E",

    Icon: GridViewRoundedIcon,

    note:
      "Savings from Microsite reduction initiatives and license optimization.",
  },
];

export const savingsCards1 = [
  {
    id: 1,
    title: "Resource Mix Savings Progress",
    subtitle: "Savings from FTE / contractor rebalancing",
    target: "$40M",
    ytd: "-",
    progress: 0,
    color: "#383d5a",
    Icon: Groups2OutlinedIcon,
    note:
      "Savings from FTE / contractor rebalancing to achieve optimal workforce mix and productivity.",
  },
  {
    id: 2,
    title: "Geo Mix Savings Progress",
    subtitle: "Savings from geo mix shift",
    target: "$10M – $30M",
    ytd: "-",
    progress: 0,
    color: "#383d5a",
    Icon: PublicOutlinedIcon,
    note:
      "Savings from geo mix shift to optimize cost arbitrage and improve delivery economics.",
  },
  {
    id: 3,
    title: "Microsite Reduction Progress",
    subtitle: "Savings attributed to Microsite reduction",
    target: "20",
    ytd: "-",
    progress: 0,
    color: "#383d5a",
    Icon: WindowOutlinedIcon,
    note:
      "Savings from Microsite reduction initiatives and license optimization.",
  },
];

const BLUE = "#1565FF";
const GREEN = "#0CA44B";

const CustomTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;

  return (
    <div className="tooltip">
      <div>{payload[0]?.payload.month}</div>

      {payload.map((item: any) => (
        <div key={item.dataKey}>
          {item.name}: {item.value}%
        </div>
      ))}
    </div>
  );
};

/* ===================== CONFIG ===================== */
const statusConfig = {
  Completed: { color: "#16A34A", type: "filled" },
  "In Progress": { color: "#F59E0B", type: "outlined" },
  Planned: { color: "#2563EB", type: "outlined" },
};

const impactConfig = {
  High: "#DC2626",
  Medium: "#F59E0B",
  Low: "#18B96E",
};

/* ===================== STATUS BADGE ===================== */
const StatusBadge = ({ value }) => {
  const config = statusConfig[value] || { color: "#0A2E78" };

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
      <Box
        sx={{
          width: 10,
          height: 10,
          borderRadius: "50%",
          border:
            config.type === "outlined" ? `2px solid ${config.color}` : "none",
          backgroundColor:
            config.type === "filled" ? config.color : "transparent",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {config.type === "filled" && (
          <Typography sx={{ fontSize: 8, color: "#fff", lineHeight: 1 }}>
            ✓
          </Typography>
        )}
      </Box>

      <Typography sx={{ fontSize: 10, color: "#0A2E78" }}>{value}</Typography>
    </Box>
  );
};

/* ===================== IMPACT BADGE ===================== */
const ImpactBadge = ({ value }) => {
  const color = impactConfig[value] || "#0A2E78";

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
      <Typography sx={{ fontSize: 10, color }}>{value}</Typography>
    </Box>
  );
};

const statusColorMap = {
  "At Risk": "#DC2626",
  "Needs Attention": "#F59E0B",
  "On Track": "#16A34A",
};

const StatusDotText = ({ value }) => {
  const color = statusColorMap[value] || "#0A2E78";

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.6 }}>
      {/* dot */}
      <Box
        sx={{
          width: 8,
          height: 8,
          borderRadius: "50%",
          backgroundColor: color,
        }}
      />

      {/* text */}
      <Typography
        sx={{
          fontSize: 10,
          fontWeight: 600,
          color: color,
          lineHeight: 1,
        }}
      >
        {value}
      </Typography>
    </Box>
  );
};

const CircularProgressWithLabel = ({ value, color }) => {
  return (
    <Box
      sx={{
        position: "relative",
        width: 110,
        height: 110,
      }}
    >
      <CircularProgress
        variant="determinate"
        value={100}
        size={110}
        thickness={4}
        sx={{
          color: "#EEF2F7",
          position: "absolute",
        }}
      />

      <CircularProgress
        variant="determinate"
        value={value}
        size={110}
        thickness={4}
        sx={{
          color,
          position: "absolute",
          "& .MuiCircularProgress-circle": {
            strokeLinecap: "round",
          },
        }}
      />

      <Box
        sx={{
          position: "absolute",
          inset: 0,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Typography
          sx={{
            fontSize: 18,
            fontWeight: 700,
            color: "#0F172A",
          }}
        >
          {value}%
        </Typography>

        <Typography
          sx={{
            fontSize: 13,
            color: "#64748B",
          }}
        >
          Progress
        </Typography>
      </Box>
    </Box>
  );
}
const InfoCard = ({ item }: any) => (
  <Box
    sx={{
      height: "100%",
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-start",
      px: 1,
      borderRight: "1px solid rgba(0,0,0,0.12)",
    }}
  >
    {item.isTakeaway ? (
      <>
        <Typography sx={labelStyle}>{item.title}</Typography>

        <Typography
          sx={{
            mt: 1,
            fontSize: 11,
            color: "#383D5A",
            lineHeight: 1.4,
          }}
        >
          {item.value}
        </Typography>
      </>
    ) : (
      <>
        <Stack direction="row" spacing={0.5} alignItems="center">
          {item.icon}
          <Typography sx={labelStyle}>{item.title}</Typography>
        </Stack>
        <Box sx={{display: "flex", gap: 1,  mt: 0.6, justifyItems: "center", alignItems: "center"}}>        

        <Typography
          sx={{
            pl: "20px",
            // mt: 0.6,
            fontSize: 12,
            fontWeight: 700,
            color: "#010035",
          }}
        >
          {item.value}
        </Typography>

        <Typography
          sx={{
            // pl: "20px",
            fontSize: 10,
            // mt: 0.6,
            color: "text.secondary",
          }}
        >
          {item.subtitle || "\u00A0"}
        </Typography>
        </Box>
      </>
    )}
  </Box>
);

const SavingsCards2 = ({ item, last = false }: any) => (
  <Box
    sx={{
      height: "100%",
      display: "flex",
      // alignItems: "center",
      gap: 0.5,
      px: "5px",
      borderRight: last ? "none" : "1px solid rgba(0,0,0,0.12)",
    }}
  >
    <Avatar
      sx={{
        width: 24,
        height: 24,
        bgcolor: item.iconBg,
        color: item.iconColor,
      }}
    >
      {item.execution ? (
        <GroupsRoundedIcon />
      ) : (
        <AttachMoneyRoundedIcon />
      )}
    </Avatar>

    <Box flex={1}>
      <Typography
        sx={{
          fontSize: 11,
          color: "#010035",
          fontWeight: 500,
        }}
      >
        {item.title}
      </Typography>

      {/* <Typography
        sx={{
          fontWeight: 700,
          fontSize: 12,
          color: "#767a8191",
          mt: "10px",
          mb: "-10px"
        }}
      >
        {item.value}
      </Typography> */}
      {item.execution ? (
        <>
          <LinearProgress
            variant="determinate"
            value={item.progress}
            sx={{
              mt: 1,
              height: 5,
              borderRadius: 4,
              bgcolor: "#ECEEF4",
              "& .MuiLinearProgress-bar": {
                bgcolor: "#6B4CF6",
                borderRadius: 4,
              },
            }}
          />
        </>
      ) : (
        <>
          <Box
            sx={{
              position: "relative",
              pt: 1.5,
              mt: 1,
            }}
          >
            <Typography
              sx={{
                position: "absolute",
                left: `${item.progress ?? 0
                  }%`,
                transform: "translateX(-50%)",
                top: -2,

                fontSize: 10,
                fontWeight: 700,

                // color: metric.label === "Breakthrough Overall Revenue" ? "#767a8191" : getProgressBarColor(
                //   metric.value ?? metric.progress ?? 0
                // ),
                // color: "#767a8191",
                color: "#767a8191",

                maxWidth: 40,
                textAlign: "center",
              }}
            >
              {item.progress ?? 0}%
            </Typography>

            <LinearProgress
              variant="determinate"
              value={item.progress ?? 0}
              sx={{
                height: 5,
                borderRadius: 10,
                bgcolor: "#E5E7EB",

                "& .MuiLinearProgress-bar": {
                  borderRadius: 10,
                  // bgcolor: "#767a8191"
                  bgcolor: "#767a8191",
                  // bgcolor: getProgressBarColor(
                  //   metric.value ?? metric.progress ?? 0
                  // ),
                },
              }}
            />


            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                mt: 0.4,
              }}
            >
              <Typography
                sx={{
                  fontSize: 10,
                  // color: "#64748B",
                  color: "#767a8191",
                  fontWeight: 600
                }}
              >
                {item.value}
              </Typography>

              <Typography
                sx={{
                  fontSize: 10,
                  // color: "#64748B",
                  color: ["Cost Savings Realization (FY29)"].includes(item.title) ? "#383d5a" : "#767a8191",
                  fontWeight: 600
                }}
              >
                {item.target}
              </Typography>
            </Box>
          </Box>
          {/* <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          mt={0.8}
        >
          <Typography
            sx={{
              fontSize: 10,
              // color: "#667085",
              color: ["Cost Savings Realization (FY29)"].includes(item.title) ? "#383d5a" : "#667085",
              marginLeft: "-20px"
            }}
          >
            vs {item.target}
          </Typography>

          <Chip
            size="small"
            icon={<SouthRoundedIcon sx={{ fontSize: 14 }} />}
            label={item.percentage}
            sx={{
              height: 22,
              bgcolor: "#FFF1F1",
              color: "#D92D20",
              fontSize: 10,
              fontWeight: 700,
              "& .MuiChip-icon": {
                color: "#D92D20",
                fontSize: 12,
              },
            }}
          />          
        </Stack> */}
          {item.ytdLY && (
            <Stack
              direction="row"
              justifyContent="start"
              alignItems="center"
              gap={1}
              mt={0.8}
            >
              <Typography
                sx={{
                  fontSize: 10,
                  // color: "#667085",
                  color: "#667085",
                  marginLeft: "-20px"
                }}
              >
                {item.ytdLY}
              </Typography>
              <Chip
                size="small"
                icon={<NorthRoundedIcon sx={{ fontSize: 14 }} />}
                label={item.growth}
                sx={{
                  height: 22,
                  bgcolor: "#1e8e3e12",
                  color: "#18B96E",
                  fontSize: 10,
                  fontWeight: 700,
                  "& .MuiChip-icon": {
                    color: "#18B96E",
                    fontSize: 12,
                  },
                }}
              />
            </Stack>
          )}
        </>
      )}
    </Box>
  </Box>
);

const SavingsCard = ({ item, last = false }: any) => (
  <Box
    sx={{
      height: "100%",
      display: "flex",
      // alignItems: "center",
      gap: 0.5,
      px: "5px",
      borderRight: last ? "none" : "1px solid rgba(0,0,0,0.12)",
    }}
  >
    <Avatar
      sx={{
        width: 24,
        height: 24,
        bgcolor: item.iconBg,
        color: item.iconColor,
      }}
    >
      {item.execution ? (
        <GroupsRoundedIcon />
      ) : (
        <AttachMoneyRoundedIcon />
      )}
    </Avatar>

    <Box flex={1}>
      <Typography
        sx={{
          fontSize: 11,
          color: "#010035",
          fontWeight: 500,
        }}
      >
        {item.title}
      </Typography>

      <Typography
        sx={{
          fontWeight: 700,
          fontSize: 12,
          color: "#767a8191",
          mt: "10px",
          mb: "-10px"
        }}
      >
        {item.value}
      </Typography>
      {item.execution ? (
        <>
          <LinearProgress
            variant="determinate"
            value={item.progress}
            sx={{
              mt: 1,
              height: 5,
              borderRadius: 4,
              bgcolor: "#ECEEF4",
              "& .MuiLinearProgress-bar": {
                bgcolor: "#6B4CF6",
                borderRadius: 4,
              },
            }}
          />
        </>
      ) : (
        <>
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            mt={0.8}
          >
            <Typography
              sx={{
                fontSize: 10,
                // color: "#667085",
                color: ["Cost Savings Realization (FY29)"].includes(item.title) ? "#383d5a" : "#667085",
                marginLeft: "-20px"
              }}
            >
              vs {item.target}
            </Typography>

            <Chip
              size="small"
              icon={<SouthRoundedIcon sx={{ fontSize: 14 }} />}
              label={item.percentage}
              sx={{
                height: 22,
                bgcolor: "#FFF1F1",
                color: "#D92D20",
                fontSize: 10,
                fontWeight: 700,
                "& .MuiChip-icon": {
                  color: "#D92D20",
                  fontSize: 12,
                },
              }}
            />
          </Stack>
          {item.ytdLY && (
            <Stack
              direction="row"
              justifyContent="space-between"
              alignItems="center"
              mt={0.8}
            >
              <Typography
                sx={{
                  fontSize: 10,
                  // color: "#667085",
                  color: "#667085",
                  marginLeft: "-20px"
                }}
              >
                {item.ytdLY}
              </Typography>
              <Chip
                size="small"
                icon={<NorthRoundedIcon sx={{ fontSize: 14 }} />}
                label={item.growth}
                sx={{
                  height: 22,
                  bgcolor: "#1e8e3e12",
                  color: "#18B96E",
                  fontSize: 10,
                  fontWeight: 700,
                  "& .MuiChip-icon": {
                    color: "#18B96E",
                    fontSize: 12,
                  },
                }}
              />
            </Stack>
          )}
        </>
      )}
    </Box>
  </Box>
);

const SavingsLeverCard = ({ item }) => {
  const Icon = item.Icon;

  return (
    <Card
      sx={{
        height: "100%",
        borderRadius: 1.5,
        overflow: "hidden",
        border: "1px solid #E5E7EB",
        boxShadow: "0 3px 12px rgba(15,23,42,.08)",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* ================= HEADER ================= */}

      <Box
        sx={{
          p: 1,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
        }}
      >
        <Box
          sx={{
            display: "flex",
            gap: 1.5,
            flex: 1,
          }}
        >
          <Avatar
            sx={{
              width: 24,
              height: 24,
              bgcolor: `${item.color}15`,
              color: item.color,
            }}
          >
            <Icon />
          </Avatar>

          <Box sx={{ display: "flex", gap: 1 }}>
            <Typography
              sx={{
                fontWeight: 600,
                fontSize: 12,
                // color: item.color,
                color: "#010035",
                mb: .5,
              }}
            >
              {item.title}
            </Typography>
            <Tooltip
              title={item.note}
              arrow
              placement="top"
            >
              <InfoOutlinedIcon
                sx={{
                  color: item.color,
                  fontSize: 18,
                  cursor: "pointer",
                }}
              />
            </Tooltip>

            {/* <Typography
              sx={{
                fontSize: 12,
                color: "#383d5a",
                lineHeight: 1.5,
              }}
            >
              {item.subtitle}
            </Typography> */}
          </Box>
        </Box>

        {item.status && (<Chip
          label={item.status}
          size="small"
          sx={{
            bgcolor: item.status === "On Track" ? "#1e8e3e12" : item.status === "Off Track" ? "#f299004a" : "#f29900",
            color: "#000000de",
            fontWeight: 400,
            borderRadius: 2,
            fontSize: 11
          }}
        />
        )}
      </Box>

      <Divider />

      {/* ================= PROGRESS ================= */}

      <Box
        sx={{
          py: 1,
          px: 2,
          display: "grid",
          gridTemplateColumns: "1fr",
          // gap: 3,
          alignItems: "center",
        }}
      >
        {/* <CircularProgressWithLabel
          value={item.progress}
          color={item.color}
        /> */}

        <Box>
          <Typography
            sx={{
              fontWeight: 600,
              fontSize: 12,
              color: "#344054",
              mb: 0.5,
            }}
          >
            Progress vs Target
          </Typography>

          <LinearProgress
            variant="determinate"
            value={item.progress}
            sx={{
              height: 6,
              borderRadius: 20,
              background: "#EEF2F7",

              "& .MuiLinearProgress-bar": {
                borderRadius: 20,
                // background: item.color,
                background: "#767a8191"
              },
            }}
          />

          <Box
            sx={{
              mt: 1,
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <Box>
              <Typography
                sx={{
                  fontSize: 12,
                  color: "#383d5a",
                }}
              >
                Current
              </Typography>

              <Typography
                sx={{
                  fontWeight: 700,
                  fontSize: 12,
                }}
              >
                {item.current}
              </Typography>
            </Box>

            <Box textAlign="right">
              <Typography
                sx={{
                  fontSize: 12,
                  color: "#383d5a",
                }}
              >
                Target
              </Typography>

              <Typography
                sx={{
                  fontWeight: 700,
                  fontSize: 12,
                }}
              >
                {item.targetRatio}
              </Typography>
            </Box>
          </Box>
        </Box>
      </Box>

      <Divider />
      <Box sx={{ py: 1, px: 2 }}>
        <Typography
          sx={{
            fontSize: 12,
            fontWeight: 700,
            // color: item.color,
            color: "#383d5a",
            mb: 1,
            letterSpacing: 0.5,
          }}
        >
          SAVINGS
        </Typography>

        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "1fr auto 1fr",
            alignItems: "stretch",
            gap: 5,
          }}
        >
          {/* YTD */}

          <Box>
            <Typography
              sx={{
                fontSize: 12,
                color: "#383d5a",
                mb: 1,
              }}
            >
              YTD Savings
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 700,
                color: "#767a8191",
                lineHeight: 1,
              }}
            >
              {item.ytd}
            </Typography>

            <Box sx={{ display: "flex", gap: 2 }}>

              <Typography
                sx={{
                  mt: 1,
                  fontSize: 12,
                  color: "#667085",
                }}
              >
                Target : {item.ytdTarget}
              </Typography>

              {item.ytdPercentage && (
                <Chip
                size="small"
                // icon={<NorthRoundedIcon sx={{ fontSize: 14 }} />}
                label={item.ytdPercentage}
                sx={{
                  mt: 0.75,
                  height: 22,
                  bgcolor: item.status === "On Track" ? "#1e8e3e12" : "#f299004a",
                  color: "#383d5a",
                  fontSize: 10,
                  fontWeight: 700,
                  "& .MuiChip-icon": {
                    color: item.status === "On Track" ? "#1e8e3e12" : "#f299004a",
                    fontSize: 12,
                  },
                }}
              />
                // <Chip
                //   label={item.ytdPercentage}
                //   size="small"
                //   sx={{
                //     mt: 0.75,
                //     bgcolor:
                //       item.ytdPercentage.includes("-")
                //         ? "#FEF3F2"
                //         : "#ECFDF3",
                //     color:
                //       item.ytdPercentage.includes("-")
                //         ? "#DC2626"
                //         : "#16A34A",
                //     fontWeight: 500,
                //     fontSize: 12,
                //   }}
                // />
              )}
            </Box>
          </Box>

          <Divider orientation="vertical" flexItem />

          {/* QTD */}

          <Box>
            <Typography
              sx={{
                fontSize: 12,
                color: "#383d5a",
                mb: 1,
              }}
            >
              QTD Savings
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 700,
                color: "#767a8191",
                lineHeight: 1,
              }}
            >
              {item.qtd}
            </Typography>

            <Box sx={{ display: "flex", gap: 2 }}>

              <Typography
                sx={{
                  mt: 1,
                  fontSize: 12,
                  color: "#667085",
                }}
              >
                Target : {item.qtdTarget}
              </Typography>
              

              {item.qtdPercentage && (
                <Chip
                size="small"
                // icon={<NorthRoundedIcon sx={{ fontSize: 14 }} />}
                label={item.qtdPercentage}
                sx={{
                  mt: 0.75,
                  height: 22,
                  // bgcolor: "#f299004a",
                  bgcolor: item.status === "On Track" ? "#1e8e3e12" : "#f299004a",
                  color: "#383d5a",
                  fontSize: 10,
                  fontWeight: 700,
                  "& .MuiChip-icon": {
                    color: item.status === "On Track" ? "#1e8e3e12" : "#f299004a",
                    fontSize: 12,
                  },
                }}
              />
              )}
            </Box>
          </Box>
        </Box>
      </Box>

      {/* <Divider /> */}

      {/* ================= FOOTER ================= */}

      {/* <Box
        sx={{
          mt: "auto",
          py: 1,
          px: 2,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          bgcolor: "#FAFBFC",
        }}
      >
        <Box
          sx={{
            display: "flex",
            gap: 1,
            alignItems: "center",
            flex: 1,
          }}
        >
          <InfoOutlinedIcon
            sx={{
              color: item.color,
              fontSize: 18,
            }}
          />

          <Typography
            sx={{
              fontSize: 11,
              color: "#667085",
              lineHeight: 1.5,
            }}
          >
            {item.note}
          </Typography>
        </Box>

        <ChevronRightIcon
          sx={{
            color: item.color,
          }}
        />
      </Box> */}
    </Card>
  );
}

export default function GPTGlobalDeliveryDeepDive() {
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();
  return (
    <Box
      sx={{
        width: "100%",
        bgcolor: "#F5F7FB",
        px: 1.5,
        py: 1,
        pb: "60px",
      }}
    >
      {/* ================================= */}
      {/* BREADCRUMB */}
      {/* ================================= */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          mb: "10px",
          alignItems: "center",
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Breadcrumbs
            separator={<NavigateNextIcon fontSize="small" />}
            sx={{
              // mb: 1,
              fontSize: 13,
            }}
          >
            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 600,
                color: "#010035",
              }}
            >
              Initiatives
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 600,
                color: "#010035",
              }}
            >
              GPT Global Delivery
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 700,
                color: "#010035",
              }}
            >
              Deep Dive
            </Typography>
          </Breadcrumbs>

          <IconButton
            onClick={() => navigate("/")}
            size="small"
            sx={{
              color: "#010035",
              marginLeft: "10px",
              fontSize: "5px",
            }}
          >
            <ArrowBackIcon fontSize="small" />
          </IconButton>
        </Box>

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            textAlign: "center",
            alignContent: "center",
          }}
        >
          <div
            style={{
              padding: "5px 10px",
              background: theme.tableHeaderBg,
              borderRadius: 6,
              color: "#ffffff",
              fontSize: 11,
              fontFamily: "var(--font-mono)",
              border: `1px solid ${theme.chipActiveBorder}`,
              fontWeight: 500,
            }}
          >
            Live ·{" "}
            {new Date().toLocaleDateString("en-US", {
              month: "short",
              day: "numeric",
              year: "numeric",
            })}
          </div>
        </Box>
      </Box>

      {/* ================================= */}
      {/* HEADER */}
      {/* ================================= */}
      <Card
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          borderRadius: 1.5,
          px: 1.5,
          py: 0.75,
          mb: 1,
        }}
      >
        <Grid container alignItems="center">
          <Grid size={{ xs: 12, md: 8 }}>
            <Stack direction="row" spacing={1.5} alignItems="center">
              <Avatar
                sx={{
                  width: 32,
                  height: 32,
                  bgcolor: "#383d5a",
                  color: "#fff",
                }}
              >
                <CloudOutlinedIcon sx={{ fontSize: 18 }} />
              </Avatar>

              <Box>
                <Stack direction="row" spacing={1} alignItems="center">
                  <Typography
                    sx={{
                      fontSize: 16,
                      fontWeight: 700,
                      color: "#010035",
                      lineHeight: 1,
                    }}
                  >
                    GPT Global Delivery
                  </Typography>

                  <Chip
                    label=""
                    size="small"
                    sx={{
                      bgcolor: "#F4A622",
                      color: "#000",
                      fontWeight: 700,
                      height: 22,
                      width: 22,
                      fontSize: 10,
                    }}
                  />
                </Stack>
                <Typography
                  sx={{
                    fontSize: 12,
                    mt: 0.25,
                    color: "#383d5a",
                    lineHeight: 1.3,
                    maxWidth: "100%",
                  }}
                >
                  {/* AI-led Global Delivery Transformation */}
                </Typography>

                <Typography
                  sx={{
                    fontSize: 10,
                    mt: 0.25,
                    color: "#475569",
                    lineHeight: 1.3,
                    maxWidth: "100%",
                  }}
                >
                  Optimizing Workforce distribution, resource mix and geographic footprint to achieve $50M - $70M in potential cost saving
                </Typography>
              </Box>
            </Stack>
          </Grid>

          <Grid size={{ xs: 12, md: 4 }}>
            <Stack
              direction="row"
              spacing={1}
              justifyContent="flex-end"
              alignItems="center"
            >
              <Button
                variant="outlined"
                startIcon={<ShareOutlinedIcon sx={{ fontSize: 14 }} />}
                size="small"
                sx={{
                  minWidth: 75,
                  height: 28,
                  fontSize: 11,
                  textTransform: "none",
                  px: 1,
                }}
              >
                Share
              </Button>

              <Button
                variant="outlined"
                startIcon={<DownloadOutlinedIcon sx={{ fontSize: 14 }} />}
                size="small"
                sx={{
                  minWidth: 80,
                  height: 28,
                  fontSize: 11,
                  textTransform: "none",
                  px: 1,
                }}
              >
                Export
              </Button>
            </Stack>
          </Grid>
        </Grid>
      </Card>

      {/* ================================= */}
      {/* SUMMARY CARD */}
      {/* ================================= */}



      <Card
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          borderRadius: 2,
          p: 1,
        }}
      >
        <Grid
          container
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "1fr",
              sm: "repeat(2,1fr)",
              md: "repeat(3,1fr)",
              // lg: "repeat(8,minmax(0,1fr))",
              // lg: "1.3fr 1fr 1fr 1fr 3fr"
              lg: "repeat(4, 1fr)"
            },
            alignItems: "stretch",
            gap: 1,
          }}
        >
          {/* {infoCards.map((item) => (
          <InfoCard
            key={item.title}
            item={item}
          />
        ))} */}
          {/* {summaryCards1.map((item, index) => (
          <SavingsCard
            key={item.title}
            item={item}
            last={index === summaryCards1.length}
          />
        ))} */}
          {summaryCard2.map((item, index) => (
            <SavingsCards2
              key={item.title}
              item={item}
              last={index === summaryCard2.length}
            />
          ))}
          {/* <Box
            sx={{
              height: "100%",
              display: "flex",
              flexDirection: "column",
              justifyContent: "flex-start",
              px: 1,
              borderRight: "1px solid rgba(0,0,0,0.12)",
            }}

          >
            <>
        <Typography sx={labelStyle}>Summary</Typography>

        <Typography
          sx={{
            mt: 1,
            fontSize: 11,
            color: "#383D5A",
            lineHeight: 1.4,
          }}
        >
          Geo mix optimization is ahead of plan while resource mix and workforce optimization require acceleration.
          
        </Typography>
      </>
          </Box> */}


        </Grid>
      </Card>


      <Grid
        container
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            sm: "repeat(2,1fr)",
            lg: `repeat(${savingsCards.length},1fr)`,
          },
          gap: 2,
          mt: 2,
        }}
      >
        {savingsCards.map((item) => (
          <SavingsLeverCard
            key={item.id}
            item={item}
          />
        ))}
      </Grid>


      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "10px",
          mt: 1,
        }}
      >
        <Card
          elevation={0}
          sx={{
            border: "1px solid #E2E8F0",
            borderRadius: 1.5,
            p: "10px",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Typography
            sx={{
              fontSize: 12,
              fontWeight: 700,
              color: "#010035",
              mb: 1,
            }}
          >
            SAVINGS TARGET SUMMARY
          </Typography>
          <Table
            size="small"
            sx={{
              tableLayout: "fixed", // important for width control

              "& .MuiTableCell-root": {
                fontSize: "10px",
                color: "#383d5a",
                textAlign: "left",
                py: 0.6,
              },

              "& .MuiTableHead-root .MuiTableCell-root": {
                backgroundColor: "#0A2E78",
                color: "#fff",
                fontWeight: 700,
                borderBottom: "none",
              },
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: "30%" }}>Savings Lever</TableCell>

                <TableCell sx={{ width: "20%" }}>Target</TableCell>

                <TableCell sx={{ width: "50%" }}>Description</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {milestones.map((row) => (
                <TableRow key={row.milestone}>
                  <TableCell sx={{}}>
                    {row.milestone}
                  </TableCell>

                  <TableCell sx={{}}>
                    {row.target}
                  </TableCell>

                  <TableCell sx={{}}>
                    {row.description}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
        {/* <Card
          elevation={0}
          sx={{
            border: "1px solid #E2E8F0",
            borderRadius: 1.5,
            p: "10px",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Typography
            sx={{
              fontSize: 12,
              fontWeight: 700,
              color: "#010035",
              mb: 1,
            }}
          >
            POTENTIAL LONG-TERM TALENT SPEND REDUCTION
          </Typography>
          <Box
                      sx={{
                        // border: "1px solid #E2E8F0",
                        borderRadius: 1.5,
                        // height: "100%",
                        px: 1.5,
                        py: 1,
                        display: "flex",
                        mt: "20px",
                        // flexDirection: "column",
                        // justifyContent: "center",
                        // alignItems: "center"
                      }}
                  >
                      <Stack direction="row" spacing={1} alignItems="center">
                          <Avatar
                              sx={{
                                  bgcolor: "#383d5a",
                                  color: "#fff",
                                  width: 70,
                                  height: 70,
                              }}
                          >
                             {"$"}
                          </Avatar>

                          <Stack spacing={0.5}>                             

                               
                                  <Typography  sx={{
                                    fontSize: 22,
                                    fontWeight: 700,
                                    color: "#010035",
                                    lineHeight: 1,
                                    marginLeft: "30px",
                                  }}
                    >
                                      {`$50M - $70M+`}
                                  </Typography>
                              

                              <Typography sx={{
                                  fontSize: 10,
                                  color: "#383d5a",
                                  marginLeft: "30px",
                              }}
                              >
                                 {`Potential long-term talent spend reduction of $50M - $70M+ through site consolidation, geo-mix shifts, workforce mix rebalancing and Headcount reduction, `}
                              </Typography>
                          </Stack>
                      </Stack>
                  </Box>
          
        </Card> */}

        {/* ================= RISKS & ISSUES ================= */}
        <Card
          elevation={0}
          sx={{
            border: "1px solid #E2E8F0",
            borderRadius: 1.5,
            p: "10px",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Typography
            sx={{
              fontSize: 12,
              fontWeight: 700,
              color: "#010035",
              mb: 1,
            }}
          >
            RISKS & DEPENDENCIES
          </Typography>

          <Table
            size="small"
            sx={{
              tableLayout: "fixed", // 🔥 important for controlled columns

              "& .MuiTableCell-root": {
                fontSize: "10px",
                color: "#383d5a",
                textAlign: "left",
                py: 0.6,
              },

              "& .MuiTableHead-root .MuiTableCell-root": {
                backgroundColor: "#0A2E78",
                color: "#fff",
                fontWeight: 700,
                borderBottom: "none",
              },
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: "50%" }}>Risk / Dependency</TableCell>
                <TableCell sx={{ width: "20%" }}>Impact</TableCell>
                <TableCell sx={{ width: "30%" }}>Status</TableCell>
                {/* <TableCell sx={{ width: "42%" }}>Mitigation</TableCell> */}
              </TableRow>
            </TableHead>

            <TableBody>
              {risks.map((risk) => (
                <TableRow key={risk.risk}>
                  <TableCell>{risk.risk}</TableCell>

                  <TableCell>
                    <ImpactBadge value={risk.impact} />
                  </TableCell>

                  <TableCell>
                    <StatusDotText value={risk.status} />
                  </TableCell>

                  {/* <TableCell>{risk.mitigation}</TableCell> */}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </Box>
      <Card
        elevation={0}
        sx={{
          mt: 1,
          border: "1px solid #E2E8F0",
          borderRadius: 1.5,
          p: 1.5,
        }}
      >
        <Typography
          sx={{
            fontSize: 12,
            fontWeight: 700,
            color: "#010035",
            mb: 1,
          }}
        >
          KEY DOCUMENTS & LINKS
        </Typography>

        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "repeat(7, 1fr)",
            gap: 1,
          }}
        >
          {documents.map((doc) => (
            <Card
              key={doc.title}
              elevation={0}
              sx={{
                border: "1px solid #E2E8F0",
                borderRadius: 1,
                //   height: 82,
                px: 1,
                py: 1,
                cursor: "pointer",

                "&:hover": {
                  bgcolor: "#F8FAFC",
                },
              }}
            >
              <Stack direction="row" spacing={1} alignItems="flex-start">
                <Typography
                  sx={{
                    fontSize: 24,
                    lineHeight: 1,
                  }}
                >
                  {doc.icon}
                </Typography>

                <Box>
                  <Typography
                    sx={{
                      fontSize: 11,
                      fontWeight: 500,
                      color: "#010035",
                      whiteSpace: "pre-line",
                      lineHeight: 1.3,
                    }}
                  >
                    {doc.title}
                  </Typography>

                  <Typography
                    sx={{
                      fontSize: 10,
                      color: "#2563EB",
                      mt: 0.5,
                      fontWeight: 500,
                    }}
                  >
                    View
                  </Typography>
                </Box>
              </Stack>
            </Card>
          ))}
        </Box>
      </Card>
      <Card
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          // borderRadius: 2,
          // mt: 2,
          py: 1,
          px: 1.5,
          position: "fixed",
          bottom: 0,
          left: 10,
          right: 10,
          zIndex: 1000,
          bgcolor: "#F5F7FB"
          // borderRadius: 0,
        }}
      >
        <Grid
          container
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "repeat(4,1fr)",
              sm: "repeat(4,1fr)",
              md: "repeat(4,1fr)",
              lg: "repeat(4,1fr)"
            },
            alignItems: "stretch",
            gap: 1,
          }}
        >
          {infoCards.map((item) => (
            <InfoCard
              key={item.title}
              item={item}
            />
          ))}
        </Grid>
      </Card>
    </Box>
  );
}

function LegendItem({ color, label, dashed }: any) {
  return (
    <Stack direction="row" spacing={2} alignItems="center">
      <Box
        sx={{
          width: 18,
          borderTop: `2px ${dashed ? "dashed" : "solid"} ${color}`,
        }}
      />

      <Typography
        sx={{
          fontSize: 10,
          fontWeight: 600,
          color: "#0A2E78",
        }}
      >
        {label}
      </Typography>
    </Stack>
  );
}

function FooterCard({ icon, title, value }: any) {
  return (
    <Stack
      direction="row"
      spacing={1}
      alignItems="center"
      sx={{
        minWidth: 95,
      }}
    >
      <Box
        sx={{
          display: "flex",
          "& .MuiSvgIcon-root": {
            fontSize: 14, // reduce icon size
          },
        }}
      >
        {icon}
      </Box>

      <Box>
        <Typography
          sx={{
            fontSize: 8,
            fontWeight: 700,
            color: "#0B226F",
          }}
        >
          {title}
        </Typography>

        <Typography
          sx={{
            fontSize: 9,
            color: "#344054",
          }}
        >
          {value}
        </Typography>
      </Box>
    </Stack>
  );
}
