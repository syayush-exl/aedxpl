import React from "react";
import {
  Avatar,
  Box,
  Breadcrumbs,
  Button,
  Card,
  Chip,
  Divider,
  Grid,
  LinearProgress,
  Stack,
  Typography,
  Paper,
  CardContent,
  IconButton,
  CircularProgress,
} from "@mui/material";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import ShareOutlinedIcon from "@mui/icons-material/ShareOutlined";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import QueryStatsOutlinedIcon from "@mui/icons-material/QueryStatsOutlined";
import ReportProblemOutlinedIcon from "@mui/icons-material/ReportProblemOutlined";

import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import ShieldOutlinedIcon from "@mui/icons-material/ShieldOutlined";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import DashboardCustomizeOutlinedIcon from "@mui/icons-material/DashboardCustomizeOutlined";
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import FlagOutlinedIcon from "@mui/icons-material/FlagOutlined";
import ShowChartOutlinedIcon from "@mui/icons-material/ShowChartOutlined";
import ArrowDropUpRoundedIcon from "@mui/icons-material/ArrowDropUpRounded";
import ArrowDropDownRoundedIcon from "@mui/icons-material/ArrowDropDownRounded";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import Tooltip from "@mui/material/Tooltip";

import AttachMoneyRoundedIcon from "@mui/icons-material/AttachMoneyRounded";
import GroupsRoundedIcon from "@mui/icons-material/GroupsRounded";
import SouthRoundedIcon from "@mui/icons-material/SouthRounded";
import NorthRoundedIcon from "@mui/icons-material/NorthRounded";
import ErrorOutlineOutlinedIcon from "@mui/icons-material/ErrorOutlineOutlined";
import AvTimerOutlinedIcon from "@mui/icons-material/AvTimerOutlined";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import SupportAgentOutlinedIcon from "@mui/icons-material/SupportAgentOutlined";
import CrisisAlertOutlinedIcon from "@mui/icons-material/CrisisAlertOutlined";
import SyncProblemOutlinedIcon from "@mui/icons-material/SyncProblemOutlined";

import GroupsIcon from "@mui/icons-material/Groups";
import PublicIcon from "@mui/icons-material/Public";

import { useTheme } from "../../theme-context";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useNavigate } from "react-router-dom";


const labelStyle = {
  fontSize: "11px",
  fontWeight: 500,
  color: "#010035",
};

const valueStyle = {
  fontSize: "42px",
  fontWeight: 700,
  color: "#0A2E78",
};

const milestones = [
  {
    milestone: "Resource Mix Savings Target ($)",
    target: "$40M",
    description: "Savings from FTE/Contractor rebalancing",
  },
  {
    milestone: "Geo Mix Savings Target ($)",
    target: "$10M - $30M",
    description: "Savings from geo mix shift",
  },
  {
    milestone: "Others Savings Target ($)",
    target: "-",
    description: "Savings from Microsite reduction",
  },

];
const progressVsPlan = [
  {
    milestone: "Vendor Resiliency framework",
    plan: "FY2026 Q1",
    planTarget: "Completed",
    status: "On Track",
  },
  {
    milestone: "Advanced monitoring & Observability",
    plan: "FY2026 Q2",
    planTarget: "Completed",
    status: "On Track",
  },
  {
    milestone: "Disaster Recovery Validation",
    plan: "FY2026 Q3",
    planTarget: "In Progress",
    status: "In Progress",
  },
  {
    milestone: "Vendor risk assessment automation",
    plan: "FY2027 Q1",
    planTarget: "Planned",
    status: "Planned",
  },
  {
    milestone: "Predictive Risk Monitoring",
    plan: "FY2027 Q2",
    planTarget: "Planned",
    status: "Planned",
  },
]

const risks = [
  {
    risk: "Cloud infrastructure availability",
    impact: "High",
    status: "On Track",
    mitigation: "Dependency mapping & refactor plan",
  },
  {
    risk: "Disaster Recovery Readiness",
    impact: "High",
    status: "Needs Attention",
    mitigation: "Accelerated assessment",
  },
  {
    risk: "Monitoring & observability",
    impact: "Medium",
    status: "Needs Attention",
    mitigation: "Additional teams & capacity",
  },
  {
    risk: "Incident response capability",
    impact: "High",
    status: "At Risk",
    mitigation: "Automation tooling",
  },
  {
    risk: "Cyber Security Resilience",
    impact: "Medium",
    status: "Needs Attention",
    mitigation: "Automation tooling",
  },
];
const documents = [
  {
    icon: "📊",
    title: "Initiative Overview (One Pager) (PPT)",
  },
  {
    icon: "📗",
    title: "Application Inventory\n(XLSX)",
  },
  {
    icon: "📈",
    title: "Migration Factory\nDashboard",
  },
  {
    icon: "📘",
    title: "FinOps Assessment\n(DOCX)",
  },
  {
    icon: "📕",
    title: "Architecture Review\n(PDF)",
  },
  {
    icon: "🟢",
    title: "Steering Committee\nNotes",
  },
  {
    icon: "📄",
    title: "RAID Log",
  },
];

const infoCards = [
  {
    title: "Initiative Owner",
    value: "Sachin",
    subtitle: "",
    icon: <PersonOutlineIcon color="primary" sx={{ fontSize: 16 }} />,
  },
  {
    title: "FAST Pillar",
    value: "Transform",
    subtitle: "",
    icon: (
      <DashboardCustomizeOutlinedIcon
        color="primary"
        sx={{ fontSize: 16 }}
      />
    ),
  },
  {
    title: "Timeline",
    value: "FY26 - FY29",
    subtitle: "(4 Year Program)",
    icon: (
      <CalendarMonthOutlinedIcon color="primary" sx={{ fontSize: 16 }} />
    ),
  },
  {
    title: "Current Phase",
    value: "FY27",
    subtitle: "Execution Phase",
    icon: <FlagOutlinedIcon color="primary" sx={{ fontSize: 16 }} />,
  },
  // {
  //   title: "Key Takeaway",
  //   value:
  //     "Geo mix optimization is ahead of plan while resource mix and workforce optimization require acceleration.",
  //   subtitle: "",
  //   icon: null,
  //   isTakeaway: true,
  // },
];
const summaryCard2 = [
  {
    title: "Overall Progress",
    value: "20%",
    target: "100%",
    progress: 20,
    percentage: "71%",
    icon: ShowChartOutlinedIcon,
    iconBg: "#F1EBFF",
    iconColor: "#6B4CF6",
  },
  {
    title: "Count of Incidents",
    value: "260",
    target: "",
    ytdLY: "$5M (YTD LY)",
    growth: "+ $3M",
    progress: 47,
    percentage: "53%",
    icon: ReportProblemOutlinedIcon,
    iconBg: "#F1EBFF",
    iconColor: "#6B4CF6",
  },
  // {
  //   title: "Total Savings (QTD)",
  //   value: "$3M",
  //   target: "$5M",
  //   progress: 60,
  //   ytdLY: "$2M (QTD LQ)",
  //   growth: "+ $1M",
  //   percentage: "40%",
  //   icon: AttachMoneyRoundedIcon,
  //   iconBg: "#EAF3FF",
  //   iconColor: "#1E88E5",
  // },
  // {
  //   title: "Total Savings (MTD)",
  //   value: "$1M",
  //   target: "$1.5M",
  //   progress: 67,
  //   ytdLY: "$0.5M (MTD LM)",
  //   growth: "+ $0.5M",
  //   percentage: "33%",
  //   icon: AttachMoneyRoundedIcon,
  //   iconBg: "#E8F7EC",   
  //   iconColor: "#28A745",
  // },
]

const savingsCards = [
  {
    id: 1,
    title: "Client Availability",
    subtitle: "Optimize workforce composition for maximum efficiency.",
    status: "On Track",

    progress: 99,

    current: "99.9921",
    targetRatio: ">=99.99% Uptime for Clients",
    growth: "0.0011% Improved",

    ytd: "$-",
    ytdTarget: "—",
    ytdPercentage: "",

    qtd: "$-",
    qtdTarget: "—",
    qtdPercentage: "",

    color: "#635BFF",

    Icon: GroupsIcon,

    note:
      "Client Availability measures a percentage of time that services are available and accessible to client without interruption.",
  },

  {
    id: 2,
    title: "MTTD",
    subtitle: "Strategic geo shift to optimize cost arbitrage and delivery.",
    status: "On Track",

    progress: 100,

    current: "41.39% YoY",
    targetRatio: ">=15% YoY",

    ytd: "$-",
    ytdTarget: "—",
    ytdPercentage: "",

    qtd: "$-",
    qtdTarget: "—",
    qtdPercentage: "",

    color: "#06B6D4",

    Icon: VisibilityOutlinedIcon,

    note:
      "MTTD (Mean time to detect) is the average time it takes to detect an incident after it occurs.",
  },
  {
    id: 3,
    title: "MTTR",
    subtitle: "MTTR (Mean time to Resolve) measures a average time taken to resolve an incident after it has been detected.",
    status: "Off Track",

    progress: 67,

    current: "10.21% YoY",
    targetRatio: ">=15% YoY",

    ytd: "$-",
    ytdTarget: "—",
    ytdPercentage: "",

    qtd: "$-",
    qtdTarget: "—",
    qtdPercentage: "",

    color: "#06B6D4",

    Icon: AvTimerOutlinedIcon,

    note:
      "MTTR (Mean time to Resolve) measures a average time taken to resolve an incident after it has been detected.",
  },
  {
    id: 4,
    title: "Critical Incident Volume",
    subtitle: "Strategic geo shift to optimize cost arbitrage and delivery.",
    status: "On Track",

    progress: 100,

    current: "22.5% YoY",
    targetRatio: ">=10% YoY",

    ytd: "$-",
    ytdTarget: "—",
    ytdPercentage: "",

    qtd: "$-",
    qtdTarget: "—",
    qtdPercentage: "",

    color: "#06B6D4",

    Icon: ErrorOutlineOutlinedIcon,

    note:
      "Critical Incident Volume measures the total number of major incidents that cause significant service disruption.",
  },

];
const metrics = [
  {
    goal: "Availability",
    metric: "Client Availability",
    target: "99.999%",
    fy25: "99.9878",
    fy25YTD: "99.9910",
    fy26YTD: "99.9921",
    improvement: "0.0011%",
    status: "Improved",
    track: "On Track",
    Icon: GroupsIcon,
    color: "#635BFF",
    note: "Client Availability measures a percentage of time that services are available and accessible to client without interruption.",
  },
  {
    goal: "Recovery",
    metric: "MTTD",
    target: "▼ ≥15% YoY",
    fy25: "8.73",
    fy25YTD: "9.47",
    fy26YTD: "5.55",
    improvement: "41.39%",
    status: "Improved",
    track: "On Track",
    Icon: VisibilityOutlinedIcon,
    color: "#06B6D4",
    note: "MTTD (Mean time to detect) is the average time it takes to detect an incident after it occurs.",
  },
  {
    goal: "Recovery",
    metric: "MTTR",
    target: "▼ ≥15% YoY",
    fy25: "22.86",
    fy25YTD: "22.88",
    fy26YTD: "20.52",
    improvement: "10.21%",
    status: "Improved",
    track: "Off Track",
    Icon: AvTimerOutlinedIcon,
    color: "#06B6D4",
    note: "MTTR (Mean time to Resolve) measures a average time taken to resolve an incident after it has been detected.",
  },
  {
    goal: "Incidents",
    metric: "Critical Incidents Volume",
    target: "▼ ≥10% YoY",
    fy25: "452",
    fy25YTD: "360",
    fy26YTD: "279",
    improvement: "22.50%",
    status: "Improved",
    track: "On Track",
    Icon: ErrorOutlineOutlinedIcon,
    color: "#06B6D4",
    note: "Critical Incident Volume measures the total number of major incidents that cause significant service disruption.",
  },
  {
    goal: "Recovery",
    metric: "MTTE",
    target: "▼ ≥15% YoY",
    fy25: "2.90",
    fy25YTD: "3.53",
    fy26YTD: "3.97",
    improvement: "12.46%",
    status: "Declined",
    track: "Off Track",
    Icon: SupportAgentOutlinedIcon,
    color: "#06B6D4",
    note: "",
  },
  {
    goal: "Recovery",
    metric: "MTTF",
    target: "▼ ≥15% YoY",
    fy25: "9.19",
    fy25YTD: "8.57",
    fy26YTD: "9.55",
    improvement: "11.44%",
    status: "Declined",
    track: "Off Track",
    Icon: CrisisAlertOutlinedIcon,
    color: "#06B6D4",
    note: "",
  },
  {
    goal: "Change driven Incidents",
    metric: "CBC Incidents",
    target: "▼ ≥10% YoY",
    fy25: "210",
    fy25YTD: "167",
    fy26YTD: "116",
    improvement: "30.54%",
    status: "Improved",
    track: "On Track",
    Icon: CrisisAlertOutlinedIcon,
    color: "#06B6D4",
    note: "",
  },
  {
    goal: "Change driven Incidents",
    metric: "Change Incident Failure Rate",
    target: "▼ ≥10% YoY",
    fy25: "2.40",
    fy25YTD: "2.61",
    fy26YTD: "1.80",
    improvement: "31.03%",
    status: "Improved",
    track: "On Track",
    Icon: SyncProblemOutlinedIcon,
    color: "#06B6D4",
    note: "",
  },

];

const BLUE = "#1565FF";
const GREEN = "#0CA44B";


/* ===================== CONFIG ===================== */
const statusConfig = {
  Completed: { color: "#16A34A", type: "filled" },
  "In Progress": { color: "#F59E0B", type: "outlined" },
  Planned: { color: "#2563EB", type: "outlined" },
};

const impactConfig = {
  High: "#DC2626",
  Medium: "#F59E0B",
  Low: "#18B96E",
};

/* ===================== IMPACT BADGE ===================== */
const ImpactBadge = ({ value }) => {
  const color = impactConfig[value] || "#0A2E78";

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
      <Typography sx={{ fontSize: 10, color }}>{value}</Typography>
    </Box>
  );
};

const statusColorMap = {
  "At Risk": "#DC2626",
  "Needs Attention": "#F59E0B",
  "On Track": "#16A34A",
};

const StatusDotText = ({ value }) => {
  const color = statusColorMap[value] || "#0A2E78";

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.6 }}>
      {/* dot */}
      <Box
        sx={{
          width: 8,
          height: 8,
          borderRadius: "50%",
          backgroundColor: color,
        }}
      />

      {/* text */}
      <Typography
        sx={{
          fontSize: 10,
          fontWeight: 600,
          color: color,
          lineHeight: 1,
        }}
      >
        {value}
      </Typography>
    </Box>
  );
};

const InfoCard = ({ item }: any) => (
  <Box
    sx={{
      height: "100%",
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-start",
      px: 1,
      borderRight: "1px solid rgba(0,0,0,0.12)",
    }}
  >
    {item.isTakeaway ? (
      <>
        <Typography sx={labelStyle}>{item.title}</Typography>

        <Typography
          sx={{
            mt: 1,
            fontSize: 11,
            color: "#383D5A",
            lineHeight: 1.4,
          }}
        >
          {item.value}
        </Typography>
      </>
    ) : (
      <>
        <Stack direction="row" spacing={0.5} alignItems="center">
          {item.icon}
          <Typography sx={labelStyle}>{item.title}</Typography>
        </Stack>
        <Box sx={{ display: "flex", gap: 1, mt: 0.6, justifyItems: "center", alignItems: "center" }}>

          <Typography
            sx={{
              pl: "20px",
              // mt: 0.6,
              fontSize: 12,
              fontWeight: 700,
              color: "#010035",
            }}
          >
            {item.value}
          </Typography>

          <Typography
            sx={{
              // pl: "20px",
              fontSize: 10,
              // mt: 0.6,
              color: "text.secondary",
            }}
          >
            {item.subtitle || "\u00A0"}
          </Typography>
        </Box>
      </>
    )}
  </Box>
);

const SavingsCards2 = ({ item, last = false }: any) => {
  const Icon = item.icon;

  return (
    <Box
      sx={{
        height: "100%",
        display: "flex",
        // alignItems: "center",
        gap: 0.5,
        px: "5px",
        borderRight: last ? "none" : "1px solid rgba(0,0,0,0.12)",
      }}
    >
      <Avatar
        sx={{
          width: 24,
          height: 24,
          bgcolor: item.iconBg,
          color: item.iconColor,
        }}
      >
        <Icon />
      </Avatar>

      <Box flex={1}>
        <Typography
          sx={{
            fontSize: 11,
            color: "#010035",
            fontWeight: 500,
          }}
        >
          {item.title}
        </Typography>

        {/* <Typography
        sx={{
          fontWeight: 700,
          fontSize: 12,
          color: "#767a8191",
          mt: "10px",
          mb: "-10px"
        }}
      >
        {item.value}
      </Typography> */}
        {item.title === "Count of Incidents" ? (
          <>
            {/* <LinearProgress
            variant="determinate"
            value={item.progress}
            sx={{
              mt: 1,
              height: 5,
              borderRadius: 4,
              bgcolor: "#ECEEF4",
              "& .MuiLinearProgress-bar": {
                bgcolor: "#6B4CF6",
                borderRadius: 4,
              },
            }}
          /> */}
            <Box sx={{ mt: 1, }}>
              <Typography sx={{
                fontSize: 12,
                // color: "#64748B",
                color: "#767a8191",
                fontWeight: 600
              }}>
                Current: 279
              </Typography>
              <Box sx={{ display: "flex", gap: 1 }}>
                <Typography sx={{
                  fontSize: 12,
                  // color: "#64748B",
                  color: "#383d5a",
                  fontWeight: 600
                }}>
                  22.3% YoY improvement
                </Typography>
                <ArrowDropUpRoundedIcon
                  sx={{
                    mt: "-10px",
                    fontSize: 42,
                    color: "#16A34A",
                    // mr: -0.5,
                  }}
                />
              </Box>
              <Typography sx={{
                fontSize: 12,
                mt: "-10px",
                // color: "#64748B",
                color: "#767a8191",
                fontWeight: 600
              }}>
                {`Target: >= 10%`}
              </Typography>


            </Box>
          </>
        ) : (
          <>
            <Box
              sx={{
                position: "relative",
                pt: 1.5,
                mt: 1,
              }}
            >
              <Typography
                sx={{
                  position: "absolute",
                  left: `${item.progress ?? 0
                    }%`,
                  transform: "translateX(-50%)",
                  top: -2,

                  fontSize: 10,
                  fontWeight: 700,

                  // color: metric.label === "Breakthrough Overall Revenue" ? "#767a8191" : getProgressBarColor(
                  //   metric.value ?? metric.progress ?? 0
                  // ),
                  // color: "#767a8191",
                  color: "#767a8191",

                  maxWidth: 40,
                  textAlign: "center",
                }}
              >
                {item.progress ?? 0}%
              </Typography>

              <LinearProgress
                variant="determinate"
                value={item.progress ?? 0}
                sx={{
                  height: 5,
                  borderRadius: 10,
                  bgcolor: "#E5E7EB",

                  "& .MuiLinearProgress-bar": {
                    borderRadius: 10,
                    // bgcolor: "#767a8191"
                    bgcolor: "#767a8191",
                    // bgcolor: getProgressBarColor(
                    //   metric.value ?? metric.progress ?? 0
                    // ),
                  },
                }}
              />


              <Box
                sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  mt: 0.4,
                }}
              >
                <Typography
                  sx={{
                    fontSize: 10,
                    // color: "#64748B",
                    color: "#767a8191",
                    fontWeight: 600
                  }}
                >
                  {item.value}
                </Typography>

                <Typography
                  sx={{
                    fontSize: 10,
                    // color: "#64748B",
                    color: ["Cost Savings Realization (FY29)"].includes(item.title) ? "#383d5a" : "#767a8191",
                    fontWeight: 600
                  }}
                >
                  {item.target}
                </Typography>
              </Box>
            </Box>

            {item.ytdLY && (
              <Stack
                direction="row"
                justifyContent="start"
                alignItems="center"
                gap={1}
                mt={0.8}
              >
                <Typography
                  sx={{
                    fontSize: 10,
                    // color: "#667085",
                    color: "#667085",
                    marginLeft: "-20px"
                  }}
                >
                  {item.ytdLY}
                </Typography>
                <Chip
                  size="small"
                  icon={<NorthRoundedIcon sx={{ fontSize: 14 }} />}
                  label={item.growth}
                  sx={{
                    height: 22,
                    bgcolor: "#1e8e3e12",
                    color: "#18B96E",
                    fontSize: 10,
                    fontWeight: 700,
                    "& .MuiChip-icon": {
                      color: "#18B96E",
                      fontSize: 12,
                    },
                  }}
                />
              </Stack>
            )}
          </>
        )}
      </Box>
    </Box>
  );
}

const SavingsLeverCard = ({ item }) => {
  const Icon = item.Icon;

  return (
    <Card
      sx={{
        height: "100%",
        borderRadius: 1.5,
        overflow: "hidden",
        border: "1px solid #E5E7EB",
        boxShadow: "0 3px 12px rgba(15,23,42,.08)",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* ================= HEADER ================= */}

      <Box
        sx={{
          p: 1,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
        }}
      >
        <Box
          sx={{
            display: "flex",
            gap: 1.5,
            flex: 1,
          }}
        >
          <Avatar
            sx={{
              width: 24,
              height: 24,
              bgcolor: `${item.color}15`,
              color: item.color,
            }}
          >
            <Icon />
          </Avatar>

          <Box sx={{ display: "flex", gap: 1 }}>
            <Typography
              sx={{
                fontWeight: 600,
                fontSize: 12,
                // color: item.color,
                color: "#010035",
                mb: .5,
              }}
            >
              {item.title}
            </Typography>
            <Tooltip
              title={item.note}
              arrow
              placement="top"
            >
              <InfoOutlinedIcon
                sx={{
                  color: item.color,
                  fontSize: 18,
                  cursor: "pointer",
                }}
              />
            </Tooltip>

            {/* <Typography
              sx={{
                fontSize: 12,
                color: "#383d5a",
                lineHeight: 1.5,
              }}
            >
              {item.subtitle}
            </Typography> */}
          </Box>
        </Box>

        {item.status && (<Chip
          label={item.status}
          size="small"
          sx={{
            bgcolor: item.status === "On Track" ? "#18B96E" : item.status === "Off Track" ? "#F4A622" : "#f29900",
            color: "#000000de",
            fontWeight: 400,
            borderRadius: 2,
            fontSize: 11
          }}
        />
        )}
      </Box>

      <Divider />

      {/* ================= PROGRESS ================= */}

      <Box
        sx={{
          py: 1,
          px: 2,
          display: "grid",
          gridTemplateColumns: "1fr",
          // gap: 3,
          alignItems: "center",
        }}
      >
        {/* <CircularProgressWithLabel
          value={item.progress}
          color={item.color}
        /> */}

        <Box>
          <Typography
            sx={{
              fontWeight: 600,
              fontSize: 12,
              color: "#344054",
              mb: 0.5,
            }}
          >
            Progress vs Target
          </Typography>

          <LinearProgress
            variant="determinate"
            value={item.progress}
            sx={{
              height: 6,
              borderRadius: 20,
              background: "#EEF2F7",

              "& .MuiLinearProgress-bar": {
                borderRadius: 20,
                // background: item.color,
                background: "#767a8191"
              },
            }}
          />

          <Box
            sx={{
              mt: 1,
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <Box>
              <Typography
                sx={{
                  fontSize: 12,
                  color: "#383d5a",
                }}
              >
                Current
              </Typography>

              <Typography
                sx={{
                  fontWeight: 600,
                  fontSize: 11,
                }}
              >
                {item.current}
              </Typography>
            </Box>

            <Box textAlign="right">
              <Typography
                sx={{
                  fontSize: 12,
                  color: "#383d5a",
                }}
              >
                Target
              </Typography>

              <Typography
                sx={{
                  fontWeight: 600,
                  fontSize: 11,
                }}
              >
                {item.targetRatio}
              </Typography>
            </Box>
          </Box>
        </Box>
      </Box>

      <Divider />
      {/* <Box sx={{ py: 1, px: 2 }}>
        <Typography
          sx={{
            fontSize: 12,
            fontWeight: 700,
            
            color: "#383d5a",
            mb: 1,
            letterSpacing: 0.5,
          }}
        >
          SAVINGS
        </Typography>

        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "1fr auto 1fr",
            alignItems: "stretch",
            gap: 5,
          }}
        >
        

          <Box>
            <Typography
              sx={{
                fontSize: 12,
                color: "#383d5a",
                mb: 1,
              }}
            >
              YTD Savings
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 700,
                color: "#767a8191",
                lineHeight: 1,
              }}
            >
              {item.ytd}
            </Typography>

            <Box sx={{ display: "flex", gap: 2 }}>

              <Typography
                sx={{
                  mt: 1,
                  fontSize: 12,
                  color: "#667085",
                }}
              >
                Target : {item.ytdTarget}
              </Typography>

              {item.ytdPercentage && (
                <Chip
                size="small"
                
                label={item.ytdPercentage}
                sx={{
                  mt: 0.75,
                  height: 22,
                  bgcolor: item.status === "On Track" ? "#1e8e3e12" : "#f299004a",
                  color: "#383d5a",
                  fontSize: 10,
                  fontWeight: 700,
                  "& .MuiChip-icon": {
                    color: item.status === "On Track" ? "#1e8e3e12" : "#f299004a",
                    fontSize: 12,
                  },
                }}
              />
                
              )}
            </Box>
          </Box>

          <Divider orientation="vertical" flexItem />

        

          <Box>
            <Typography
              sx={{
                fontSize: 12,
                color: "#383d5a",
                mb: 1,
              }}
            >
              QTD Savings
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 700,
                color: "#767a8191",
                lineHeight: 1,
              }}
            >
              {item.qtd}
            </Typography>

            <Box sx={{ display: "flex", gap: 2 }}>

              <Typography
                sx={{
                  mt: 1,
                  fontSize: 12,
                  color: "#667085",
                }}
              >
                Target : {item.qtdTarget}
              </Typography>
              

              {item.qtdPercentage && (
                <Chip
                size="small"
                // icon={<NorthRoundedIcon sx={{ fontSize: 14 }} />}
                label={item.qtdPercentage}
                sx={{
                  mt: 0.75,
                  height: 22,
                  // bgcolor: "#f299004a",
                  bgcolor: item.status === "On Track" ? "#1e8e3e12" : "#f299004a",
                  color: "#383d5a",
                  fontSize: 10,
                  fontWeight: 700,
                  "& .MuiChip-icon": {
                    color: item.status === "On Track" ? "#1e8e3e12" : "#f299004a",
                    fontSize: 12,
                  },
                }}
              />
              )}
            </Box>
          </Box>
        </Box>
      </Box> */}

      {/* <Divider /> */}

      {/* ================= FOOTER ================= */}

      {/* <Box
        sx={{
          mt: "auto",
          py: 1,
          px: 2,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          bgcolor: "#FAFBFC",
        }}
      >
        <Box
          sx={{
            display: "flex",
            gap: 1,
            alignItems: "center",
            flex: 1,
          }}
        >
          <InfoOutlinedIcon
            sx={{
              color: item.color,
              fontSize: 18,
            }}
          />

          <Typography
            sx={{
              fontSize: 11,
              color: "#667085",
              lineHeight: 1.5,
            }}
          >
            {item.note}
          </Typography>
        </Box>

        <ChevronRightIcon
          sx={{
            color: item.color,
          }}
        />
      </Box> */}
    </Card>
  );
}
const MetricCard = ({ data }) => {
  const improved = data.status === "Improved";
  const Icon = data.Icon;

  return (
    <Card
      elevation={0}
      sx={{
        borderRadius: 1.5,
        border: "1px solid #E5E7EB",
        p: 1,
        // height: "100%",
        // transition: ".25s",
        // "&:hover": {
        //   boxShadow: "0 10px 25px rgba(0,0,0,.08)",
        //   transform: "translateY(-2px)",
        // },
      }}
    >
      {/* Header */}

      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      // mb={2}
      >
        <Box display="flex" alignItems="center" gap={1}>
          <Icon
            sx={{
              color: "#010035",
              width: 24,
              height: 24,
            }}
          />

          <Typography
            sx={{
              fontWeight: 600,
              fontSize: 12,
              // color: item.color,
              color: "#010035",
              mb: .5,
            }}
          >
            {data.metric}
          </Typography>
          <Tooltip
            title={data.note}
            arrow
            placement="top"
          >
            <InfoOutlinedIcon
              sx={{
                // color: data.color,
                color: "#383d5a",
                fontSize: 18,
                mt: "-5px",
                cursor: "pointer",
              }}
            />
          </Tooltip>
        </Box>

        <Chip
          label={data.track}
          size="small"
          sx={{
            bgcolor: data.track === "On Track" ? "#18B96E" : data.track === "Off Track" ? "#F4A622" : "#f29900",
            color: "#000000de",
            fontWeight: 400,
            borderRadius: 2,
            fontSize: 11
          }}
        />
      </Box>

      {/* Goal */}
      <Box sx={{ display: "flex", gap: 0.5, justifyContent: "start", px: 2 }}>

        <Typography
          sx={{
            fontWeight: 600,
            fontSize: 12,
            // color: item.color,
            color: "#383d5a",
            mb: 1,
          }}
        >
          Goal:
        </Typography>

        <Typography
          sx={{
            fontWeight: 600,
            fontSize: 12,
            // color: item.color,
            color: "#383d5a",
            mb: 1,
          }}
        >
          {data.goal}
        </Typography>
      </Box>

      {/* Target */}

      <Box
        sx={{
          bgcolor: "#F8FAFC",
          borderRadius: 3,
          p: 1,
          mb: 1,
          display: "flex",
          alignItems: "center",
          gap: 2
        }}
      >
        <Typography
          sx={{
            fontWeight: 600,
            fontSize: 12,
            color: "#383d5a",
          }}
        >
          🎯 Target
        </Typography>

        <Typography
          fontWeight={700}
          color="#059669"
          fontSize={12}
        >
          {data.target}
        </Typography>
      </Box>

      <Divider />

      {/* Performance */}

      <Typography
        sx={{
          fontWeight: 600,
          fontSize: 12,
          color: "#010035",
          mb: 1,
          mt: 1,
        }}
      >
        Accomplishments
      </Typography>

      <Box
        display="flex"
        justifyContent="space-between"
      // mb={1}
      >
        <Typography sx={{
          fontSize: 12,
          color: "#383d5a",
        }}>
          FY25
        </Typography>

        <Typography sx={{
          fontWeight: 700,
          fontSize: 12,
        }}>
          {data.fy25}
        </Typography>
      </Box>

      <Box
        display="flex"
        justifyContent="space-between"
      // mb={1}
      >
        <Typography sx={{
          fontSize: 12,
          color: "#383d5a",
        }}>
          FY25 YTD
        </Typography>

        <Typography sx={{
          fontWeight: 700,
          fontSize: 12,
        }}>
          {data.fy25YTD}
        </Typography>
      </Box>

      <Box
        display="flex"
        justifyContent="space-between"
      >
        <Typography sx={{
          fontSize: 12,
          color: "#383d5a",
        }}>
          FY26 YTD
        </Typography>

        <Typography
          sx={{
            fontWeight: 700,
            fontSize: 12,
          }}
        >
          {data.fy26YTD}
        </Typography>
      </Box>

      <Divider sx={{ mt: 1 }} />

      {/* Bottom */}

      <Box
        display="flex"
        // flexDirection="column"
        justifyContent="center"
        alignItems="center"
      >
        {improved ? (
          <ArrowDropUpRoundedIcon
            sx={{
              color: "#16A34A",
              fontSize: 24,
            }}
          />
        ) : (
          <ArrowDropDownRoundedIcon
            sx={{
              color: "#DC2626",
              fontSize: 24,
            }}
          />
        )}
        <Box sx={{ display: "flex", gap: "5px" }}>
          <Typography
            fontWeight={600}
            fontSize={12}
            color={
              improved ? "#16A34A" : "#DC2626"
            }
          >
            {data.improvement}
          </Typography>

          <Typography
            color={
              improved ? "#16A34A" : "#DC2626"
            }
            fontWeight={600}
            fontSize={12}
          >
            {data.status}
          </Typography>
        </Box>
      </Box>
    </Card>
  );
};

export default function RiskAndRisiliency() {
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();
  return (
    <Box
      sx={{
        width: "100%",
        bgcolor: "#F5F7FB",
        px: 1.5,
        py: 1,
        pb: "60px",
      }}
    >
      {/* ================================= */}
      {/* BREADCRUMB */}
      {/* ================================= */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          mb: "10px",
          alignItems: "center",
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Breadcrumbs
            separator={<NavigateNextIcon fontSize="small" />}
            sx={{
              // mb: 1,
              fontSize: 13,
            }}
          >
            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 600,
                color: "#010035",
              }}
            >
              Initiatives
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 600,
                color: "#010035",
              }}
            >
              RISK AND RESILIENCY
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 700,
                color: "#010035",
              }}
            >
              Deep Dive
            </Typography>
          </Breadcrumbs>

          <IconButton
            onClick={() => navigate("/")}
            size="small"
            sx={{
              color: "#010035",
              marginLeft: "10px",
              fontSize: "5px",
            }}
          >
            <ArrowBackIcon fontSize="small" />
          </IconButton>
        </Box>

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            textAlign: "center",
            alignContent: "center",
          }}
        >
          <div
            style={{
              padding: "5px 10px",
              background: theme.tableHeaderBg,
              borderRadius: 6,
              color: "#ffffff",
              fontSize: 11,
              fontFamily: "var(--font-mono)",
              border: `1px solid ${theme.chipActiveBorder}`,
              fontWeight: 500,
            }}
          >
            Live ·{" "}
            {new Date().toLocaleDateString("en-US", {
              month: "short",
              day: "numeric",
              year: "numeric",
            })}
          </div>
        </Box>
      </Box>

      {/* ================================= */}
      {/* HEADER */}
      {/* ================================= */}
      {/* <Card
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          borderRadius: 1.5,
          px: 1.5,
          py: 0.75,
          mb: 1,
        }}
      >
        <Grid container alignItems="center">
          <Grid size={{ xs: 12, md: 8 }}>
            <Stack direction="row" spacing={1.5} alignItems="center">
              <Avatar
                sx={{
                  width: 32,
                  height: 32,
                  bgcolor: "#383d5a",
                  color: "#fff",
                }}
              >
                <ShieldOutlinedIcon sx={{ fontSize: 18 }} />
              </Avatar>

              <Box>
                <Stack direction="row" spacing={1} alignItems="center">
                  <Typography
                    sx={{
                      fontSize: 16,
                      fontWeight: 700,
                      color: "#010035",
                      lineHeight: 1,
                    }}
                  >
                    Risk & Resiliency
                  </Typography>

                  <Chip
                    label=""
                    size="small"
                    sx={{
                      bgcolor: "#F4A622",
                      color: "#000",
                      fontWeight: 700,
                      height: 22,
                      width: 22,
                      fontSize: 10,
                    }}
                  />
                </Stack>               

                <Typography
                  sx={{
                    fontSize: 10,
                    mt: 0.25,
                    color: "#475569",
                    lineHeight: 1.3,
                    maxWidth: "100%",
                  }}
                >
                  Improving the operational resilience by maximizing client availability, minimizing critical incidents and strengthening service availability. 
                </Typography>
                <Typography
                  sx={{
                    fontSize: 12,
                    mt: 0.25,
                    color: "#383d5a",
                    lineHeight: 1.3,
                    maxWidth: "100%",
                  }}
                >
                  {`Summary:`}
                </Typography>
              </Box>
            </Stack>
          </Grid>

          <Grid size={{ xs: 12, md: 4 }}>
            <Stack
              direction="row"
              spacing={1}
              justifyContent="flex-end"
              alignItems="center"
            >
              <Button
                variant="outlined"
                startIcon={<ShareOutlinedIcon sx={{ fontSize: 14 }} />}
                size="small"
                sx={{
                  minWidth: 75,
                  height: 28,
                  fontSize: 11,
                  textTransform: "none",
                  px: 1,
                }}
              >
                Share
              </Button>

              <Button
                variant="outlined"
                startIcon={<DownloadOutlinedIcon sx={{ fontSize: 14 }} />}
                size="small"
                sx={{
                  minWidth: 80,
                  height: 28,
                  fontSize: 11,
                  textTransform: "none",
                  px: 1,
                }}
              >
                Export
              </Button>
            </Stack>
          </Grid>
        </Grid>
      </Card> */}
      <Card
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          borderRadius: 1.5,
          px: 1.5,
          py: 0.75,
          mb: 1,
        }}
      >
        <Grid container alignItems="start">
          {/* Left Section */}
          <Grid size={{ xs: 12, md: 6 }}>
            <Stack
              direction="row"
              spacing={1.5}
              alignItems="flex-start"
              sx={{ height: "100%" }}
            >
              <Avatar
                sx={{
                  width: 32,
                  height: 32,
                  bgcolor: "#383d5a",
                  color: "#fff",
                }}
              >
                <ShieldOutlinedIcon sx={{ fontSize: 18 }} />
              </Avatar>

              <Box>
                <Stack direction="row" spacing={1} alignItems="center">
                  <Typography
                    sx={{
                      fontSize: 16,
                      fontWeight: 700,
                      color: "#010035",
                      lineHeight: 1,
                    }}
                  >
                    Risk & Resiliency
                  </Typography>
                  <Chip
                    label=""
                    size="small"
                    sx={{
                      bgcolor: "#F4A622",
                      color: "#000",
                      fontWeight: 700,
                      height: 22,
                      width: 22,
                      fontSize: 10,
                    }}
                  />
                </Stack>

                <Typography
                  sx={{
                    fontSize: 12,
                    mt: 0.25,
                    color: "#475569",
                    lineHeight: 1.3,
                  }}
                >
                  Improving the operational resilience by maximizing client
                  availability, minimizing critical incidents and strengthening
                  service availability.
                </Typography>
              </Box>
            </Stack>
          </Grid>

          <Divider orientation="vertical" flexItem />


          {/* Right Section */}
          <Grid
            size={{ xs: 12, md: 5.8 }}
            sx={{
              pl: { xs: 0, md: 1.5 },
            }}
          >
            <Stack
              direction="row"
              justifyContent="space-between"
              alignItems="flex-start"
              spacing={1.5}
            >
              {/* Summary */}
              <Box sx={{ flex: 1 }}>
                <Typography
                  sx={{
                    fontSize: 13,
                    fontWeight: 700,
                    color: "#010035",
                    mb: 0.5,
                  }}
                >
                  Summary
                </Typography>

                <Typography
                  sx={{
                    fontSize: 12,
                    mt: 0.25,
                    color: "#475569",
                    lineHeight: 1.3,
                  }}
                >
                  {/* Client availability remained above target this quarter while
                  critical incidents reduced significantly. Continued focus on
                  proactive monitoring and resiliency improvements has strengthened
                  service stability. */}
                </Typography>
              </Box>

              {/* Buttons */}
              <Stack spacing={1}>
                <Button
                  variant="outlined"
                  startIcon={<ShareOutlinedIcon sx={{ fontSize: 14 }} />}
                  size="small"
                  sx={{
                    minWidth: 75,
                    height: 28,
                    fontSize: 11,
                    textTransform: "none",
                    px: 1,
                  }}
                >
                  Share
                </Button>

                <Button
                  variant="outlined"
                  startIcon={<DownloadOutlinedIcon sx={{ fontSize: 14 }} />}
                  size="small"
                  sx={{
                    minWidth: 80,
                    height: 28,
                    fontSize: 11,
                    textTransform: "none",
                    px: 1,
                  }}
                >
                  Export
                </Button>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
      </Card>

      {/* ================================= */}
      {/* SUMMARY CARD */}
      {/* ================================= */}



      {/* <Card
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          borderRadius: 2,
          p: 1,
        }}
      >
        <Grid
          container
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "1fr",
              sm: "repeat(2,1fr)",
              md: "repeat(3,1fr)",
              // lg: "repeat(8,minmax(0,1fr))",
              // lg: "1.3fr 1fr 1fr 1fr 3fr"
              // lg: "repeat(4, 1fr)"
              lg: "1fr 1fr 2fr"
            },
            alignItems: "stretch",
            gap: 1,
          }}
        >         
          {summaryCard2.map((item, index) => (
            <SavingsCards2
              key={item.title}
              item={item}
              last={index === summaryCard2.length}
            />
          ))}
          <Box>
          <Stack spacing={0.25}>
              <Typography sx={{
                fontSize: "13px",
                fontWeight: 500,
                color: "#010035",
              }}>
                Summary</Typography>

              <Typography
                sx={{
                  fontSize: 11,
                  color: "#383d5a",
                  lineHeight: 1.25,
                }}
              >
               
              </Typography>
            </Stack>
            
            </Box>        

        </Grid>
      </Card> */}


      {/* <Grid
        container
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            sm: "repeat(2,1fr)",
            lg: `repeat(${savingsCards.length},1fr)`,
          },
          gap: 1,
          mt: 2,
        }}
      >
        {savingsCards.map((item) => (
          <SavingsLeverCard
            key={item.id}
            item={item}
          />
        ))}
      </Grid> */}
      {/* Metric Cards */}
      <Grid
        container
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            sm: "repeat(2,1fr)",
            lg: `repeat(4,1fr)`,
          },
          gap: 1.5,
          mt: 2,
        }}
      >
        {metrics.map((item) => (
          <Grid
            key={item.metric}
          >
            <MetricCard data={item} />
          </Grid>
        ))}


      </Grid>


      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "10px",
          mt: 1,
        }}
      >
        <Card
          elevation={0}
          sx={{
            border: "1px solid #E2E8F0",
            borderRadius: 1.5,
            p: "10px",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Typography
            sx={{
              fontSize: 12,
              fontWeight: 700,
              color: "#010035",
              mb: 1,
            }}
          >
            Progress vs Plan (FY2026)
          </Typography>
          <Table
            size="small"
            sx={{
              tableLayout: "fixed", // important for width control

              "& .MuiTableCell-root": {
                fontSize: "10px",
                color: "#383d5a",
                textAlign: "left",
                py: 0.6,
              },

              "& .MuiTableHead-root .MuiTableCell-root": {
                backgroundColor: "#0A2E78",
                color: "#fff",
                fontWeight: 700,
                borderBottom: "none",
              },
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: "40%" }}>Milestone</TableCell>

                <TableCell sx={{ width: "20%" }}>Plan</TableCell>

                <TableCell sx={{ width: "20%" }}>Plan Target</TableCell>
                <TableCell sx={{ width: "20%" }}>Status</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {progressVsPlan.map((row) => (
                <TableRow key={row.milestone}>
                  <TableCell sx={{}}>
                    {row.milestone}
                  </TableCell>

                  <TableCell sx={{}}>
                    {row.plan}
                  </TableCell>

                  <TableCell sx={{}}>
                    {row.planTarget}
                  </TableCell>
                  <TableCell sx={{}}>
                    {row.status}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>

        {/* ================= RISKS & ISSUES ================= */}
        <Card
          elevation={0}
          sx={{
            border: "1px solid #E2E8F0",
            borderRadius: 1.5,
            p: "10px",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Typography
            sx={{
              fontSize: 12,
              fontWeight: 700,
              color: "#010035",
              mb: 1,
            }}
          >
            RISKS & DEPENDENCIES
          </Typography>

          <Table
            size="small"
            sx={{
              tableLayout: "fixed", // 🔥 important for controlled columns

              "& .MuiTableCell-root": {
                fontSize: "10px",
                color: "#383d5a",
                textAlign: "left",
                py: 0.6,
              },

              "& .MuiTableHead-root .MuiTableCell-root": {
                backgroundColor: "#0A2E78",
                color: "#fff",
                fontWeight: 700,
                borderBottom: "none",
              },
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: "50%" }}>Risk / Dependency</TableCell>
                <TableCell sx={{ width: "20%" }}>Impact</TableCell>
                <TableCell sx={{ width: "30%" }}>Status</TableCell>
                {/* <TableCell sx={{ width: "42%" }}>Mitigation</TableCell> */}
              </TableRow>
            </TableHead>

            <TableBody>
              {risks.map((risk) => (
                <TableRow key={risk.risk}>
                  <TableCell>{risk.risk}</TableCell>

                  <TableCell>
                    <ImpactBadge value={risk.impact} />
                  </TableCell>

                  <TableCell>
                    <StatusDotText value={risk.status} />
                  </TableCell>

                  {/* <TableCell>{risk.mitigation}</TableCell> */}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </Box>
      <Card
        elevation={0}
        sx={{
          mt: 1,
          border: "1px solid #E2E8F0",
          borderRadius: 1.5,
          p: 1.5,
        }}
      >
        <Typography
          sx={{
            fontSize: 12,
            fontWeight: 700,
            color: "#010035",
            mb: 1,
          }}
        >
          KEY DOCUMENTS & LINKS
        </Typography>

        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "repeat(7, 1fr)",
            gap: 1,
          }}
        >
          {documents.map((doc) => (
            <Card
              key={doc.title}
              elevation={0}
              sx={{
                border: "1px solid #E2E8F0",
                borderRadius: 1,
                //   height: 82,
                px: 1,
                py: 1,
                cursor: "pointer",

                "&:hover": {
                  bgcolor: "#F8FAFC",
                },
              }}
            >
              <Stack direction="row" spacing={1} alignItems="flex-start">
                <Typography
                  sx={{
                    fontSize: 24,
                    lineHeight: 1,
                  }}
                >
                  {doc.icon}
                </Typography>

                <Box>
                  <Typography
                    sx={{
                      fontSize: 11,
                      fontWeight: 500,
                      color: "#010035",
                      whiteSpace: "pre-line",
                      lineHeight: 1.3,
                    }}
                  >
                    {doc.title}
                  </Typography>

                  <Typography
                    sx={{
                      fontSize: 10,
                      color: "#2563EB",
                      mt: 0.5,
                      fontWeight: 500,
                    }}
                  >
                    View
                  </Typography>
                </Box>
              </Stack>
            </Card>
          ))}
        </Box>
      </Card>
      <Card
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          // borderRadius: 2,
          // mt: 2,
          py: 1,
          px: 1.5,
          position: "fixed",
          bottom: 0,
          left: 10,
          right: 10,
          zIndex: 1000,
          bgcolor: "#F5F7FB"
          // borderRadius: 0,
        }}
      >
        <Grid
          container
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "repeat(4,1fr)",
              sm: "repeat(4,1fr)",
              md: "repeat(4,1fr)",
              lg: "repeat(4,1fr)"
            },
            alignItems: "stretch",
            gap: 1,
          }}
        >
          {infoCards.map((item) => (
            <InfoCard
              key={item.title}
              item={item}
            />
          ))}
        </Grid>
      </Card>
    </Box>
  );
}
