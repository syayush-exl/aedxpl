import React from "react";
import {
  Avatar,
  Box,
  Breadcrumbs,
  Button,
  Card,
  Chip,
  Divider,
  Grid,
  LinearProgress,
  Stack,
  Typography,
  Paper,
  CardContent,
  IconButton,
  CircularProgress
} from "@mui/material";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import ShareOutlinedIcon from "@mui/icons-material/ShareOutlined";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import Diversity3Icon from '@mui/icons-material/Diversity3';
import LocalPhoneIcon from '@mui/icons-material/LocalPhone';
import LaptopIcon from '@mui/icons-material/Laptop';
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import InsertDriveFileOutlinedIcon from "@mui/icons-material/InsertDriveFileOutlined";
import AssessmentOutlinedIcon from "@mui/icons-material/AssessmentOutlined";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  LabelList,
  BarChart,
  Bar,
  Legend,
  ReferenceLine,
} from "recharts";
import AppsOutlinedIcon from "@mui/icons-material/AppsOutlined";
import CloudDoneOutlinedIcon from "@mui/icons-material/CloudDoneOutlined";
import ApartmentOutlinedIcon from "@mui/icons-material/ApartmentOutlined";
import CheckCircleOutlineOutlinedIcon from "@mui/icons-material/CheckCircleOutlineOutlined";
import AccessTimeOutlinedIcon from "@mui/icons-material/AccessTimeOutlined";
import Groups2OutlinedIcon from "@mui/icons-material/Groups2Outlined";
import PublicOutlinedIcon from "@mui/icons-material/PublicOutlined";
import WindowOutlinedIcon from "@mui/icons-material/WindowOutlined";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";

import AttachMoneyRoundedIcon from "@mui/icons-material/AttachMoneyRounded";
import GroupsRoundedIcon from "@mui/icons-material/GroupsRounded";
import SouthRoundedIcon from "@mui/icons-material/SouthRounded";

import GroupsIcon from "@mui/icons-material/Groups";
import PublicIcon from "@mui/icons-material/Public";
import GridViewRoundedIcon from "@mui/icons-material/GridViewRounded";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import CloudOutlinedIcon from "@mui/icons-material/CloudOutlined";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import DashboardCustomizeOutlinedIcon from "@mui/icons-material/DashboardCustomizeOutlined";
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import FlagOutlinedIcon from "@mui/icons-material/FlagOutlined";
import MonitorHeartOutlinedIcon from "@mui/icons-material/MonitorHeartOutlined";
import NorthRoundedIcon from "@mui/icons-material/NorthRounded";


import SavingsOutlinedIcon from "@mui/icons-material/SavingsOutlined";
import TrendingUpOutlinedIcon from "@mui/icons-material/TrendingUpOutlined";
import StorageOutlinedIcon from "@mui/icons-material/StorageOutlined";
import AccountBalanceWalletOutlinedIcon from "@mui/icons-material/AccountBalanceWalletOutlined";

import LaptopMacOutlinedIcon from "@mui/icons-material/LaptopMacOutlined";
// import CloudOutlinedIcon from "@mui/icons-material/CloudOutlined";
import HandshakeOutlinedIcon from "@mui/icons-material/HandshakeOutlined";
import DevicesOutlinedIcon from "@mui/icons-material/DevicesOutlined";

import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import DoneIcon from "@mui/icons-material/Done";
import chart from "../../data/migrationProgress.json";
import { useTheme } from "../../theme-context";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useNavigate } from "react-router-dom";
import SpendTrendCard from "../newComp/spendTrendCard";

const kpis = [
  {
    title: "Total Applications",
    value: "1,094",
    subtitle: "Across 18 DCs",
    color: "#0A2E78",
    icon: <AppsOutlinedIcon sx={{ fontSize: 16 }} />,
  },
  {
    title: "Applications Migrated",
    value: "280",
    subtitle: "26% of total",
    color: "#0A2E78",
    icon: <CloudDoneOutlinedIcon sx={{ fontSize: 16 }} />,
  },
  {
    title: "Active Data Centers",
    value: "18",
    subtitle: "On Track",
    color: "#0A2E78",
    icon: <ApartmentOutlinedIcon sx={{ fontSize: 16 }} />,
  },
  {
    title: "Overall Migration Completion",
    value: "16%",
    subtitle: "Achieved by June 2026",
    color: "#0A2E78",
    icon: <CheckCircleOutlineOutlinedIcon sx={{ fontSize: 16 }} />,
  },
];

const labelStyle = {
  fontSize: "11px",
  fontWeight: 500,
  color: "#010035",
};

const valueStyle = {
  fontSize: "42px",
  fontWeight: 700,
  color: "#0A2E78",
};

const migrationProgressData = [
  { month: "Q1", planned: 20, actual: 16 },
  { month: "Q2", planned: 35, actual: 28 },
  { month: "Q3", planned: 50, actual: 42 },
  { month: "Q4", planned: 70, actual: 60 },
  { month: "Q5", planned: 90, actual: 80 },
];

const buData = [
  {
    name: "Commercial",
    completed: 70,
    inProgress: 20,
    pending: 10,
  },
  {
    name: "Consumer",
    completed: 55,
    inProgress: 25,
    pending: 20,
  },
  {
    name: "Finance",
    completed: 40,
    inProgress: 30,
    pending: 30,
  },
  {
    name: "Operations",
    completed: 65,
    inProgress: 20,
    pending: 15,
  },
];
const buRows = [
  {
    bu: "GETS",
    total: 500,
    red: 90,
    purple: 40,
    green: 50,
    gray: 90,
    blue: 20,
    pct: "14%",
  },
  {
    bu: "ESI",
    total: 210,
    red: 25,
    purple: 20,
    green: 40,
    gray: 70,
    blue: 25,
    pct: "19%",
  },
  {
    bu: "Nationals",
    total: 80,
    red: 40,
    purple: 10,
    green: 15,
    gray: 15,
    blue: 0,
    pct: "13%",
  },
  {
    bu: "Major & Canada",
    total: 70,
    red: 35,
    purple: 10,
    green: 10,
    gray: 15,
    blue: 0,
    pct: "21%",
  },
  {
    bu: "SR/MRFS",
    total: 60,
    red: 25,
    purple: 10,
    green: 5,
    gray: 10,
    blue: 10,
    pct: "8%",
  },
];
const milestones = [
    {
      milestone: "TESM Governance Established",
      target: "FY26 Q1",
      status: "Completed",
    },
    {
      milestone: "Immediate Cost Actions Executed",
      target: "FY26 Q2",
      status: "In Progress",
    },
    {
      milestone: "Spend Transparency Capability Launched",
      target: "FY26 Q3",
      status: "In Progress",
    },
    {
      milestone: "Contract Intelligence Capability Implemented",
      target: "FY27 Q1",
      status: "Planned",
    },
    {
      milestone: "Vendor Performance Framework Established",
      target: "FY27 Q2",
      status: "Planned",
    },
    {
        milestone: "Enterprise Optimization Engine Deployeds",
        target: "FY27 Q3",
        status: "Future",
    },
    //   {
    //     milestone: "Optimization Engine Deployment",
    //     target: "FY28",
    //     status: "Planned",
    //   },
  ];

  const infoCards = [
    {
      title: "Initiative Owner",
      value: "Varun",
      subtitle: "",
      icon: <PersonOutlineIcon color="primary" sx={{ fontSize: 16 }} />,
    },
    {
      title: "FAST Pillar",
      value: "Transform",
      subtitle: "",
      icon: (
        <DashboardCustomizeOutlinedIcon
          color="primary"
          sx={{ fontSize: 16 }}
        />
      ),
    },
    {
      title: "Timeline",
      value: "FY26 - FY29",
      subtitle: "(4 Year Program)",
      icon: (
        <CalendarMonthOutlinedIcon color="primary" sx={{ fontSize: 16 }} />
      ),
    },
    {
      title: "Current Phase",
      value: "FY27",
      subtitle: "Execution Phase",
      icon: <FlagOutlinedIcon color="primary" sx={{ fontSize: 16 }} />,
    },
   
    // {
    //   title: "Key Takeaway",
    //   value:
    //     "Geo mix optimization is ahead of plan while resource mix and workforce optimization require acceleration.",
    //   subtitle: "",
    //   icon: null,
    //   isTakeaway: true,
    // },
  ];
  const summaryCard2 = [
    {
      title: "Cost Savings Realization (FY29)",
      value: "$23M",
      target: "$140M",
      progress: 17,
      percentage: "71%",
      iconBg: "#F1EBFF",
      iconColor: "#6B4CF6",
    },
    {
      title: "Total Savings (YTD)",
      value: "$12M",
      target: "$35M",
      ytdLY: "$10M (YTD LY)",
      growth: "+ $2M",
      progress: 35,
      percentage: "53%",
      iconBg: "#F1EBFF",
      iconColor: "#6B4CF6",
    },
    {
      title: "Total Savings (QTD)",
      value: "$3M",
      target: "$8M",
      progress: 38,
      ytdLY: "$2M (QTD LQ)",
      growth: "+ $1M",
      percentage: "40%",
      iconBg: "#EAF3FF",
      iconColor: "#1E88E5",
    },
    {
      title: "Total Savings (MTD)",
      value: "$1M",
      target: "$2M",
      progress: 50,
      ytdLY: "$0.5M (MTD LM)",
      growth: "+ $0.5M",
      percentage: "33%",
      iconBg: "#E8F7EC",
      iconColor: "#28A745",
    },
  ]
  const summaryCards1 = [
    {
      title: "Cost Savings Realization(FY29) ",
      value: "$23M",
      target: "$140M Target",
      progress: 47,
      percentage: "83%",
      iconBg: "#F1EBFF",
      iconColor: "#6B4CF6",
    },
    // {
    //   title: "Total Savings (FY29)",
    //   value: "$20M",
    //   target: "$70M Target",
    //   progress: 47,
    //   percentage: "71%",
    //   iconBg: "#F1EBFF",
    //   iconColor: "#6B4CF6",
    // },
    {
      title: "Total Savings (YTD)",
      value: "$12M",
      target: "$35M Target",
      progress: 47,
      percentage: "65%",
      iconBg: "#F1EBFF",
      iconColor: "#6B4CF6",
    },
    {
      title: "Total Savings (QTD)",
      value: "$3M",
      target: "$8M Target",
      progress: 60,
      percentage: "62%",
      iconBg: "#EAF3FF",
      iconColor: "#1E88E5",
    },
    {
      title: "Total Savings (MTD)",
      value: "$1M",
      target: "$2M Target",
      progress: 67,
      percentage: "50%",
      iconBg: "#E8F7EC",
      iconColor: "#28A745",
    },
    // {
    //   title: "Execution Progress",
    //   value: "20%",
    //   progress: 20,
    //   execution: true,
    //   iconBg: "#EFE9FF",
    //   iconColor: "#7E57C2",
    // },
  ];
 
  const pipeline = [
    {
      vendor: "Microsoft (M365 ES)",
      opportunity: "Optimization & Right-sizing",
      potential: "$4.6M",
      status: "In progress",
      value: "-"
    },
    {
      vendor: "Windows Server",
      opportunity: "Rightsizing",
      potential: "$1.90M",
      status: "In progress",
      value: "-"
    },
    {
      vendor: "Centralized Procurement + RFI",
      opportunity: "Vendor consolidation & standardization",
      potential: "$1.0M",
      status: "In progress",
      value: "-"
    },
    {
      vendor: "Extended Device Lifecycle",
      opportunity: "Lifecycle extension to 4–5 years",
      potential: "$1.1M",
      status: "In progress",
      value: "-"
    },
    {
      vendor: "Damages & End-of-life Cost Reduction",
      opportunity: "Buyout & Damage Cost Elimination",
      potential: "$0.4M",
      status: "In progress",
      value: "-"
    },
    // {
    //   vendor: "",
    //   Opportunity: "High",
    //   potential: "At Risk",
    //   status: "",
    //   value: ""
    // },
  //   {
  //     risk: "Microsite reduction delivery",
  //     impact: "High",
  //     status: "At Risk",
  //     mitigation: "Automation tooling",
  //   },
  //   {
  //     risk: "Data availability & reporting accuracy",
  //     impact: "Low",
  //     status: "On Track",
  //     mitigation: "Automation tooling",
  //   },
  ];

const risks = [
  {
    risk: "Business Unit adoption & change management",
    impact: "High",
    status: "At Risk",
    mitigation: "Early stakeholder engagaement and executive sponsership",
  },
  {
    risk: "Contractual lock-ins & renewal contrainits",
    impact: "High",
    status: "Needs Attention",
    mitigation: "Proactive deal radar and renewal planning",
  },
  {
    risk: "Limited spend visibility & data quality",
    impact: "Medium",
    status: "Needs Attention",
    mitigation: "Improve spend taxonomy, tagging and contract intelligence",
  },
  {
    risk: "Cross-Functional Support (Procurement, Finance, IT)",
    impact: "High",
    status: "Dependency",
    mitigation: "Establish governance forums and clear ownership",
  },
  {
    risk: "Availability of Vendor & Contract Data",
    impact: "Medium",
    status: "Dependency",
    mitigation: "Centralize contract repository and spend data sources",
  },
//   {
//     risk: "Microsite reduction delivery",
//     impact: "High",
//     status: "At Risk",
//     mitigation: "Automation tooling",
//   },
//   {
//     risk: "Data availability & reporting accuracy",
//     impact: "Low",
//     status: "On Track",
//     mitigation: "Automation tooling",
//   },
];
const documents = [
 
  {
    
    icon: "📘",
    title: "Saving Opportunity Tracker\n(DOCX)",
  },
//   {
//     icon: "📈",
//     title: "Migration Factory\nDashboard",
//   },
  {
    icon: "📗",
    title: "Microsite EA Savings Analysis\n(XLSX)",
  },
  {
    icon: "📊",
    title: "Laptop Buy vs Lease Business Case (PPT)",
  },
  {
    icon: "📕",
    title: "TGC Governance Framework\n(PDF)",
  },
  {
    icon: "🟢",
    title: "Vendor Performance Playbook\nNotes",
  },
  {
    icon: "📄",
    title: "FY26 Savings Opportunity Tracker",
  },
];


export const summaryCards = [
  {
    title: "Savings YTD",
    value: "$8M",
    subtitle: "vs $17M Target",
    color: "#383d5a",
    icon: "$",
  },
  {
    title: "Savings FY(t)",
    value: "$20M",
    subtitle: "vs $25M Target",
    color: "#18A957",
    icon: "📈",
  },
  {
    title: "Execution Progress",
    subtitle: "Weighted average",
    color: "#4338CA",
    icon: "👥",
  },
  {
    title: "Workforce Mix Progress",
    subtitle: "Weighted average",
    color: "#F97316",
    icon: "👥",
  },
  {
    title: "Geo Mix Progress",
    subtitle: "Weighted average",
    color: "#2563EB",
    icon: "🌍",
  },
  {
    title: "AI Led Delivery Progress",
    subtitle: "Weighted average",
    color: "#7C3AED",
    icon: "✦",
  },
];
const savingsLeverData = [
    {
      id: 1,
      color: "#5B21B6",
      title: "Software & Maintenance Optimization",
      target: "$47M – $93M",
      ytd: "$8M",
      progress: 12,
      icon: <LaptopMacOutlinedIcon fontSize="small" />,
    },
    {
      id: 2,
      color: "#2E7D32",
      title: "Cloud Spend Optimization",
      target: "$13M – $26M",
      ytd: "$2M",
      progress: 15,
      icon: <CloudOutlinedIcon fontSize="small" />,
    },
    {
      id: 3,
      color: "#EF6C00",
      title: "Vendor & Contract Optimization",
      target: "$20M+",
      ytd: "$3M",
      progress: 15,
      icon: <HandshakeOutlinedIcon fontSize="small" />,
    },
    {
      id: 4,
      color: "#1565C0",
      title: "Device Lifecycle Optimization",
      target: "$2.5M – $4.4M",
      ytd: "$1.1M",
      progress: 44,
      icon: <DevicesOutlinedIcon fontSize="small" />,
    },
  ];
  const savingsCards = [
    {
      id: 1,
      title: "Software & Maintenance",
      subtitle: "",
      status: "Off Track",
  
      progress: 16,
  
      current: "$15M",
      targetRatio: "$47M-$93M",
  
      ytd: "$8M",
      ytdTarget: "$20M",
      ytdPercentage: "40%",
  
      qtd: "$2M",
      qtdTarget: "$5M",
      qtdPercentage: "40%",
  
      color: "#635BFF",
  
      Icon: GroupsIcon,
  
      note:
        "",
    },
  
    {
      id: 2,
      title: "Cloud",
      subtitle: "",
      status: "On Track",
  
      progress: 12,
  
      current: "$3M",
      targetRatio: "$13M-$26M",
  
      ytd: "$3M",
      ytdTarget: "$3M",
      ytdPercentage: "100%",
  
      qtd: "$2M",
      qtdTarget: "$2M",
      qtdPercentage: "100%",
  
      color: "#06B6D4",
  
      Icon: PublicIcon,
  
      note:
        "",
    },
    {
      id: 2,
      title: "Consulting",
      subtitle: "",
      status: "Off Track",
  
      progress: 15,
  
      current: "$2M",
      targetRatio: "$7M-$14M",
  
      ytd: "$1.5M",
      ytdTarget: "$3.5M",
      ytdPercentage: "43%",
  
      qtd: "$0.3M",
      qtdTarget: "$1M",
      qtdPercentage: "30%",
  
      color: "#06B6D4",
  
      Icon: Diversity3Icon,
  
      note:
        "",
    },
  

    {
      id: 4,
      title: "Telecom",
      subtitle:
        "",
  
      status: "Off Track",
  
      progress: 50,
  
      current: "$2M",
      targetRatio: "$2M-$4M",
  
      ytd: "$0.4M",
      ytdTarget: "$1M",
      ytdPercentage: "40%",
  
      qtd: "$0.1M",
      qtdTarget: "$0.3M",
      qtdPercentage: "33%",
  
      color: "#22C55E",
  
      Icon: LocalPhoneIcon,
  
      note:
        "",
    },

    {
      id: 5,
      title: "Lease",
      subtitle:
        "",
  
      status: "Off Track",
  
      progress: 25,
  
      current: "$0.5M",
      targetRatio: "$1M-$2M",
  
      ytd: "$0.3M",
      ytdTarget: "$0.5M",
      ytdPercentage: "60%",
  
      qtd: "$0.1M",
      qtdTarget: "$0.3M",
      qtdPercentage: "33%",
  
      color: "#22C55E",
  
      Icon: LaptopIcon,
  
      note:
        "",
    },
  ];

const BLUE = "#1565FF";
const GREEN = "#0CA44B";

const CustomTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;

  return (
    <div className="tooltip">
      <div>{payload[0]?.payload.month}</div>

      {payload.map((item: any) => (
        <div key={item.dataKey}>
          {item.name}: {item.value}%
        </div>
      ))}
    </div>
  );
};

/* ===================== CONFIG ===================== */
const statusConfig = {
  Completed: { color: "#16A34A", type: "filled" },
  "In Progress": { color: "#F59E0B", type: "outlined" },
  Planned: { color: "#2563EB", type: "outlined" },
};

const impactConfig = {
  High: "#DC2626",
  Medium: "#F59E0B",
  Low: "#18B96E",
};

/* ===================== STATUS BADGE ===================== */
const StatusBadge = ({ value }) => {
  const config = statusConfig[value] || { color: "#0A2E78" };

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
      <Box
        sx={{
          width: 10,
          height: 10,
          borderRadius: "50%",
          border:
            config.type === "outlined" ? `2px solid ${config.color}` : "none",
          backgroundColor:
            config.type === "filled" ? config.color : "transparent",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {config.type === "filled" && (
          <Typography sx={{ fontSize: 8, color: "#fff", lineHeight: 1 }}>
            ✓
          </Typography>
        )}
      </Box>

      <Typography sx={{ fontSize: 10, color: "#0A2E78" }}>{value}</Typography>
    </Box>
  );
};

const  CircularProgressWithLabel = ({ value, color }) => {
  return (
    <Box
      sx={{
        position: "relative",
        width: 110,
        height: 110,
      }}
    >
      <CircularProgress
        variant="determinate"
        value={100}
        size={110}
        thickness={4}
        sx={{
          color: "#EEF2F7",
          position: "absolute",
        }}
      />

      <CircularProgress
        variant="determinate"
        value={value}
        size={110}
        thickness={4}
        sx={{
          color,
          position: "absolute",
          "& .MuiCircularProgress-circle": {
            strokeLinecap: "round",
          },
        }}
      />

      <Box
        sx={{
          position: "absolute",
          inset: 0,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Typography
          sx={{
            fontSize: 18,
            fontWeight: 700,
            color: "#0F172A",
          }}
        >
          {value}%
        </Typography>

        <Typography
          sx={{
            fontSize: 13,
            color: "#64748B",
          }}
        >
          Progress
        </Typography>
      </Box>
    </Box>
  );
}
const InfoCard = ({ item }: any) => (
  <Box
    sx={{
      height: "100%",
      display: "flex",
      flexDirection: "column",
      justifyContent: "flex-start",
      px: 1,
      borderRight: "1px solid rgba(0,0,0,0.12)",
    }}
  >
    {item.isTakeaway ? (
      <>
        <Typography sx={labelStyle}>{item.title}</Typography>

        <Typography
          sx={{
            mt: 1,
            fontSize: 11,
            color: "#383D5A",
            lineHeight: 1.4,
          }}
        >
          {item.value}
        </Typography>
      </>
    ) : (
      <>
        <Stack direction="row" spacing={0.5} alignItems="center">
          {item.icon}
          <Typography sx={labelStyle}>{item.title}</Typography>
        </Stack>
        <Box sx={{display: "flex", gap: 1,  mt: 0.6, justifyItems: "center", alignItems: "center"}}>        

        <Typography
          sx={{
            pl: "20px",
            // mt: 0.6,
            fontSize: 12,
            fontWeight: 700,
            color: "#010035",
          }}
        >
          {item.value}
        </Typography>

        <Typography
          sx={{
            // pl: "20px",
            fontSize: 10,
            // mt: 0.6,
            color: "text.secondary",
          }}
        >
          {item.subtitle || "\u00A0"}
        </Typography>
        </Box>
      </>
    )}
  </Box>
);
const SavingsCards2 = ({ item, last = false }: any) => (
  <Box
    sx={{
      height: "100%",
      display: "flex",
      // alignItems: "center",
      gap: 0.5,
      px: "5px",
      borderRight: last ? "none" : "1px solid rgba(0,0,0,0.12)",
    }}
  >
    <Avatar
      sx={{
        width: 24,
        height: 24,
        bgcolor: item.iconBg,
        color: item.iconColor,
      }}
    >
      {item.execution ? (
        <GroupsRoundedIcon />
      ) : (
        <AttachMoneyRoundedIcon />
      )}
    </Avatar>

    <Box flex={1}>
      <Typography
        sx={{
          fontSize: 11,
          color: "#010035",
          fontWeight: 500,
        }}
      >
        {item.title}
      </Typography>

      {/* <Typography
        sx={{
          fontWeight: 700,
          fontSize: 12,
          color: "#767a8191",
          mt: "10px",
          mb: "-10px"
        }}
      >
        {item.value}
      </Typography> */}
      {item.execution ? (
        <>
          <LinearProgress
            variant="determinate"
            value={item.progress}
            sx={{
              mt: 1,
              height: 5,
              borderRadius: 4,
              bgcolor: "#ECEEF4",
              "& .MuiLinearProgress-bar": {
                bgcolor: "#6B4CF6",
                borderRadius: 4,
              },
            }}
          />
        </>
      ) : (
        <>
          <Box
            sx={{
              position: "relative",
              pt: 1.5,
              mt: 1,
            }}
          >
            <Typography
              sx={{
                position: "absolute",
                left: `${item.progress ?? 0
                  }%`,
                transform: "translateX(-50%)",
                top: -2,

                fontSize: 10,
                fontWeight: 700,

                // color: metric.label === "Breakthrough Overall Revenue" ? "#767a8191" : getProgressBarColor(
                //   metric.value ?? metric.progress ?? 0
                // ),
                // color: "#767a8191",
                color: "#767a8191",

                maxWidth: 40,
                textAlign: "center",
              }}
            >
              {item.progress ?? 0}%
            </Typography>

            <LinearProgress
              variant="determinate"
              value={item.progress ?? 0}
              sx={{
                height: 5,
                borderRadius: 10,
                bgcolor: "#E5E7EB",

                "& .MuiLinearProgress-bar": {
                  borderRadius: 10,
                  // bgcolor: "#767a8191"
                  bgcolor: "#767a8191",
                  // bgcolor: getProgressBarColor(
                  //   metric.value ?? metric.progress ?? 0
                  // ),
                },
              }}
            />


            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                mt: 0.4,
              }}
            >
              <Typography
                sx={{
                  fontSize: 10,
                  // color: "#64748B",
                  color: "#767a8191",
                  fontWeight: 600
                }}
              >
                {item.value}
              </Typography>

              <Typography
                sx={{
                  fontSize: 10,
                  // color: "#64748B",
                  color: ["Cost Savings Realization (FY29)"].includes(item.title) ? "#383d5a" : "#767a8191",
                  fontWeight: 600
                }}
              >
                {item.target}
              </Typography>
            </Box>
          </Box>
          {/* <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          mt={0.8}
        >
          <Typography
            sx={{
              fontSize: 10,
              // color: "#667085",
              color: ["Cost Savings Realization (FY29)"].includes(item.title) ? "#383d5a" : "#667085",
              marginLeft: "-20px"
            }}
          >
            vs {item.target}
          </Typography>

          <Chip
            size="small"
            icon={<SouthRoundedIcon sx={{ fontSize: 14 }} />}
            label={item.percentage}
            sx={{
              height: 22,
              bgcolor: "#FFF1F1",
              color: "#D92D20",
              fontSize: 10,
              fontWeight: 700,
              "& .MuiChip-icon": {
                color: "#D92D20",
                fontSize: 12,
              },
            }}
          />          
        </Stack> */}
          {item.ytdLY && (
            <Stack
              direction="row"
              justifyContent="start"
              alignItems="center"
              gap={1}
              mt={0.8}
            >
              <Typography
                sx={{
                  fontSize: 10,
                  // color: "#667085",
                  color: "#667085",
                  marginLeft: "-20px"
                }}
              >
                {item.ytdLY}
              </Typography>
              <Chip
                size="small"
                icon={<NorthRoundedIcon sx={{ fontSize: 14 }} />}
                label={item.growth}
                sx={{
                  height: 22,
                  bgcolor: "#1e8e3e12",
                  color: "#18B96E",
                  fontSize: 10,
                  fontWeight: 700,
                  "& .MuiChip-icon": {
                    color: "#18B96E",
                    fontSize: 12,
                  },
                }}
              />
            </Stack>
          )}
        </>
      )}
    </Box>
  </Box>
);

const SavingsCard = ({ item, last = false }: any) => (
  <Box
    sx={{
      height: "100%",
      display: "flex",
      // alignItems: "center",
      gap: 0.5,
      px: "5px",
      borderRight: last ? "none" : "1px solid rgba(0,0,0,0.12)",
    }}
  >
    <Avatar
      sx={{
        width: 24,
        height: 24,
        bgcolor: item.iconBg,
        color: item.iconColor,
      }}
    >
      {item.execution ? (
        <GroupsRoundedIcon />
      ) : (
        <AttachMoneyRoundedIcon />
      )}
    </Avatar>

    <Box flex={1}>
      <Typography
        sx={{
          fontSize: 11,
          color: "#010035",
          fontWeight: 500,
        }}
      >
        {item.title}
      </Typography>

      <Typography
        sx={{
          fontWeight: 700,
          fontSize: 12,
          color: "#767a8191",
          mt: "10px",
          mb: "-10px"
        }}
      >
        {item.value}
      </Typography>
      {item.execution ? (
        <>
          <LinearProgress
            variant="determinate"
            value={item.progress}
            sx={{
              mt: 1,
              height: 5,
              borderRadius: 4,
              bgcolor: "#ECEEF4",
              "& .MuiLinearProgress-bar": {
                bgcolor: "#6B4CF6",
                borderRadius: 4,
              },
            }}
          />
        </>
      ) : (
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          mt={0.8}
        >
          <Typography
            sx={{
              fontSize: 10,
              // color: "#667085",
              color:`${item.title=="Cost Savings Realization(FY29)" ? "black" : "gray"}`,
              marginLeft: "-20px"
            }}
          >
            vs {item.target}
          </Typography>

          <Chip
            size="small"
            icon={<SouthRoundedIcon sx={{ fontSize: 14 }} />}
            label={item.percentage}
            sx={{
              height: 22,
              bgcolor: "#FFF1F1",
              color: "#D92D20",
              fontSize: 10,
              fontWeight: 700,
              "& .MuiChip-icon": {
                color: "#D92D20",
                fontSize: 12,
              },
            }}
          />
        </Stack>
      )}
    </Box>
  </Box>
);

const  SavingsLeverCard = ({ item }) => {
  const Icon = item.Icon;

  return (
    <Card
      sx={{
        height: "100%",
        borderRadius: 1.5,
        overflow: "hidden",
        border: "1px solid #E5E7EB",
        boxShadow: "0 3px 12px rgba(15,23,42,.08)",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* ================= HEADER ================= */}

      <Box
        sx={{
          p: 1,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
        }}
      >
        <Box
          sx={{
            display: "flex",
            gap: 1.5,
            flex: 1,
          }}
        >
          <Avatar
            sx={{
              width: 40,
              height: 40,
              bgcolor: `${item.color}15`,
              color: item.color,
            }}
          >
            <Icon />
          </Avatar>

          <Box>
            <Typography
              sx={{
                fontWeight: 600,
                fontSize: 12,
                color: "#010035",
                mb: .5,
              }}
            >
              {item.title}
            </Typography>

            <Typography
              sx={{
                fontSize: 12,
                color: "#667085",
                lineHeight: 1.5,
              }}
            >
              {item.subtitle}
            </Typography>
          </Box>
        </Box>

        <Chip
          label={item.status}
          size="small"
          sx={{
            // bgcolor: "#ECFDF3",
            bgcolor:item.status === "On Track" ? "#1e8e3e12" : item.status === "Off Track" ? "#f299004a" : "#f29900",
            color: "#000000de",
            fontWeight: 400,
            borderRadius: 2,
            fontSize: 11
          }}
        />
      </Box>

      <Divider />

      {/* ================= PROGRESS ================= */}

      <Box
        sx={{
          py: 1,
          px: 2,
          display: "grid",
          gridTemplateColumns: "1fr",
          // gap: 3,
          alignItems: "center",
        }}
      >
        {/* <CircularProgressWithLabel
          value={item.progress}
          color={item.color}
        /> */}

        <Box>
          <Typography
            sx={{
              fontWeight: 600,
              fontSize: 11,
              color: "#383d5a",
              mb: 0.5,
            }}
          >
            Progress vs Target
          </Typography>

          <LinearProgress
            variant="determinate"
            value={item.progress}
            sx={{
              height: 6,
              borderRadius: 20,
              background: "#EEF2F7",

              "& .MuiLinearProgress-bar": {
                borderRadius: 20,
                background: "#767a8191",
              },
            }}
          />

          <Box
            sx={{
              mt: 1,
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <Box>
              <Typography
                sx={{
                  fontSize: 11,
                  color: "#383d5a",
                }}
              >
                Current
              </Typography>

              <Typography
                sx={{
                  fontWeight: 500,
                  fontSize: 11,
                  color:"#767a8191"
                }}
              >
                {item.current}
              </Typography>
            </Box>

            <Box textAlign="right">
              <Typography
                sx={{
                  fontSize: 11,
                  color: "#383d5a",
                }}
              >
                Target
              </Typography>

              <Typography
                sx={{
                  fontWeight: 500,
                  fontSize: 11,
                  color: "#383d5a"
                }}
              >
                {item.targetRatio}
              </Typography>
            </Box>
          </Box>
        </Box>
      </Box>

      <Divider />
      <Box sx={{ py: 1, px: 1 }}>
        <Typography
          sx={{
            fontSize: 12,
            fontWeight: 700,
            color: "#383d5a",
            mb: 1,
            letterSpacing: 0.5,
          }}
        >
          SAVINGS
        </Typography>

        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "1fr auto 1fr",
            // alignItems: "stretch",
            gap: 1,
          }}
        >
          {/* YTD */}

          <Box>
            <Typography
              sx={{
                fontSize: 12,
                color: "#667085",
                mb: 1,
              }}
            >
              YTD Savings
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 700,
                color: "#767a8191",
                lineHeight: 1,
              }}
            >
              {item.ytd}
            </Typography>

            <Box sx={{display: "flex", gap: 2}}>           

            <Typography
              sx={{
                mt: 1,
                fontSize: 12,
                color: "#767a8191",
              }}
            >
              Target {item.ytdTarget}
            </Typography>

            {item.ytdPercentage && (
              <Chip
              size="small"
              // icon={<NorthRoundedIcon sx={{ fontSize: 14 }} />}
              label={item.ytdPercentage}
              sx={{
                mt: 0.75,
                height: 22,
                bgcolor: item.status === "On Track" ? "#1e8e3e12" : "#f299004a",
                color: "#383d5a",
                fontSize: 10,
                fontWeight: 700,
                "& .MuiChip-icon": {
                  color: item.status === "On Track" ? "#1e8e3e12" : "#f299004a",
                  fontSize: 12,
                },
              }}
            />
            )}
            </Box>
          </Box>

          <Divider orientation="vertical" flexItem />

          {/* QTD */}

          <Box>
            <Typography
              sx={{
                fontSize: 12,
                color: "#667085",
                mb: 1,
              }}
            >
              QTD Savings
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 700,
                color: "#767a8191",
                lineHeight: 1,
              }}
            >
              {item.qtd}
            </Typography>

            <Box sx={{display: "flex", gap: 2}}>

            <Typography
              sx={{
                mt: 1,
                fontSize: 12,
                color: "#767a8191",
              }}
            >
              Target : {item.qtdTarget}
            </Typography>

            {item.qtdPercentage && (
               <Chip
               size="small"
               // icon={<NorthRoundedIcon sx={{ fontSize: 14 }} />}
               label={item.qtdPercentage}
               sx={{
                 mt: 0.75,
                 height: 22,
                 bgcolor: item.status === "On Track" ? "#1e8e3e12" : "#f299004a",
                 color: "#383d5a",
                 fontSize: 10,
                 fontWeight: 700,
                 "& .MuiChip-icon": {
                   color: item.status === "On Track" ? "#1e8e3e12" : "#f299004a",
                   fontSize: 12,
                 },
               }}
             />
            )}
            </Box>
          </Box>
        </Box>
      </Box>

      <Divider />

      {/* ================= FOOTER ================= */}

    </Card>
  );
}

/* ===================== IMPACT BADGE ===================== */
const ImpactBadge = ({ value }) => {
  const color = impactConfig[value] || "#0A2E78";

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
      <Typography sx={{ fontSize: 10, color }}>{value}</Typography>
    </Box>
  );
};

const statusColorMap = {
  "At Risk": "#DC2626",
  "Needs Attention": "#F59E0B",
  "On Track": "#16A34A",
};

const StatusDotText = ({ value }) => {
  const color = statusColorMap[value] || "#0A2E78";

  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.6 }}>
      {/* dot */}
      <Box
        sx={{
          width: 8,
          height: 8,
          borderRadius: "50%",
          backgroundColor: color,
        }}
      />

      {/* text */}
      <Typography
        sx={{
          fontSize: 10,
          fontWeight: 600,
          color: color,
          lineHeight: 1,
        }}
      >
        {value}
      </Typography>
    </Box>
  );
};

export default function TESMDeepDive() {
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();
  return (
    <Box
      sx={{
        width: "100%",
        bgcolor: "#F5F7FB",
        px: 1.5,
        py: 1,
        pb: "60px",
      }}
    >
      {/* ================================= */}
      {/* BREADCRUMB */}
      {/* ================================= */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          mb: "10px",
          alignItems: "center",
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Breadcrumbs
            separator={<NavigateNextIcon fontSize="small" />}
            sx={{
              // mb: 1,
              fontSize: 13,
            }}
          >
            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 600,
                color: "#010035",
              }}
            >
              Initiatives
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 600,
                color: "#010035",
              }}
            >
              TESM
            </Typography>

            <Typography
              sx={{
                fontSize: 13,
                fontWeight: 700,
                color: "#010035",
              }}
            >
              Deep Dive
            </Typography>
          </Breadcrumbs>

          <IconButton
            onClick={() => navigate("/")}
            size="small"
            sx={{
              color: "#010035",
              marginLeft: "10px",
              fontSize: "5px",
            }}
          >
            <ArrowBackIcon fontSize="small" />
          </IconButton>
        </Box>

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            textAlign: "center",
            alignContent: "center",
          }}
        >
          <div
            style={{
              padding: "5px 10px",
              background: theme.tableHeaderBg,
              borderRadius: 6,
              color: "#ffffff",
              fontSize: 11,
              fontFamily: "var(--font-mono)",
              border: `1px solid ${theme.chipActiveBorder}`,
              fontWeight: 500,
            }}
          >
            Live ·{" "}
            {new Date().toLocaleDateString("en-US", {
              month: "short",
              day: "numeric",
              year: "numeric",
            })}
          </div>
        </Box>
      </Box>

      {/* ================================= */}
      {/* HEADER */}
      {/* ================================= */}
      <Card
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          borderRadius: 1.5,
          px: 1.5,
          py: 0.75,
          mb: 1,
        }}
      >
        <Grid container alignItems="center">
          <Grid size={{ xs: 12, md: 8 }}>
            <Stack direction="row" spacing={1.5} alignItems="center">
              <Avatar
                sx={{
                  width: 32,
                  height: 32,
                  bgcolor: "#383d5a",
                  color: "#fff",
                }}
              >
                <CloudOutlinedIcon sx={{ fontSize: 18 }} />
              </Avatar>

              <Box>
                <Stack direction="row" spacing={1} alignItems="center">
                  <Typography
                    sx={{
                      fontSize: 16,
                      fontWeight: 700,
                      color: "#010035",
                      lineHeight: 1,
                    }}
                  >
                    TESM - Tech Ecosystem & Spend Management
                  </Typography>

                  <Chip
                    label=""
                    size="small"
                    sx={{
                      bgcolor: "#F4A622",
                      color: "#000",
                      fontWeight: 700,
                      height: 22,
                      width: 22,
                      fontSize: 10,
                    }}
                  />
                </Stack>
                <Typography
                  sx={{
                    fontSize: 12,
                    mt: 0.25,
                    color: "#383d5a",
                    lineHeight: 1.3,
                    maxWidth: "100%",
                  }}
                >
                    Optimize Spend through software & maintenance, cloud, consulting, Telecom & Lease to bend the cost curve from 10.5% CAGR to 4% and deliver $140M+ long-term savings.
                </Typography>
               
              </Box>
            </Stack>
          </Grid>

          <Grid size={{ xs: 12, md: 4 }}>
            <Stack
              direction="row"
              spacing={1}
              justifyContent="flex-end"
              alignItems="center"
            >
              <Button
                variant="outlined"
                startIcon={<ShareOutlinedIcon sx={{ fontSize: 14 }} />}
                size="small"
                sx={{
                  minWidth: 75,
                  height: 28,
                  fontSize: 11,
                  textTransform: "none",
                  px: 1,
                }}
              >
                Share
              </Button>

              <Button
                variant="outlined"
                startIcon={<DownloadOutlinedIcon sx={{ fontSize: 14 }} />}
                size="small"
                sx={{
                  minWidth: 80,
                  height: 28,
                  fontSize: 11,
                  textTransform: "none",
                  px: 1,
                }}
              >
                Export
              </Button>
            </Stack>
          </Grid>
        </Grid>
      </Card>

      

      {/* ================================= */}
      {/* SUMMARY CARD */}
      {/* ================================= */}

      <Card
      elevation={0}
      sx={{
        border: "1px solid #E2E8F0",
        borderRadius: 2,
        p: 1,
      }}
    >
      <Grid
        container
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            sm: "repeat(2,1fr)",
            md: "repeat(3,1fr)",
            lg: "repeat(4,minmax(0,1fr))",
          },
          alignItems: "stretch",
          gap: 1,
        }}
      >
        {/* {infoCards.map((item) => (
          <InfoCard
            key={item.title}
            item={item}
          />
        ))} */}
        {/* {summaryCards1.map((item, index) => (
          <SavingsCard
            key={item.title}
            item={item}
            last={index === summaryCards1.length - 1}
          />
        ))} */}
          {summaryCard2.map((item, index) => (
            <SavingsCards2
              key={item.title}
              item={item}
              last={index === summaryCard2.length}
            />
          ))}
        

        </Grid>
        </Card>

      {/* ================================= */}
      {/* KPI ROW */}
      {/* ================================= */}

      
      {/* Charts */}

      <Box mt={2}> 
  <Stack
    direction="row"
    justifyContent="space-between"
    alignItems="center"
    mb={1}
  >
    <Typography
      sx={{
        fontWeight: 500,
        fontSize: 14,
        color: "#383d5a"
      }}
    >
      SAVINGS PROGRESS BY LEVER
      <Typography
        component="span"
        sx={{
          ml: 0.5,
          color: "#383d5a",
          fontSize: 12,
          fontWeight: 500,
        }}
      >
        (Targets & YTD Savings)
      </Typography>
    </Typography>

    <Typography
      sx={{
        fontSize: 11,
        color: "text.secondary",
      }}
    >
      {/* All savings are annualized run-rate potential. */}
    </Typography>
  </Stack>


  <Grid
      container
      sx={{
        display: "grid",
        gridTemplateColumns: {
          xs: "1fr",
          sm: "repeat(2,1fr)",
          lg: `repeat(5,1fr)`,
        },
        gap: 1,
        mt: 2,
      }}
    >
      {savingsCards.map((item) => (
        <SavingsLeverCard
          key={item.id}
          item={item}
        />
      ))}
    </Grid>
 
</Box>
      
    
<Box
        sx={{
          display: "grid",
          gridTemplateColumns: "1.2fr 1.7fr",
          gap: "10px",
          mt: 1,
        }}
      >
        <SpendTrendCard />


        {/* akash-changes */}
        <Box
        sx={{
          display:"grid",
          gridTemplateRows:"repeat(auto-fit, minmax(250px, 1fr))",
          gap:"10px",
          alignItems:"stretch"
        }}
        >
         <Card
          elevation={0}
          sx={{
            border: "1px solid #E2E8F0",
            borderRadius: 1.5,
            p: "10px",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Typography
            sx={{
              fontSize: 12,
              fontWeight: 700,
              color: "#0A2E78",
              mb: 1,
            }}
          >
            VALUE PIPELINE & OPPORTUNTIES
          </Typography>

          <Table
            size="small"
            sx={{
              tableLayout: "fixed", // 🔥 important for controlled columns

              "& .MuiTableCell-root": {
                fontSize: "10px",
                color: "#0A2E78",
                textAlign: "left",
                py: 0.6,
              },

              "& .MuiTableHead-root .MuiTableCell-root": {
                backgroundColor: "#0A2E78",
                color: "#fff",
                fontWeight: 700,
                borderBottom: "none",
              },
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: "25%" }}>Vendor / Item</TableCell>
                <TableCell sx={{ width: "25%" }}>Opportunity</TableCell>
                <TableCell sx={{ width: "20%" }}>Optimization Potential</TableCell>
                <TableCell sx={{ width: "12%" }}>Status</TableCell>
                <TableCell sx={{ width: "18%" }}>Value Realize(YTD)</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {pipeline.map((risk) => (
                <TableRow key={risk.vendor}>
                  <TableCell>{risk.vendor}</TableCell>
                  <TableCell>{risk.opportunity}</TableCell>
                  <TableCell>{risk.potential}</TableCell>
                  <TableCell>{risk.status}</TableCell>
                  <TableCell>{risk.value}</TableCell>

                  {/* <TableCell>
                    <ImpactBadge value={risk.opportunity} />
                  </TableCell>

                  <TableCell>
                    <StatusDotText value={risk.status} />
                  </TableCell>

                  <TableCell>{risk.mitigation}</TableCell> */}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>


        <Card
          elevation={0}
          sx={{
            border: "1px solid #E2E8F0",
            borderRadius: 1.5,
            p: "10px",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Typography
            sx={{
              fontSize: 12,
              fontWeight: 700,
              color: "#0A2E78",
              mb: 1,
            }}
          >
            RISKS & DEPENDENCIES
          </Typography>

          <Table
            size="small"
            sx={{
              tableLayout: "fixed", // 🔥 important for controlled columns

              "& .MuiTableCell-root": {
                fontSize: "10px",
                color: "#0A2E78",
                textAlign: "left",
                py: 0.6,
              },

              "& .MuiTableHead-root .MuiTableCell-root": {
                backgroundColor: "#0A2E78",
                color: "#fff",
                fontWeight: 700,
                borderBottom: "none",
              },
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: "33%" }}>Risk / Issue</TableCell>
                <TableCell sx={{ width: "18%" }}>Impact</TableCell>
                <TableCell sx={{ width: "26%" }}>Status</TableCell>
                <TableCell sx={{ width: "42%" }}>Mitigation</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {risks.map((risk) => (
                <TableRow key={risk.risk}>
                  <TableCell>{risk.risk}</TableCell>

                  <TableCell>
                    <ImpactBadge value={risk.impact} />
                  </TableCell>

                  <TableCell>
                    <StatusDotText value={risk.status} />
                  </TableCell>

                  <TableCell>{risk.mitigation}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
        </Box>
        
        
      </Box>
      {/* <Box  sx={{
          display: "grid",
          gridTemplateColumns: "1.2fr 1.7fr",
          gap: "10px",
          mt: 1,
        }}> */}
      {/* <Card
          elevation={0}
          sx={{
            border: "1px solid #E2E8F0",
            borderRadius: 1.5,
            p: "10px",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Typography
            sx={{
              fontSize: 12,
              fontWeight: 700,
              color: "#0A2E78",
              mb: 1,
            }}
          >
           STRATEGIC MILESTONE TRACKER
          </Typography>
          <Table
            size="small"
            sx={{
              tableLayout: "fixed", // important for width control

              "& .MuiTableCell-root": {
                fontSize: "10px",
                color: "#0A2E78",
                textAlign: "left",
                py: 0.6,
              },

              "& .MuiTableHead-root .MuiTableCell-root": {
                backgroundColor: "#0A2E78",
                color: "#fff",
                fontWeight: 700,
                borderBottom: "none",
              },
            }}
          >
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: "45%" }}>Milestone</TableCell>

                <TableCell sx={{ width: "25%" }}>Target</TableCell>

                <TableCell sx={{ width: "30%" }}>Status</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {milestones.map((row) => (
                <TableRow key={row.milestone}>
                  <TableCell sx={{ }}>
                    {row.milestone}
                  </TableCell>

                  <TableCell sx={{ whiteSpace: "nowrap" }}>
                    {row.target}
                  </TableCell>

                  <TableCell sx={{ whiteSpace: "nowrap" }}>
                    <StatusBadge value={row.status} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card> */}

        {/* ================= RISKS & ISSUES ================= */}
        
      {/* </Box> */}
      <Card
        elevation={0}
        sx={{
          mt: 1,
          border: "1px solid #E2E8F0",
          borderRadius: 1.5,
          p: 1.5,
        }}
      >
        <Typography
          sx={{
            fontSize: 12,
            fontWeight: 700,
            color: "#010035",
            mb: 1,
          }}
        >
          KEY DOCUMENTS & LINKS
        </Typography>

        <Box
          sx={{
            display: "grid",
            // gridTemplateColumns: "repeat(7, 1fr)",
            gridTemplateColumns: `repeat(${documents.length}, 1fr)`,
            gap: 1,
          }}
        >
          {documents.map((doc) => (
            <Card
              key={doc.title}
              elevation={0}
              sx={{
                border: "1px solid #E2E8F0",
                borderRadius: 1,
                //   height: 82,
                px: 1,
                py: 1,
                cursor: "pointer",

                "&:hover": {
                  bgcolor: "#F8FAFC",
                },
              }}
            >
              <Stack direction="row" spacing={1} alignItems="flex-start">
                <Typography
                  sx={{
                    fontSize: 24,
                    lineHeight: 1,
                  }}
                >
                  {doc.icon}
                </Typography>

                <Box>
                  <Typography
                    sx={{
                      fontSize: 11,
                      fontWeight: 500,
                      color: "#010035",
                      whiteSpace: "pre-line",
                      lineHeight: 1.3,
                    }}
                  >
                    {doc.title}
                  </Typography>

                  <Typography
                    sx={{
                      fontSize: 10,
                      color: "#2563EB",
                      mt: 0.5,
                      fontWeight: 500,
                    }}
                  >
                    View
                  </Typography>
                </Box>
              </Stack>
            </Card>
          ))}
        </Box>
      </Card>
      <Card
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          // borderRadius: 2,
          py: 1,
          px: 1.5,
          position: "fixed",
          bottom: 0,
          left: 10,
          right: 10,
          zIndex: 1000,
          bgcolor: "#F5F7FB"
          // borderRadius: 0,
        }}
      >
        <Grid
          container
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "repeat(4,1fr)",
              sm: "repeat(4,1fr)",
              md: "repeat(4,1fr)",
              lg: "repeat(4,1fr)"
            },
            alignItems: "stretch",
            gap: 1,
          }}
        >
          {infoCards.map((item) => (
            <InfoCard
              key={item.title}
              item={item}
            />
          ))}
        </Grid>
      </Card>
    </Box>
  );
}

function LegendItem({ color, label, dashed }: any) {
  return (
    <Stack direction="row" spacing={2} alignItems="center">
      <Box
        sx={{
          width: 18,
          borderTop: `2px ${dashed ? "dashed" : "solid"} ${color}`,
        }}
      />

      <Typography
        sx={{
          fontSize: 10,
          fontWeight: 600,
          color: "#0A2E78",
        }}
      >
        {label}
      </Typography>
    </Stack>
  );
}

function FooterCard({ icon, title, value }: any) {
  return (
    <Stack
      direction="row"
      spacing={1}
      alignItems="center"
      sx={{
        minWidth: 95,
      }}
    >
      <Box
        sx={{
          display: "flex",
          "& .MuiSvgIcon-root": {
            fontSize: 14, // reduce icon size
          },
        }}
      >
        {icon}
      </Box>

      <Box>
        <Typography
          sx={{
            fontSize: 8,
            fontWeight: 700,
            color: "#0B226F",
          }}
        >
          {title}
        </Typography>

        <Typography
          sx={{
            fontSize: 9,
            color: "#344054",
          }}
        >
          {value}
        </Typography>
      </Box>
    </Stack>
  );
}
