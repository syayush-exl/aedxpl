import React from "react";
import {
    Avatar,
    Box,
    Breadcrumbs,
    Button,
    Card,
    Chip,
    Divider,
    Grid,
    LinearProgress,
    Stack,
    Typography,
    Paper,
    CardContent,
    IconButton,
    CircularProgress,
} from "@mui/material";
import {
    ResponsiveContainer,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    LabelList,
    Cell,
    ReferenceLine,
} from "recharts";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import ShareOutlinedIcon from "@mui/icons-material/ShareOutlined";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";

import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import CloudOutlinedIcon from "@mui/icons-material/CloudOutlined";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import DashboardCustomizeOutlinedIcon from "@mui/icons-material/DashboardCustomizeOutlined";
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import FlagOutlinedIcon from "@mui/icons-material/FlagOutlined";
import PersonIcon from '@mui/icons-material/Person';
import SmartToyOutlinedIcon from "@mui/icons-material/SmartToyOutlined";

import Groups2OutlinedIcon from "@mui/icons-material/Groups2Outlined";
import PublicOutlinedIcon from "@mui/icons-material/PublicOutlined";
import WindowOutlinedIcon from "@mui/icons-material/WindowOutlined";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import Tooltip from "@mui/material/Tooltip";

import NorthRoundedIcon from "@mui/icons-material/NorthRounded";

import GroupsIcon from "@mui/icons-material/Groups";
import PublicIcon from "@mui/icons-material/Public";
import GridViewRoundedIcon from "@mui/icons-material/GridViewRounded";

import { useTheme } from "../../theme-context";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useNavigate } from "react-router-dom";


const labelStyle = {
    fontSize: "11px",
    fontWeight: 500,
    color: "#010035",
};

const valueStyle = {
    fontSize: "42px",
    fontWeight: 700,
    color: "#0A2E78",
};

const roadmaps = [
    {
        focus: "Growth",
        description: "Focus investment on key domains (Payroll, Compliance, Tax, Implementation)",
        target: "TBD",
        status: "On Track",
    },
    {
        focus: "Distribution",
        description: "Shift from features to Persona-based agents spanning domains.",
        target: "TBD",
        status: "In Progress",
    },
    {
        focus: "Scale",
        description: "Scale with consistent agent orchestration standards",
        target: "TBD",
        status: "Planned",
    },
]
const agentDetails = [
    {
        persona: "Employee",
        domain: "Benefits",
        aiAgentName: "Benefits Agent - ESS",
        description: "Help employees access benefits related features like open Enrollment",
        agentType: "Domain",
        connectedToDomain: "N/A",
        connectedToHead: "N/A",
        demoLink: "",
    },
    // {
    //     persona: "Employee",
    //     domain: "Benefits",
    //     aiAgentName: "Benefits Agent - ESS",
    //     description: "Help employees access benefits related features like open Enrollment",
    //     agentType: "Domain",
    //     connectedToDomain: "N/A",
    //     connectedToHead: "N/A",
    //     demoLink: "",
    // },
    // {
    //     persona: "Employee",
    //     domain: "Benefits",
    //     aiAgentName: "Benefits Agent - ESS",
    //     description: "Help employees access benefits related features like open Enrollment",
    //     agentType: "Domain",
    //     connectedToDomain: "N/A",
    //     connectedToHead: "N/A",
    //     demoLink: "",
    // },
    // {
    //     persona: "Employee",
    //     domain: "Benefits",
    //     aiAgentName: "Benefits Agent - ESS",
    //     description: "Help employees access benefits related features like open Enrollment",
    //     agentType: "Domain",
    //     connectedToDomain: "N/A",
    //     connectedToHead: "N/A",
    //     demoLink: "",
    // },
]

const milestones = [
    {
        milestone: "Resource Mix Savings Target ($)",
        target: "$40M",
        description: "Savings from FTE/Contractor rebalancing",
    },
    {
        milestone: "Geo Mix Savings Target ($)",
        target: "$10M - $30M",
        description: "Savings from geo mix shift",
    },
    {
        milestone: "Others Savings Target ($)",
        target: "-",
        description: "Savings from Microsite reduction",
    },

];

const risks = [
    {
        risk: "Poor adoption of persona-based agents",
        impact: "High",
        status: "At Risk",
        mitigation: "Run targeted adoption campaigns",
    },
    {
        risk: "Incomplete persona requirements",
        impact: "High",
        status: "At Risk",
        mitigation: "Validate use cases with stakeholders",
    },
    {
        risk: "Dependency on AI/data platform readiness",
        impact: "High",
        status: "Needs Attention",
        mitigation: "Align roadmap and platform milestones",
    },
    {
        risk: "Integration challenges with existing systems",
        impact: "Medium",
        status: "Needs Attention",
        mitigation: "Prioritize critical integrations",
    },
    {
        risk: "Lack of standardized agent governance",
        impact: "Medium",
        status: "Needs Attention",
        mitigation: "Establish agent development standards",
    },
];
const documents = [
    {
        icon: "📊",
        title: "Initiative Overview (One Pager) (PPT)",
    },
    {
        icon: "📗",
        title: "Application Inventory\n(XLSX)",
    },
    {
        icon: "📈",
        title: "Migration Factory\nDashboard",
    },
    {
        icon: "📘",
        title: "FinOps Assessment\n(DOCX)",
    },
    {
        icon: "📕",
        title: "Architecture Review\n(PDF)",
    },
    {
        icon: "🟢",
        title: "Steering Committee\nNotes",
    },
    {
        icon: "📄",
        title: "RAID Log",
    },
];

const data = [
    { name: "Pay", value: 63 },
    { name: "HR", value: 14 },
    { name: "Talent", value: 8 },
    { name: "Benefits &\nRetirement", value: 14 },
    { name: "Time", value: 44 },
    { name: "Compliance", value: 8 },
    { name: "Multiple\nDomains", value: 37 },
    { name: "Implementation", value: 17 },
    { name: "Service", value: 12 },
    { name: "Other", value: 8 },
    { name: "Sales", value: 9 },
];
const domainData = [
    { name: "Time", value: 326 },
    { name: "Multiple Domains", value: 175 },
    { name: "Sales", value: 142 },
    { name: "Pay", value: 139 },
    { name: "Service", value: 87 },
    { name: "Compliance", value: 65 },
    { name: "HR", value: 55 },
    { name: "Benefits", value: 51 },
    { name: "Implementation", value: 34 },
    { name: "Talent", value: 28 },
];

const buData = [
    { name: "Breakthrough", value: 5 },
    { name: "CoSo", value: 16 },
    { name: "ESI_BoB", value: 11 },
    { name: "ESI_CEL", value: 22 },
    { name: "ESI_GV", value: 52 },
    { name: "ESI_IHCM", value: 24 },
    { name: "HRO_CS_CG", value: 85 },
    { name: "HRO_CS_NG", value: 100 },
    { name: "HRO_TS_CG", value: 74 },
    { name: "HRO_XB_CS_CG", value: 1 },
];

const personaData = [
    { name: "Practitioner", value: 489 },
    { name: "Associate", value: 339 },
    { name: "Employee", value: 327 },
    { name: "Manager", value: 235 },
];

const infoCards = [
    {
        title: "Initiative Owner",
        value: "Roberto Masiero",
        subtitle: "",
        icon: <PersonOutlineIcon color="primary" sx={{ fontSize: 16 }} />,
    },
    {
        title: "FAST Pillar",
        value: "Accelerate",
        subtitle: "",
        icon: (
            <DashboardCustomizeOutlinedIcon
                color="primary"
                sx={{ fontSize: 16 }}
            />
        ),
    },
    {
        title: "Timeline",
        value: "FY26 - FY29",
        subtitle: "(4 Year Program)",
        icon: (
            <CalendarMonthOutlinedIcon color="primary" sx={{ fontSize: 16 }} />
        ),
    },
    {
        title: "Current Phase",
        value: "FY27",
        subtitle: "Execution Phase",
        icon: <FlagOutlinedIcon color="primary" sx={{ fontSize: 16 }} />,
    },
    // {
    //   title: "Key Takeaway",
    //   value:
    //     "Geo mix optimization is ahead of plan while resource mix and workforce optimization require acceleration.",
    //   subtitle: "",
    //   icon: null,
    //   isTakeaway: true,
    // },
];

const agentSummaryCardsData = [
    {
      title: "Total Live Agents",
      value: 249,
      color: "#18B96E",
    },
    {
      title: "GA Live",
      value: 181,
      color: "#18B96E",
    },
    {
      title: "Pilot Live",
      value: 68,
      color: "#18B96E",
    },
    {
      title: "GA Upcoming",
      value: 905,
      color: "#94A3B8",
    },
    {
      title: "Pilot Upcoming",
      value: 836,
      color: "#94A3B8",
    },
  ];
const summaryCardData = [
    {
        title: "Practitioner",
        value: "54%",
        target: "100%",
        progress: 54,
        percentage: "71%",
        iconBg: "#F1EBFF",
        iconColor: "#383d5a",
        status: "On Track",
    },
    {
        title: "Employee",
        value: "30%",
        target: "100%",
        // ytdLY: "$5M (YTD LY)",
        // growth: "+ $3M",
        progress: 47,
        percentage: "53%",
        iconBg: "#F1EBFF",
        iconColor: "#383d5a",
        status: "Off Track",
    },
    {
        title: "Associate",
        value: "24%",
        target: "100%",
        progress: 24,
        // ytdLY: "$2M (QTD LQ)",
        // growth: "+ $1M",
        percentage: "40%",
        iconBg: "#EAF3FF",
        iconColor: "#383d5a",
        status: "On Track",
    },
]

const BLUE = "#1565FF";
const GREEN = "#0CA44B";


/* ===================== CONFIG ===================== */
const statusConfig = {
    Completed: { color: "#16A34A", type: "filled" },
    "In Progress": { color: "#F59E0B", type: "outlined" },
    Planned: { color: "#2563EB", type: "outlined" },
};

const impactConfig = {
    High: "#DC2626",
    Medium: "#F59E0B",
    Low: "#18B96E",
};


/* ===================== IMPACT BADGE ===================== */
const ImpactBadge = ({ value }) => {
    const color = impactConfig[value] || "#0A2E78";

    return (
        <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
            <Typography sx={{ fontSize: 10, color }}>{value}</Typography>
        </Box>
    );
};

const statusColorMap = {
    "At Risk": "#DC2626",
    "Needs Attention": "#F59E0B",
    "On Track": "#16A34A",
    "In Progress": "#F59E0B",
};

const StatusDotText = ({ value }) => {
    const color = statusColorMap[value] || "#0A2E78";

    return (
        <Box sx={{ display: "flex", alignItems: "center", gap: 0.6 }}>
            {/* dot */}
            <Box
                sx={{
                    width: 8,
                    height: 8,
                    borderRadius: "50%",
                    backgroundColor: color,
                }}
            />

            {/* text */}
            <Typography
                sx={{
                    fontSize: 10,
                    fontWeight: 600,
                    color: color,
                    lineHeight: 1,
                }}
            >
                {value}
            </Typography>
        </Box>
    );
};

const InfoCard = ({ item }: any) => (
    <Box
        sx={{
            height: "100%",
            display: "flex",
            flexDirection: "column",
            justifyContent: "flex-start",
            px: 1,
            borderRight: "1px solid rgba(0,0,0,0.12)",
        }}
    >
        {item.isTakeaway ? (
            <>
                <Typography sx={labelStyle}>{item.title}</Typography>

                <Typography
                    sx={{
                        mt: 1,
                        fontSize: 11,
                        color: "#383D5A",
                        lineHeight: 1.4,
                    }}
                >
                    {item.value}
                </Typography>
            </>
        ) : (
            <>
                <Stack direction="row" spacing={0.5} alignItems="center">
                    {item.icon}
                    <Typography sx={labelStyle}>{item.title}</Typography>
                </Stack>
                <Box sx={{ display: "flex", gap: 1, mt: 0.6, justifyItems: "center", alignItems: "center" }}>

                    <Typography
                        sx={{
                            pl: "20px",
                            // mt: 0.6,
                            fontSize: 12,
                            fontWeight: 700,
                            color: "#010035",
                        }}
                    >
                        {item.value}
                    </Typography>

                    <Typography
                        sx={{
                            // pl: "20px",
                            fontSize: 10,
                            // mt: 0.6,
                            color: "text.secondary",
                        }}
                    >
                        {item.subtitle || "\u00A0"}
                    </Typography>
                </Box>
            </>
        )}
    </Box>
);
const ChartCard = ({ title, data }) => (
    <Card
        elevation={0}
        sx={{
            border: "1px solid #E2E8F0",
            borderRadius: 1,
            // height: "100%",
        }}
    >
        <CardContent sx={{ pl: "0px !important", py: "8px !important" }}>
            <Typography
                sx={{
                    fontSize: 12,
                    fontWeight: 700,
                    mb: 1,
                    color: "#010035",
                }}
                align="center"
            >
                {title}
            </Typography>

            <ResponsiveContainer width="100%" height={220}>
                <BarChart
                    data={data}
                    layout="vertical"
                    margin={{
                        top: 0,
                        right: 24,
                        left: 0,
                        bottom: 0,
                    }}
                >
                    <XAxis hide type="number" />

                    <YAxis
                        type="category"
                        dataKey="name"
                        width={90}
                        tick={{
                            fontSize: 11,
                            fill: "#444",
                        }}
                    />

                    <Bar
                        dataKey="value"
                        radius={[0, 2, 2, 0]}
                        fill="#5267C8"
                        barSize={title === "Total Agents by Persona" ? 32 : 18}
                    >
                        {data.map((entry, index) => (
                            <Cell
                                key={index}
                                fill="#5267C8"
                            />
                        ))}

                        <LabelList
                            dataKey="value"
                            position="right"
                            style={{
                                fontSize: 11,
                                fill: "#383d5a",
                                fontWeight: 600,
                            }}
                        />
                    </Bar>
                </BarChart>
            </ResponsiveContainer>

            <Typography
                align="center"
                sx={{
                    mt: 1,
                    fontSize: 11,
                    color: "#383d5a",
                }}
            >
                # Agents at SOR level (including TBDs)
            </Typography>
        </CardContent>
    </Card>
);

const SavingsCards = ({ item, last = false }: any) => (
    <Box
        sx={{
            height: "100%",
            display: "flex",
            // alignItems: "center",
            gap: 0.5,
            px: "5px",
            borderRight: last ? "none" : "1px solid rgba(0,0,0,0.12)",
        }}
    >
        <Avatar
            sx={{
                width: 24,
                height: 24,
                // bgcolor: item.iconBg,
                color: item.iconColor,

            }}
        >
            <PersonIcon />
        </Avatar>

        <Box flex={1}>
            <Box sx={{
                //   p: 1,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
            }}>
                <Typography
                    sx={{
                        fontSize: 13,
                        ml: "10px",
                        color: "#010035",
                        fontWeight: 500,
                    }}
                >
                    {item.title}
                </Typography>
                <Chip
                    label={item.status}
                    size="small"
                    sx={{
                        bgcolor: item.status === "On Track" ? "#18B96E" : item.status === "Off Track" ? "#F4A622" : "#f29900",
                        color: "#000000de",
                        fontWeight: 400,
                        borderRadius: 2,
                        fontSize: 11
                    }}
                />
            </Box>

            {/* <Typography
        sx={{
          fontWeight: 700,
          fontSize: 12,
          color: "#767a8191",
          mt: "10px",
          mb: "-10px"
        }}
      >
        {item.value}
      </Typography> */}

            <>
                <Box
                    sx={{
                        position: "relative",
                        pt: 1.5,
                        mt: 1,
                    }}
                >
                    <Typography
                        sx={{
                            position: "absolute",
                            left: `${item.progress ?? 0
                                }%`,
                            transform: "translateX(-50%)",
                            top: -2,
                            fontSize: 10,
                            fontWeight: 700,
                            color: "#767a8191",

                            maxWidth: 40,
                            textAlign: "center",
                        }}
                    >
                        {item.progress ?? 0}%
                    </Typography>

                    <LinearProgress
                        variant="determinate"
                        value={item.progress ?? 0}
                        sx={{
                            height: 5,
                            borderRadius: 10,
                            bgcolor: "#E5E7EB",

                            "& .MuiLinearProgress-bar": {
                                borderRadius: 10,
                                bgcolor: "#767a8191",
                            },
                        }}
                    />


                    <Box
                        sx={{
                            display: "flex",
                            justifyContent: "space-between",
                            mt: 0.4,
                        }}
                    >
                        <Typography
                            sx={{
                                fontSize: 10,
                                // color: "#64748B",
                                color: "#767a8191",
                                fontWeight: 600
                            }}
                        >
                            {item.value}
                        </Typography>

                        <Typography
                            sx={{
                                fontSize: 10,
                                // color: "#64748B",
                                color: ["Cost Savings Realization (FY29)"].includes(item.title) ? "#383d5a" : "#767a8191",
                                fontWeight: 600
                            }}
                        >
                            {item.target}
                        </Typography>
                    </Box>
                </Box>
                {item.ytdLY && (
                    <Stack
                        direction="row"
                        justifyContent="start"
                        alignItems="center"
                        gap={1}
                        mt={0.8}
                    >
                        <Typography
                            sx={{
                                fontSize: 10,
                                // color: "#667085",
                                color: "#667085",
                                marginLeft: "-20px"
                            }}
                        >
                            {item.ytdLY}
                        </Typography>
                        <Chip
                            size="small"
                            icon={<NorthRoundedIcon sx={{ fontSize: 14 }} />}
                            label={item.growth}
                            sx={{
                                height: 22,
                                bgcolor: "#1e8e3e12",
                                color: "#18B96E",
                                fontSize: 10,
                                fontWeight: 700,
                                "& .MuiChip-icon": {
                                    color: "#18B96E",
                                    fontSize: 12,
                                },
                            }}
                        />
                    </Stack>
                )}
            </>
        </Box>
    </Box>
);
const AgentSummaryCards = ({ title, value, color }) => {
    return (
      <Card
        elevation={0}
        sx={{
          border: "1px solid #E2E8F0",
          borderRadius: 1,       
        }}
      >      
        <Box
          sx={{
            height: 6,
            bgcolor: color,
          }}
        />       
        <Box
          sx={{
            bgcolor: "#EAF2FF",
            py: 0.25,
            // px: 1,
            borderBottom: "1px solid #E2E8F0",
          }}
        >
          <Typography
            align="center"
            sx={{
              fontSize: 12,
              fontWeight: 700,
              color: "#010035",
            }}
          >
            {title}
          </Typography>
        </Box>  
        
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",           
          }}
        >
          <Typography
            sx={{
              fontSize: 20,
              fontWeight: 700,
              color: "#334155",
            }}
          >
            {value}
          </Typography>
        </Box>
      </Card>
    );
};

export default function AICentricDeepDive() {
    const { theme, toggle } = useTheme();
    const navigate = useNavigate();
    return (
        <Box
            sx={{
                width: "100%",
                bgcolor: "#F5F7FB",
                px: 1.5,
                py: 1,
                pb: "60px",
            }}
        >         
            {/* BREADCRUMB */}           
            <Box
                sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    mb: "10px",
                    alignItems: "center",
                }}
            >
                <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Breadcrumbs
                        separator={<NavigateNextIcon fontSize="small" />}
                        sx={{
                            // mb: 1,
                            fontSize: 13,
                        }}
                    >
                        <Typography
                            sx={{
                                fontSize: 13,
                                fontWeight: 600,
                                color: "#010035",
                            }}
                        >
                            Initiatives
                        </Typography>

                        <Typography
                            sx={{
                                fontSize: 13,
                                fontWeight: 600,
                                color: "#010035",
                            }}
                        >
                            Deliver on Persona Based Agent Plan
                        </Typography>

                        <Typography
                            sx={{
                                fontSize: 13,
                                fontWeight: 700,
                                color: "#010035",
                            }}
                        >
                            Deep Dive
                        </Typography>
                    </Breadcrumbs>

                    <IconButton
                        onClick={() => navigate("/")}
                        size="small"
                        sx={{
                            color: "#010035",
                            marginLeft: "10px",
                            fontSize: "5px",
                        }}
                    >
                        <ArrowBackIcon fontSize="small" />
                    </IconButton>
                </Box>

                <Box
                    sx={{
                        display: "flex",
                        alignItems: "center",
                        textAlign: "center",
                        alignContent: "center",
                    }}
                >
                    <div
                        style={{
                            padding: "5px 10px",
                            background: theme.tableHeaderBg,
                            borderRadius: 6,
                            color: "#ffffff",
                            fontSize: 11,
                            fontFamily: "var(--font-mono)",
                            border: `1px solid ${theme.chipActiveBorder}`,
                            fontWeight: 500,
                        }}
                    >
                        Live ·{" "}
                        {new Date().toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                            year: "numeric",
                        })}
                    </div>
                </Box>
            </Box>

            {/* HEADER */}         
            <Card
                elevation={0}
                sx={{
                    border: "1px solid #E2E8F0",
                    borderRadius: 1.5,
                    px: 1.5,
                    py: 0.75,
                    mb: 1,
                }}
            >
                <Grid container alignItems="center">
                    <Grid size={{ xs: 12, md: 8 }}>
                        <Stack direction="row" spacing={1.5} alignItems="center">
                            <Avatar
                                sx={{
                                    width: 32,
                                    height: 32,
                                    bgcolor: "#383d5a",
                                    color: "#fff",
                                }}
                            >
                                <SmartToyOutlinedIcon sx={{ fontSize: 18 }} />
                            </Avatar>

                            <Box>
                                <Stack direction="row" spacing={1} alignItems="center">
                                    <Typography
                                        sx={{
                                            fontSize: 16,
                                            fontWeight: 700,
                                            color: "#010035",
                                            lineHeight: 1,
                                        }}
                                    >
                                        Deliver on Persona Based Agent Plan
                                    </Typography>

                                    <Chip
                                        label=""
                                        size="small"
                                        sx={{
                                            bgcolor: "#F4A622",
                                            color: "#000",
                                            fontWeight: 700,
                                            height: 22,
                                            width: 22,
                                            fontSize: 10,
                                        }}
                                    />
                                </Stack>
                                <Typography
                                    sx={{
                                        fontSize: 12,
                                        mt: 0.25,
                                        color: "#383d5a",
                                        lineHeight: 1.3,
                                        maxWidth: "100%",
                                    }}
                                >
                                    {/* AI-led Global Delivery Transformation */}
                                </Typography>

                                <Typography
                                    sx={{
                                        fontSize: 10,
                                        mt: 0.25,
                                        color: "#475569",
                                        lineHeight: 1.3,
                                        maxWidth: "100%",
                                    }}
                                >
                                    Focusing the roadmap on Persona-based agents to drive scalable value.
                                </Typography>
                            </Box>
                        </Stack>
                    </Grid>

                    <Grid size={{ xs: 12, md: 4 }}>
                        <Stack
                            direction="row"
                            spacing={1}
                            justifyContent="flex-end"
                            alignItems="center"
                        >
                            <Button
                                variant="outlined"
                                startIcon={<ShareOutlinedIcon sx={{ fontSize: 14 }} />}
                                size="small"
                                sx={{
                                    minWidth: 75,
                                    height: 28,
                                    fontSize: 11,
                                    textTransform: "none",
                                    px: 1,
                                }}
                            >
                                Share
                            </Button>

                            <Button
                                variant="outlined"
                                startIcon={<DownloadOutlinedIcon sx={{ fontSize: 14 }} />}
                                size="small"
                                sx={{
                                    minWidth: 80,
                                    height: 28,
                                    fontSize: 11,
                                    textTransform: "none",
                                    px: 1,
                                }}
                            >
                                Export
                            </Button>
                        </Stack>
                    </Grid>
                </Grid>
            </Card>

            {/* SUMMARY CARD */}            
            <Card
                elevation={0}
                sx={{
                    border: "1px solid #E2E8F0",
                    borderRadius: 2,
                    p: 1,
                }}
            >
               {/* <Typography
        sx={{
          fontSize: 18,
          fontWeight: 700,
          color: "#010035",
          mb: 2,
        }}
      >
        Agent Summary
      </Typography> */}

      <Box
        sx={{
          display: "grid",
          gap: 2,
          gridTemplateColumns: {
            xs: "1fr",
            sm: "repeat(2,1fr)",
            md: "repeat(3,1fr)",
            lg: "repeat(5,1fr)",
          },
        }}
      >
        {agentSummaryCardsData.map((card) => (
          <AgentSummaryCards
            key={card.title}
            {...card}
          />
        ))}
      </Box>
    </Card>
     {/* Extra Summary Cards */}
    <Card
                elevation={0}
                sx={{
                    border: "1px solid #E2E8F0",
                    borderRadius: 2,
                    p: 1,
                    mt: 1
                }}
            >
                <Grid
                    container
                    sx={{
                        display: "grid",
                        gridTemplateColumns: {
                            xs: "1fr",
                            sm: "repeat(2,1fr)",
                            md: "repeat(3,1fr)",
                            lg: "repeat(3, 1fr)"
                        },
                        alignItems: "stretch",
                        gap: 1,
                    }}
                >
                    {summaryCardData.map((item, index) => (
                        <SavingsCards
                            key={item.title}
                            item={item}
                            last={index === summaryCardData.length}
                        />
                    ))}

                </Grid>
            </Card>
           
            {/* Agent Distribution Charts */}
            <Card
                elevation={0}
                sx={{
                    mt: 1,
                    border: "1px solid #E2E8F0",
                    borderRadius: 2,
                    p: 1,
                }}
            >
                <Typography
                    sx={{
                        fontSize: "14px",
                        color: "#010035",
                        fontWeight: 700,
                        mb: 1,
                    }}
                >
                    Agent Distribution
                </Typography>

                <Box
                    sx={{
                        display: "grid",
                        gap: 2,
                        gridTemplateColumns: {
                            xs: "1fr",
                            md: "repeat(2,1fr)",
                            lg: "repeat(3,1fr)",
                        },
                    }}
                >
                    <ChartCard
                        title="Total Agents by Domain"
                        data={domainData}
                    />

                    <ChartCard
                        title="Distribution by Consumption BU"
                        data={buData}
                    />

                    <ChartCard
                        title="Total Agents by Persona"
                        data={personaData}
                    />
                </Box>
            </Card>
           
          
            {/* Payroll charts */}
            <Card
                elevation={0}
                sx={{
                    border: "1px solid #E2E8F0",
                    borderRadius: 2,
                    mt: 1,
                }}
            >
                <CardContent sx={{ pb: "0px !important" }}>
                    <Typography
                        sx={{
                            fontSize: 14,
                            fontWeight: 700,
                            // mb: 1,
                            color: "#010035",
                        }}
                    >
                        Domain: Payroll represents the largest area of roadmap investment
                    </Typography>
                    <Box sx={{ position: "relative" }}>

                        <ResponsiveContainer width="100%" height={130}>
                            <BarChart
                                data={data}
                                margin={{
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0,
                                }}
                            >
                                <YAxis hide />

                                <XAxis
                                    dataKey="name"
                                    tick={{
                                        fontSize: 11,
                                        fill: "#444",
                                    }}
                                    interval={0}
                                />

                                <Bar
                                    dataKey="value"
                                    fill="#5267C8"
                                    barSize={30}
                                    radius={[2, 2, 0, 0]}
                                >
                                    <LabelList
                                        dataKey="value"
                                        position="top"
                                        style={{
                                            fontSize: 11,
                                            fill: "#383d5a",
                                            fontWeight: 600,
                                        }}
                                    />
                                </Bar>

                                {/* <ReferenceLine
              y={55}
              stroke="#5267C8"
              strokeWidth={1.5}
            /> */}

                            </BarChart>
                        </ResponsiveContainer>
                        <Box
                            sx={{
                                position: "absolute",
                                right: 160,
                                top: 45,
                                width: 230,
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between",
                            }}
                        >
                            <Box
                                sx={{
                                    width: 6,
                                    height: 6,
                                    borderRadius: "50%",
                                    bgcolor: "#5267C8",
                                }}
                            />

                            <Box
                                sx={{
                                    flex: 1,
                                    //   mx: 1,
                                    height: 2,
                                    bgcolor: "#5267C8",
                                }}
                            />

                            <Box
                                sx={{
                                    width: 6,
                                    height: 6,
                                    borderRadius: "50%",
                                    bgcolor: "#5267C8",
                                }}
                            />

                            <Typography
                                sx={{
                                    position: "absolute",
                                    top: -18,
                                    left: "35%",
                                    fontSize: 11,
                                    color: "#5267C8",
                                    fontWeight: 600,
                                }}
                            >
                                Internal
                            </Typography>
                        </Box>
                    </Box>
                </CardContent>
            </Card>
            {/* Agent Details Table */}
            <Card
                elevation={0}
                sx={{
                    border: "1px solid #E2E8F0",
                    borderRadius: 1.5,
                    p: "10px",
                    display: "flex",
                    flexDirection: "column",
                    mt: 1,
                }}
            >
                <Typography
                    sx={{
                        fontSize: 12,
                        fontWeight: 700,
                        color: "#010035",
                        mb: 1,
                    }}
                >
                    AGENT DETAILS
                </Typography>
                <Table
                    size="small"
                    sx={{
                        tableLayout: "fixed", // important for width control

                        "& .MuiTableCell-root": {
                            fontSize: "10px",
                            color: "#383d5a",
                            textAlign: "left",
                            py: 0.6,
                        },

                        "& .MuiTableHead-root .MuiTableCell-root": {
                            backgroundColor: "#0A2E78",
                            color: "#fff",
                            fontWeight: 700,
                            borderBottom: "none",
                        },
                    }}
                >
                    <TableHead>
                        <TableRow>
                            <TableCell sx={{ width: "8%" }}>Persona</TableCell>

                            <TableCell sx={{ width: "8%" }}>Domain</TableCell>

                            <TableCell sx={{ width: "14%" }}>AI Agent Name</TableCell>
                            <TableCell sx={{ width: "30%" }}>Description</TableCell>
                            <TableCell sx={{ width: "7%" }}>Agent Type</TableCell>
                            <TableCell sx={{ width: "12%" }}>Connected to Domain</TableCell>
                            <TableCell sx={{ width: "13%" }}>Connected to Head</TableCell>
                            <TableCell sx={{ width: "8%" }}>Demo Link</TableCell>
                        </TableRow>
                    </TableHead>

                    <TableBody>
                        {agentDetails.map((row) => (
                            <TableRow key={row.persona}>
                                <TableCell sx={{}}>{row.persona}</TableCell>
                                <TableCell sx={{}}>{row.domain}</TableCell>
                                <TableCell sx={{}}>{row.aiAgentName}</TableCell>
                                <TableCell sx={{}}>{row.description}</TableCell>
                                <TableCell sx={{}}>{row.agentType}</TableCell>
                                <TableCell sx={{}}>{row.connectedToDomain}</TableCell>
                                <TableCell sx={{}}>{row.connectedToHead}</TableCell>
                                <TableCell sx={{}}>{row.demoLink}</TableCell>

                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </Card>

            {/* Roadmaps & Risks/Dependencies Table */}
            <Box
                sx={{
                    display: "grid",
                    gridTemplateColumns: "0.9fr 1.1fr",
                    gap: "10px",
                    mt: 1,
                }}
            >
                <Card
                    elevation={0}
                    sx={{
                        border: "1px solid #E2E8F0",
                        borderRadius: 1.5,
                        p: "10px",
                        display: "flex",
                        flexDirection: "column",
                    }}
                >
                    <Typography
                        sx={{
                            fontSize: 12,
                            fontWeight: 700,
                            color: "#010035",
                            mb: 1,
                        }}
                    >
                        ROADMAP
                    </Typography>
                    <Table
                        size="small"
                        sx={{
                            tableLayout: "fixed", // important for width control

                            "& .MuiTableCell-root": {
                                fontSize: "10px",
                                color: "#383d5a",
                                textAlign: "left",
                                py: 0.6,
                            },

                            "& .MuiTableHead-root .MuiTableCell-root": {
                                backgroundColor: "#0A2E78",
                                color: "#fff",
                                fontWeight: 700,
                                borderBottom: "none",
                            },
                        }}
                    >
                        <TableHead>
                            <TableRow>
                                <TableCell sx={{ width: "20%" }}>Focus</TableCell>

                                <TableCell sx={{ width: "40%" }}>Description</TableCell>

                                <TableCell sx={{ width: "20%" }}>Target</TableCell>
                                <TableCell sx={{ width: "20%" }}>Status</TableCell>
                            </TableRow>
                        </TableHead>

                        <TableBody>
                            {roadmaps.map((row) => (
                                <TableRow key={row.focus}>
                                    <TableCell sx={{}}>
                                        {row.focus}
                                    </TableCell>
                                    <TableCell sx={{}}>
                                        {row.description}
                                    </TableCell>

                                    <TableCell sx={{}}>
                                        {row.target}
                                    </TableCell>

                                    <TableCell sx={{}}>
                                        <StatusDotText value={row.status} />
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </Card>

                {/* ================= RISKS & ISSUES ================= */}
                <Card
                    elevation={0}
                    sx={{
                        border: "1px solid #E2E8F0",
                        borderRadius: 1.5,
                        p: "10px",
                        display: "flex",
                        flexDirection: "column",
                    }}
                >
                    <Typography
                        sx={{
                            fontSize: 12,
                            fontWeight: 700,
                            color: "#010035",
                            mb: 1,
                        }}
                    >
                        RISKS & DEPENDENCIES
                    </Typography>

                    <Table
                        size="small"
                        sx={{
                            tableLayout: "fixed", // 🔥 important for controlled columns

                            "& .MuiTableCell-root": {
                                fontSize: "10px",
                                color: "#383d5a",
                                textAlign: "left",
                                py: 0.6,
                            },

                            "& .MuiTableHead-root .MuiTableCell-root": {
                                backgroundColor: "#0A2E78",
                                color: "#fff",
                                fontWeight: 700,
                                borderBottom: "none",
                            },
                        }}
                    >
                        <TableHead>
                            <TableRow>
                                <TableCell sx={{ width: "35%" }}>Risk / Dependency</TableCell>
                                <TableCell sx={{ width: "12%" }}>Impact</TableCell>
                                <TableCell sx={{ width: "18%" }}>Status</TableCell>
                                <TableCell sx={{ width: "35%" }}>Mitigation / Action</TableCell>
                            </TableRow>
                        </TableHead>

                        <TableBody>
                            {risks.map((risk) => (
                                <TableRow key={risk.risk}>
                                    <TableCell>{risk.risk}</TableCell>

                                    <TableCell>
                                        <ImpactBadge value={risk.impact} />
                                    </TableCell>

                                    <TableCell>
                                        <StatusDotText value={risk.status} />
                                    </TableCell>

                                    <TableCell>{risk.mitigation}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </Card>
            </Box>
            {/* Links */}
            <Card
                elevation={0}
                sx={{
                    mt: 1,
                    border: "1px solid #E2E8F0",
                    borderRadius: 1.5,
                    p: 1.5,
                }}
            >
                <Typography
                    sx={{
                        fontSize: 12,
                        fontWeight: 700,
                        color: "#010035",
                        mb: 1,
                    }}
                >
                    KEY DOCUMENTS & LINKS
                </Typography>

                <Box
                    sx={{
                        display: "grid",
                        gridTemplateColumns: "repeat(7, 1fr)",
                        gap: 1,
                    }}
                >
                    {documents.map((doc) => (
                        <Card
                            key={doc.title}
                            elevation={0}
                            sx={{
                                border: "1px solid #E2E8F0",
                                borderRadius: 1,
                                //   height: 82,
                                px: 1,
                                py: 1,
                                cursor: "pointer",

                                "&:hover": {
                                    bgcolor: "#F8FAFC",
                                },
                            }}
                        >
                            <Stack direction="row" spacing={1} alignItems="flex-start">
                                <Typography
                                    sx={{
                                        fontSize: 24,
                                        lineHeight: 1,
                                    }}
                                >
                                    {doc.icon}
                                </Typography>

                                <Box>
                                    <Typography
                                        sx={{
                                            fontSize: 11,
                                            fontWeight: 500,
                                            color: "#010035",
                                            whiteSpace: "pre-line",
                                            lineHeight: 1.3,
                                        }}
                                    >
                                        {doc.title}
                                    </Typography>

                                    <Typography
                                        sx={{
                                            fontSize: 10,
                                            color: "#2563EB",
                                            mt: 0.5,
                                            fontWeight: 500,
                                        }}
                                    >
                                        View
                                    </Typography>
                                </Box>
                            </Stack>
                        </Card>
                    ))}
                </Box>
            </Card>
            {/* Sticky Footer */}
            <Card
                elevation={0}
                sx={{
                    border: "1px solid #E2E8F0",
                    // borderRadius: 2,
                    // mt: 2,
                    py: 1,
                    px: 1.5,
                    position: "fixed",
                    bottom: 0,
                    left: 10,
                    right: 10,
                    zIndex: 1000,
                    bgcolor: "#F5F7FB"
                    // borderRadius: 0,
                }}
            >
                <Grid
                    container
                    sx={{
                        display: "grid",
                        gridTemplateColumns: {
                            xs: "repeat(4,1fr)",
                            sm: "repeat(4,1fr)",
                            md: "repeat(4,1fr)",
                            lg: "repeat(4,1fr)"
                        },
                        alignItems: "stretch",
                        gap: 1,
                    }}
                >
                    {infoCards.map((item) => (
                        <InfoCard
                            key={item.title}
                            item={item}
                        />
                    ))}
                </Grid>
            </Card>
        </Box>
    );
}


